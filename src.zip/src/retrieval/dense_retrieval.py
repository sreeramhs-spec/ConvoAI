"""
Dense vector retrieval using sentence transformers and FAISS.

This module implements dense retrieval using:
- Sentence transformer models for embeddings
- FAISS for efficient similarity search
- Support for different distance metrics
- Batch processing and index management
"""

import json
import pickle
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Union

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer
from tqdm import tqdm


class DenseRetriever:
    """Dense retrieval using sentence transformers and FAISS."""
    
    def __init__(self, 
                 model_name: str = "sentence-transformers/all-MiniLM-L6-v2",
                 index_type: str = "flat",
                 distance_metric: str = "cosine"):
        """
        Initialize the dense retriever.
        
        Args:
            model_name: Name of sentence transformer model
            index_type: Type of FAISS index ('flat', 'ivf', 'hnsw')
            distance_metric: Distance metric ('cosine', 'euclidean', 'dot_product')
        """
        self.model_name = model_name
        self.index_type = index_type
        self.distance_metric = distance_metric
        
        # Initialize sentence transformer
        print(f"Loading sentence transformer model: {model_name}")
        self.model = SentenceTransformer(model_name)
        self.embedding_dim = self.model.get_sentence_embedding_dimension()
        
        # Initialize FAISS index
        self.index = None
        self.chunk_ids = []
        self.chunk_metadata = {}
        
        print(f"Dense retriever initialized with {self.embedding_dim}D embeddings")
    
    def _create_faiss_index(self, embedding_dim: int) -> faiss.Index:
        """Create appropriate FAISS index based on configuration."""
        if self.distance_metric == "cosine":
            # For cosine similarity, we'll normalize vectors and use inner product
            if self.index_type == "flat":
                index = faiss.IndexFlatIP(embedding_dim)
            elif self.index_type == "ivf":
                # IVF index for larger datasets
                quantizer = faiss.IndexFlatIP(embedding_dim)
                index = faiss.IndexIVFFlat(quantizer, embedding_dim, 100)  # 100 clusters
            elif self.index_type == "hnsw":
                # HNSW for fast approximate search
                index = faiss.IndexHNSWFlat(embedding_dim, 32)  # 32 connections per vertex
            else:
                raise ValueError(f"Unsupported index type: {self.index_type}")
                
        elif self.distance_metric == "euclidean":
            if self.index_type == "flat":
                index = faiss.IndexFlatL2(embedding_dim)
            elif self.index_type == "ivf":
                quantizer = faiss.IndexFlatL2(embedding_dim)
                index = faiss.IndexIVFFlat(quantizer, embedding_dim, 100)
            elif self.index_type == "hnsw":
                index = faiss.IndexHNSWFlat(embedding_dim, 32)
            else:
                raise ValueError(f"Unsupported index type: {self.index_type}")
                
        elif self.distance_metric == "dot_product":
            if self.index_type == "flat":
                index = faiss.IndexFlatIP(embedding_dim)
            else:
                raise ValueError(f"Dot product only supported with flat index")
        else:
            raise ValueError(f"Unsupported distance metric: {self.distance_metric}")
        
        return index
    
    def encode_texts(self, 
                    texts: List[str], 
                    batch_size: int = 32,
                    show_progress: bool = True) -> np.ndarray:
        """
        Encode texts into dense embeddings.
        
        Args:
            texts: List of texts to encode
            batch_size: Batch size for encoding
            show_progress: Whether to show progress bar
            
        Returns:
            Numpy array of embeddings
        """
        embeddings = []
        
        # Process in batches
        for i in tqdm(range(0, len(texts), batch_size), 
                     desc="Encoding texts", 
                     disable=not show_progress):
            batch_texts = texts[i:i + batch_size]
            batch_embeddings = self.model.encode(
                batch_texts,
                convert_to_numpy=True,
                normalize_embeddings=(self.distance_metric == "cosine")
            )
            embeddings.append(batch_embeddings)
        
        return np.vstack(embeddings)
    
    def build_index(self, 
                   chunks: Dict[str, List[Dict]],
                   save_path: Optional[str] = None,
                   batch_size: int = 32) -> None:
        """
        Build FAISS index from text chunks.
        
        Args:
            chunks: Dictionary of chunks from text processing
            save_path: Path to save the index
            batch_size: Batch size for encoding
        """
        print("Building dense vector index...")
        
        # Prepare data
        all_texts = []
        all_chunk_ids = []
        chunk_metadata = {}
        
        for url, chunk_list in chunks.items():
            for chunk in chunk_list:
                all_texts.append(chunk['text'])
                chunk_id = chunk['chunk_id']
                all_chunk_ids.append(chunk_id)
                
                # Store metadata
                chunk_metadata[chunk_id] = {
                    'url': url,
                    'title': chunk['title'],
                    'chunk_index': chunk['chunk_index'],
                    'text': chunk['text'],
                    'token_count': chunk['token_count'],
                    'keywords': chunk.get('keywords', [])
                }
        
        print(f"Encoding {len(all_texts)} text chunks...")
        
        # Encode texts
        embeddings = self.encode_texts(all_texts, batch_size=batch_size)
        
        print(f"Creating FAISS index ({self.index_type}, {self.distance_metric})...")
        
        # Create and populate index
        self.index = self._create_faiss_index(embeddings.shape[1])
        
        # For IVF index, we need to train first
        if self.index_type == "ivf":
            print("Training IVF index...")
            self.index.train(embeddings)
        
        # Add embeddings to index
        self.index.add(embeddings)
        
        # Store metadata
        self.chunk_ids = all_chunk_ids
        self.chunk_metadata = chunk_metadata
        
        print(f"Index built successfully with {self.index.ntotal} vectors")
        
        # Save index if path provided
        if save_path:
            self.save_index(save_path)
    
    def save_index(self, save_path: str) -> None:
        """Save FAISS index and metadata to disk."""
        save_path = Path(save_path)
        save_path.mkdir(parents=True, exist_ok=True)
        
        # Save FAISS index
        faiss.write_index(self.index, str(save_path / "dense_index.faiss"))
        
        # Save metadata
        metadata = {
            'model_name': self.model_name,
            'index_type': self.index_type,
            'distance_metric': self.distance_metric,
            'embedding_dim': self.embedding_dim,
            'chunk_ids': self.chunk_ids,
            'total_chunks': len(self.chunk_ids)
        }
        
        with open(save_path / "dense_metadata.json", 'w') as f:
            json.dump(metadata, f, indent=2)
        
        # Save chunk metadata
        with open(save_path / "chunk_metadata.pkl", 'wb') as f:
            pickle.dump(self.chunk_metadata, f)
        
        print(f"Dense index saved to {save_path}")
    
    def load_index(self, load_path: str) -> None:
        """Load FAISS index and metadata from disk."""
        load_path = Path(load_path)
        
        # Load FAISS index
        self.index = faiss.read_index(str(load_path / "dense_index.faiss"))
        
        # Load metadata
        with open(load_path / "dense_metadata.json", 'r') as f:
            metadata = json.load(f)
        
        self.chunk_ids = metadata['chunk_ids']
        
        # Load chunk metadata
        with open(load_path / "chunk_metadata.pkl", 'rb') as f:
            self.chunk_metadata = pickle.load(f)
        
        print(f"Dense index loaded from {load_path}")
        print(f"Index contains {len(self.chunk_ids)} chunks")
    
    def search(self, 
              query: str, 
              top_k: int = 20,
              return_scores: bool = True) -> List[Dict]:
        """
        Search for similar chunks using dense retrieval.
        
        Args:
            query: Query text
            top_k: Number of top results to return
            return_scores: Whether to include similarity scores
            
        Returns:
            List of retrieved chunks with metadata
        """
        if self.index is None:
            raise ValueError("Index not built or loaded. Call build_index() or load_index() first.")
        
        # Encode query
        query_embedding = self.model.encode(
            [query],
            convert_to_numpy=True,
            normalize_embeddings=(self.distance_metric == "cosine")
        )
        
        # Search
        scores, indices = self.index.search(query_embedding, top_k)
        
        # Prepare results
        results = []
        for idx, score in zip(indices[0], scores[0]):
            if idx == -1:  # FAISS returns -1 for empty results
                continue
                
            chunk_id = self.chunk_ids[idx]
            chunk_data = self.chunk_metadata[chunk_id].copy()
            
            if return_scores:
                # Convert FAISS score to similarity score
                if self.distance_metric == "cosine":
                    chunk_data['similarity_score'] = float(score)
                elif self.distance_metric == "euclidean":
                    # Convert L2 distance to similarity (higher is better)
                    chunk_data['similarity_score'] = 1.0 / (1.0 + float(score))
                else:
                    chunk_data['similarity_score'] = float(score)
            
            chunk_data['retrieval_method'] = 'dense'
            results.append(chunk_data)
        
        return results
    
    def batch_search(self, 
                    queries: List[str],
                    top_k: int = 20,
                    batch_size: int = 16) -> List[List[Dict]]:
        """
        Perform batch search for multiple queries.
        
        Args:
            queries: List of query texts
            top_k: Number of top results per query
            batch_size: Batch size for query encoding
            
        Returns:
            List of result lists, one per query
        """
        all_results = []
        
        for i in tqdm(range(0, len(queries), batch_size), desc="Batch search"):
            batch_queries = queries[i:i + batch_size]
            
            # Encode batch of queries
            query_embeddings = self.model.encode(
                batch_queries,
                convert_to_numpy=True,
                normalize_embeddings=(self.distance_metric == "cosine")
            )
            
            # Search for batch
            scores, indices = self.index.search(query_embeddings, top_k)
            
            # Process results for each query in batch
            for q_idx, (query_scores, query_indices) in enumerate(zip(scores, indices)):
                results = []
                for idx, score in zip(query_indices, query_scores):
                    if idx == -1:
                        continue
                    
                    chunk_id = self.chunk_ids[idx]
                    chunk_data = self.chunk_metadata[chunk_id].copy()
                    
                    if self.distance_metric == "cosine":
                        chunk_data['similarity_score'] = float(score)
                    elif self.distance_metric == "euclidean":
                        chunk_data['similarity_score'] = 1.0 / (1.0 + float(score))
                    else:
                        chunk_data['similarity_score'] = float(score)
                    
                    chunk_data['retrieval_method'] = 'dense'
                    results.append(chunk_data)
                
                all_results.append(results)
        
        return all_results
    
    def get_embeddings(self, chunk_ids: List[str]) -> np.ndarray:
        """Get embeddings for specific chunk IDs."""
        indices = [self.chunk_ids.index(cid) for cid in chunk_ids if cid in self.chunk_ids]
        
        if not indices:
            return np.array([])
        
        # FAISS doesn't support getting vectors by ID directly
        # We need to reconstruct from the index (only works for some index types)
        try:
            embeddings = np.array([self.index.reconstruct(i) for i in indices])
            return embeddings
        except:
            print("Cannot retrieve embeddings from this index type")
            return np.array([])
    
    def get_index_stats(self) -> Dict:
        """Get statistics about the current index."""
        if self.index is None:
            return {}
        
        stats = {
            'total_vectors': self.index.ntotal,
            'embedding_dimension': self.embedding_dim,
            'index_type': self.index_type,
            'distance_metric': self.distance_metric,
            'model_name': self.model_name
        }
        
        # Add index-specific stats
        if hasattr(self.index, 'nlist'):
            stats['num_clusters'] = self.index.nlist
        if hasattr(self.index, 'hnsw'):
            stats['hnsw_m'] = self.index.hnsw.M
        
        return stats


def main():
    """Test the dense retriever."""
    # Sample data
    sample_chunks = {
        "url1": [
            {
                'chunk_id': 'chunk_1',
                'text': 'Artificial intelligence is a branch of computer science.',
                'title': 'AI Article',
                'chunk_index': 0,
                'token_count': 10,
                'keywords': ['artificial', 'intelligence']
            },
            {
                'chunk_id': 'chunk_2', 
                'text': 'Machine learning is a subset of artificial intelligence.',
                'title': 'AI Article',
                'chunk_index': 1,
                'token_count': 9,
                'keywords': ['machine', 'learning']
            }
        ]
    }
    
    # Test retriever
    retriever = DenseRetriever()
    retriever.build_index(sample_chunks)
    
    # Search
    results = retriever.search("What is AI?", top_k=2)
    
    print("Search Results:")
    for i, result in enumerate(results):
        print(f"{i+1}. {result['title']}: {result['text'][:50]}...")
        print(f"   Score: {result['similarity_score']:.3f}")


if __name__ == "__main__":
    main()