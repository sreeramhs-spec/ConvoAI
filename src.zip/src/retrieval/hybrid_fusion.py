"""
Hybrid fusion using Reciprocal Rank Fusion (RRF).

This module implements the combination of dense and sparse retrieval results using:
- Reciprocal Rank Fusion algorithm
- Score normalization and combination
- Deduplication of results
- Configurable fusion parameters
"""

import math
from collections import defaultdict
from typing import Dict, List, Optional, Set, Tuple, Union

import numpy as np


class HybridFusion:
    """Combines dense and sparse retrieval results using RRF."""
    
    def __init__(self, 
                 k: int = 60,
                 alpha: float = 0.5,
                 normalize_scores: bool = True,
                 deduplicate: bool = True):
        """
        Initialize the hybrid fusion component.
        
        Args:
            k: RRF parameter (typically 60)
            alpha: Weight for combining normalized scores (0.0 = sparse only, 1.0 = dense only)
            normalize_scores: Whether to normalize scores before fusion
            deduplicate: Whether to remove duplicate chunks
        """
        self.k = k
        self.alpha = alpha
        self.normalize_scores = normalize_scores
        self.deduplicate = deduplicate
        
        print(f"Hybrid fusion initialized with k={k}, alpha={alpha}")
    
    def reciprocal_rank_fusion(self, 
                              ranked_lists: List[List[Dict]],
                              top_k: Optional[int] = None) -> List[Dict]:
        """
        Apply Reciprocal Rank Fusion to combine multiple ranked lists.
        
        Args:
            ranked_lists: List of ranked result lists from different retrievers
            top_k: Number of top results to return
            
        Returns:
            Fused and re-ranked results
        """
        # Collect all unique documents and their RRF scores
        doc_scores = defaultdict(float)
        doc_data = {}  # Store document metadata
        
        for rank_list in ranked_lists:
            for rank, doc in enumerate(rank_list, 1):
                chunk_id = doc['chunk_id']
                
                # Calculate RRF score: 1 / (k + rank)
                rrf_score = 1.0 / (self.k + rank)
                doc_scores[chunk_id] += rrf_score
                
                # Store document data (prefer first occurrence)
                if chunk_id not in doc_data:
                    doc_data[chunk_id] = doc.copy()
        
        # Sort by RRF score
        sorted_docs = sorted(doc_scores.items(), 
                           key=lambda x: x[1], 
                           reverse=True)
        
        # Prepare results
        results = []
        for chunk_id, rrf_score in sorted_docs:
            doc = doc_data[chunk_id].copy()
            doc['rrf_score'] = rrf_score
            doc['retrieval_method'] = 'hybrid_rrf'
            results.append(doc)
        
        # Return top-k if specified
        if top_k is not None:
            results = results[:top_k]
        
        return results
    
    def fuse_results(self,
                    dense_results: List[Dict],
                    sparse_results: List[Dict],
                    top_k: int = 10,
                    fusion_method: str = 'rrf') -> List[Dict]:
        """
        Fuse dense and sparse retrieval results.
        
        Args:
            dense_results: Results from dense retrieval
            sparse_results: Results from sparse retrieval
            top_k: Number of final results to return
            fusion_method: Fusion method ('rrf', 'score_fusion', 'rank_fusion')
            
        Returns:
            Fused results
        """
        if fusion_method == 'rrf':
            return self._rrf_fusion(dense_results, sparse_results, top_k)
        elif fusion_method == 'score_fusion':
            return self._score_fusion(dense_results, sparse_results, top_k)
        elif fusion_method == 'rank_fusion':
            return self._rank_fusion(dense_results, sparse_results, top_k)
        else:
            raise ValueError(f"Unknown fusion method: {fusion_method}")
    
    def _rrf_fusion(self,
                   dense_results: List[Dict],
                   sparse_results: List[Dict],
                   top_k: int) -> List[Dict]:
        """Apply RRF fusion to dense and sparse results."""
        # Use the main RRF method
        return self.reciprocal_rank_fusion([dense_results, sparse_results], top_k)
    
    def _score_fusion(self,
                     dense_results: List[Dict],
                     sparse_results: List[Dict],
                     top_k: int) -> List[Dict]:
        """
        Fuse results using normalized score combination.
        
        This method normalizes scores from both retrievers and combines them
        using a weighted average.
        """
        # Normalize scores
        if self.normalize_scores:
            dense_results = self._normalize_scores(dense_results, 'similarity_score')
            sparse_results = self._normalize_scores(sparse_results, 'bm25_score')
        
        # Combine results
        combined_scores = {}
        all_docs = {}
        
        # Process dense results
        for doc in dense_results:
            chunk_id = doc['chunk_id']
            dense_score = doc.get('similarity_score', 0.0)
            
            combined_scores[chunk_id] = {
                'dense_score': dense_score,
                'sparse_score': 0.0
            }
            all_docs[chunk_id] = doc
        
        # Process sparse results
        for doc in sparse_results:
            chunk_id = doc['chunk_id']
            sparse_score = doc.get('bm25_score', 0.0)
            
            if chunk_id in combined_scores:
                combined_scores[chunk_id]['sparse_score'] = sparse_score
            else:
                combined_scores[chunk_id] = {
                    'dense_score': 0.0,
                    'sparse_score': sparse_score
                }
                all_docs[chunk_id] = doc
        
        # Calculate combined scores
        final_scores = []
        for chunk_id, scores in combined_scores.items():
            combined_score = (self.alpha * scores['dense_score'] + 
                            (1 - self.alpha) * scores['sparse_score'])
            final_scores.append((chunk_id, combined_score, scores))
        
        # Sort by combined score
        final_scores.sort(key=lambda x: x[1], reverse=True)
        
        # Prepare results
        results = []
        for chunk_id, combined_score, individual_scores in final_scores[:top_k]:
            doc = all_docs[chunk_id].copy()
            doc['combined_score'] = combined_score
            doc['dense_score'] = individual_scores['dense_score']
            doc['sparse_score'] = individual_scores['sparse_score']
            doc['retrieval_method'] = 'hybrid_score'
            results.append(doc)
        
        return results
    
    def _rank_fusion(self,
                    dense_results: List[Dict],
                    sparse_results: List[Dict],
                    top_k: int) -> List[Dict]:
        """
        Fuse results using rank-based combination.
        
        This method assigns scores based on ranks in each retrieval method.
        """
        # Create rank mappings
        dense_ranks = {doc['chunk_id']: rank + 1 
                      for rank, doc in enumerate(dense_results)}
        sparse_ranks = {doc['chunk_id']: rank + 1 
                       for rank, doc in enumerate(sparse_results)}
        
        # Get all unique documents
        all_chunk_ids = set(dense_ranks.keys()) | set(sparse_ranks.keys())
        all_docs = {}
        
        for doc in dense_results + sparse_results:
            chunk_id = doc['chunk_id']
            if chunk_id not in all_docs:
                all_docs[chunk_id] = doc
        
        # Calculate rank-based scores
        scored_docs = []
        max_dense_rank = len(dense_results)
        max_sparse_rank = len(sparse_results)
        
        for chunk_id in all_chunk_ids:
            dense_rank = dense_ranks.get(chunk_id, max_dense_rank + 1)
            sparse_rank = sparse_ranks.get(chunk_id, max_sparse_rank + 1)
            
            # Convert ranks to scores (lower rank = higher score)
            dense_score = 1.0 / dense_rank
            sparse_score = 1.0 / sparse_rank
            
            combined_score = self.alpha * dense_score + (1 - self.alpha) * sparse_score
            scored_docs.append((chunk_id, combined_score, dense_rank, sparse_rank))
        
        # Sort by combined score
        scored_docs.sort(key=lambda x: x[1], reverse=True)
        
        # Prepare results
        results = []
        for chunk_id, combined_score, dense_rank, sparse_rank in scored_docs[:top_k]:
            doc = all_docs[chunk_id].copy()
            doc['combined_score'] = combined_score
            doc['dense_rank'] = dense_rank
            doc['sparse_rank'] = sparse_rank
            doc['retrieval_method'] = 'hybrid_rank'
            results.append(doc)
        
        return results
    
    def _normalize_scores(self, 
                         results: List[Dict], 
                         score_key: str) -> List[Dict]:
        """Normalize scores to [0, 1] range."""
        if not results:
            return results
        
        scores = [doc.get(score_key, 0.0) for doc in results]
        min_score = min(scores)
        max_score = max(scores)
        
        # Avoid division by zero
        if max_score == min_score:
            normalized_results = []
            for doc in results:
                new_doc = doc.copy()
                new_doc[f'normalized_{score_key}'] = 1.0
                normalized_results.append(new_doc)
            return normalized_results
        
        # Min-max normalization
        normalized_results = []
        for doc in results:
            new_doc = doc.copy()
            original_score = doc.get(score_key, 0.0)
            normalized_score = (original_score - min_score) / (max_score - min_score)
            new_doc[f'normalized_{score_key}'] = normalized_score
            new_doc[score_key] = normalized_score  # Replace original score
            normalized_results.append(new_doc)
        
        return normalized_results
    
    def analyze_fusion_results(self,
                             dense_results: List[Dict],
                             sparse_results: List[Dict],
                             fused_results: List[Dict]) -> Dict:
        """
        Analyze the fusion results to understand the contribution of each method.
        
        Args:
            dense_results: Original dense results
            sparse_results: Original sparse results 
            fused_results: Final fused results
            
        Returns:
            Analysis dictionary with various statistics
        """
        # Create sets of chunk IDs for analysis
        dense_ids = set(doc['chunk_id'] for doc in dense_results)
        sparse_ids = set(doc['chunk_id'] for doc in sparse_results)
        fused_ids = set(doc['chunk_id'] for doc in fused_results)
        
        analysis = {
            'input_stats': {
                'dense_count': len(dense_results),
                'sparse_count': len(sparse_results),
                'dense_unique': len(dense_ids),
                'sparse_unique': len(sparse_ids),
                'overlap': len(dense_ids & sparse_ids),
                'total_unique': len(dense_ids | sparse_ids)
            },
            'fusion_stats': {
                'fused_count': len(fused_results),
                'from_dense_only': len(fused_ids & dense_ids - sparse_ids),
                'from_sparse_only': len(fused_ids & sparse_ids - dense_ids),
                'from_both': len(fused_ids & dense_ids & sparse_ids),
            }
        }
        
        # Calculate contribution percentages
        total_fused = len(fused_results)
        if total_fused > 0:
            analysis['contribution_percentages'] = {
                'dense_only': analysis['fusion_stats']['from_dense_only'] / total_fused * 100,
                'sparse_only': analysis['fusion_stats']['from_sparse_only'] / total_fused * 100,
                'both_methods': analysis['fusion_stats']['from_both'] / total_fused * 100
            }
        
        # Rank correlation analysis
        analysis['rank_correlations'] = self._calculate_rank_correlations(
            dense_results, sparse_results, fused_results
        )
        
        return analysis
    
    def _calculate_rank_correlations(self,
                                   dense_results: List[Dict],
                                   sparse_results: List[Dict],
                                   fused_results: List[Dict]) -> Dict:
        """Calculate rank correlations between different methods."""
        # Create rank mappings
        dense_ranks = {doc['chunk_id']: i for i, doc in enumerate(dense_results)}
        sparse_ranks = {doc['chunk_id']: i for i, doc in enumerate(sparse_results)}
        fused_ranks = {doc['chunk_id']: i for i, doc in enumerate(fused_results)}
        
        # Find common documents for correlation calculation
        common_dense_fused = set(dense_ranks.keys()) & set(fused_ranks.keys())
        common_sparse_fused = set(sparse_ranks.keys()) & set(fused_ranks.keys())
        common_all = set(dense_ranks.keys()) & set(sparse_ranks.keys()) & set(fused_ranks.keys())
        
        correlations = {}
        
        # Calculate Spearman correlation (simplified)
        if len(common_dense_fused) > 1:
            dense_fused_corr = self._spearman_correlation(
                [dense_ranks[cid] for cid in common_dense_fused],
                [fused_ranks[cid] for cid in common_dense_fused]
            )
            correlations['dense_vs_fused'] = dense_fused_corr
        
        if len(common_sparse_fused) > 1:
            sparse_fused_corr = self._spearman_correlation(
                [sparse_ranks[cid] for cid in common_sparse_fused],
                [fused_ranks[cid] for cid in common_sparse_fused]
            )
            correlations['sparse_vs_fused'] = sparse_fused_corr
        
        if len(common_all) > 1:
            dense_sparse_corr = self._spearman_correlation(
                [dense_ranks[cid] for cid in common_all],
                [sparse_ranks[cid] for cid in common_all]
            )
            correlations['dense_vs_sparse'] = dense_sparse_corr
        
        return correlations
    
    def _spearman_correlation(self, x: List[float], y: List[float]) -> float:
        """Calculate Spearman rank correlation coefficient."""
        n = len(x)
        if n < 2:
            return 0.0
        
        # Convert to ranks
        x_ranks = self._get_ranks(x)
        y_ranks = self._get_ranks(y)
        
        # Calculate correlation
        x_mean = sum(x_ranks) / n
        y_mean = sum(y_ranks) / n
        
        numerator = sum((x_ranks[i] - x_mean) * (y_ranks[i] - y_mean) for i in range(n))
        
        x_var = sum((x_ranks[i] - x_mean) ** 2 for i in range(n))
        y_var = sum((y_ranks[i] - y_mean) ** 2 for i in range(n))
        
        denominator = math.sqrt(x_var * y_var)
        
        if denominator == 0:
            return 0.0
        
        return numerator / denominator
    
    def _get_ranks(self, values: List[float]) -> List[float]:
        """Convert values to ranks."""
        sorted_indices = sorted(range(len(values)), key=lambda i: values[i])
        ranks = [0] * len(values)
        
        for rank, idx in enumerate(sorted_indices):
            ranks[idx] = rank + 1
        
        return ranks
    
    def get_fusion_stats(self) -> Dict:
        """Get statistics about the fusion configuration."""
        return {
            'rrf_k': self.k,
            'alpha': self.alpha,
            'normalize_scores': self.normalize_scores,
            'deduplicate': self.deduplicate
        }


def main():
    """Test the hybrid fusion component."""
    # Sample results
    dense_results = [
        {'chunk_id': 'chunk_1', 'text': 'AI is important', 'similarity_score': 0.9},
        {'chunk_id': 'chunk_2', 'text': 'ML is subset', 'similarity_score': 0.8},
        {'chunk_id': 'chunk_3', 'text': 'Data science', 'similarity_score': 0.7}
    ]
    
    sparse_results = [
        {'chunk_id': 'chunk_2', 'text': 'ML is subset', 'bm25_score': 5.2},
        {'chunk_id': 'chunk_4', 'text': 'Statistics matter', 'bm25_score': 4.1},
        {'chunk_id': 'chunk_1', 'text': 'AI is important', 'bm25_score': 3.8}
    ]
    
    # Test fusion
    fusion = HybridFusion()
    
    # RRF fusion
    rrf_results = fusion.fuse_results(dense_results, sparse_results, 
                                     top_k=3, fusion_method='rrf')
    
    print("RRF Fusion Results:")
    for i, result in enumerate(rrf_results):
        print(f"{i+1}. {result['text']} (RRF: {result['rrf_score']:.3f})")
    
    # Score fusion
    score_results = fusion.fuse_results(dense_results, sparse_results,
                                       top_k=3, fusion_method='score_fusion')
    
    print("\nScore Fusion Results:")
    for i, result in enumerate(score_results):
        print(f"{i+1}. {result['text']} (Combined: {result['combined_score']:.3f})")
    
    # Analysis
    analysis = fusion.analyze_fusion_results(dense_results, sparse_results, rrf_results)
    print(f"\nFusion Analysis: {analysis}")


if __name__ == "__main__":
    main()