"""
Sparse keyword retrieval using BM25 algorithm.

This module implements sparse retrieval using:
- BM25 algorithm for keyword matching
- TF-IDF weighting with document frequency
- Advanced text preprocessing and tokenization
- Support for custom parameters (k1, b)
"""

import json
import math
import pickle
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import nltk
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize
from rank_bm25 import BM25Okapi
from tqdm import tqdm


class SparseRetriever:
    """Sparse retrieval using BM25 algorithm."""
    
    def __init__(self,
                 k1: float = 1.5,
                 b: float = 0.75,
                 use_stemming: bool = True,
                 remove_stopwords: bool = True,
                 min_term_freq: int = 1):
        """
        Initialize the sparse retriever.
        
        Args:
            k1: BM25 parameter controlling term frequency saturation
            b: BM25 parameter controlling length normalization
            use_stemming: Whether to apply stemming to terms
            remove_stopwords: Whether to remove stopwords
            min_term_freq: Minimum term frequency to include in index
        """
        self.k1 = k1
        self.b = b
        self.use_stemming = use_stemming
        self.remove_stopwords = remove_stopwords
        self.min_term_freq = min_term_freq
        
        # Initialize NLP components
        self._initialize_nlp()
        
        # BM25 components
        self.bm25 = None
        self.tokenized_corpus = []
        self.chunk_ids = []
        self.chunk_metadata = {}
        self.vocabulary = set()
        self.term_frequencies = Counter()
        
        print("Sparse retriever initialized with BM25")
    
    def _initialize_nlp(self):
        """Initialize NLTK components."""
        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('punkt')
            
        try:
            nltk.data.find('corpora/stopwords')
        except LookupError:
            nltk.download('stopwords')
        
        # Initialize stemmer
        self.stemmer = PorterStemmer() if self.use_stemming else None
        
        # Initialize stopwords
        if self.remove_stopwords:
            self.stop_words = set(stopwords.words('english'))
            # Add common terms that might not be useful for retrieval
            self.stop_words.update([
                'would', 'could', 'should', 'might', 'must', 'shall',
                'wikipedia', 'article', 'page', 'section', 'see', 'also'
            ])
        else:
            self.stop_words = set()
    
    def preprocess_text(self, text: str) -> List[str]:
        """
        Preprocess text for BM25 indexing.
        
        Args:
            text: Input text
            
        Returns:
            List of processed tokens
        """
        # Convert to lowercase and tokenize
        tokens = word_tokenize(text.lower())
        
        # Filter tokens
        processed_tokens = []
        for token in tokens:
            # Keep only alphabetic tokens
            if not token.isalpha():
                continue
            
            # Remove stopwords
            if self.remove_stopwords and token in self.stop_words:
                continue
            
            # Apply stemming
            if self.use_stemming and self.stemmer:
                token = self.stemmer.stem(token)
            
            # Filter very short tokens
            if len(token) < 2:
                continue
                
            processed_tokens.append(token)
        
        return processed_tokens
    
    def build_index(self,
                   chunks: Dict[str, List[Dict]],
                   save_path: Optional[str] = None) -> None:
        """
        Build BM25 index from text chunks.
        
        Args:
            chunks: Dictionary of chunks from text processing
            save_path: Path to save the index
        """
        print("Building BM25 sparse index...")
        
        # Prepare data
        all_texts = []
        all_chunk_ids = []
        chunk_metadata = {}
        
        for url, chunk_list in chunks.items():
            for chunk in chunk_list:
                all_texts.append(chunk['text'])
                chunk_id = chunk['chunk_id']
                all_chunk_ids.append(chunk_id)
                
                # Store metadata
                chunk_metadata[chunk_id] = {
                    'url': url,
                    'title': chunk['title'],
                    'chunk_index': chunk['chunk_index'],
                    'text': chunk['text'],
                    'token_count': chunk['token_count'],
                    'keywords': chunk.get('keywords', [])
                }
        
        print(f"Preprocessing {len(all_texts)} text chunks...")
        
        # Preprocess all texts
        tokenized_corpus = []
        all_terms = []
        
        for text in tqdm(all_texts, desc="Preprocessing texts"):
            tokens = self.preprocess_text(text)
            tokenized_corpus.append(tokens)
            all_terms.extend(tokens)
        
        # Build vocabulary and term frequencies
        self.term_frequencies = Counter(all_terms)
        
        # Filter rare terms if specified
        if self.min_term_freq > 1:
            filtered_corpus = []
            valid_terms = set(term for term, freq in self.term_frequencies.items() 
                            if freq >= self.min_term_freq)
            
            for tokens in tokenized_corpus:
                filtered_tokens = [token for token in tokens if token in valid_terms]
                filtered_corpus.append(filtered_tokens)
            
            tokenized_corpus = filtered_corpus
            self.vocabulary = valid_terms
        else:
            self.vocabulary = set(self.term_frequencies.keys())
        
        print(f"Built vocabulary with {len(self.vocabulary)} unique terms")
        
        # Create BM25 index
        print("Creating BM25 index...")
        self.bm25 = BM25Okapi(tokenized_corpus, k1=self.k1, b=self.b)
        
        # Store metadata
        self.tokenized_corpus = tokenized_corpus
        self.chunk_ids = all_chunk_ids
        self.chunk_metadata = chunk_metadata
        
        print(f"BM25 index built successfully with {len(self.chunk_ids)} documents")
        
        # Save index if path provided
        if save_path:
            self.save_index(save_path)
    
    def save_index(self, save_path: str) -> None:
        """Save BM25 index and metadata to disk."""
        save_path = Path(save_path)
        save_path.mkdir(parents=True, exist_ok=True)
        
        # Save BM25 model
        with open(save_path / "bm25_model.pkl", 'wb') as f:
            pickle.dump(self.bm25, f)
        
        # Save tokenized corpus
        with open(save_path / "tokenized_corpus.pkl", 'wb') as f:
            pickle.dump(self.tokenized_corpus, f)
        
        # Save metadata
        metadata = {
            'k1': self.k1,
            'b': self.b,
            'use_stemming': self.use_stemming,
            'remove_stopwords': self.remove_stopwords,
            'min_term_freq': self.min_term_freq,
            'chunk_ids': self.chunk_ids,
            'vocabulary_size': len(self.vocabulary),
            'total_chunks': len(self.chunk_ids)
        }
        
        with open(save_path / "sparse_metadata.json", 'w') as f:
            json.dump(metadata, f, indent=2)
        
        # Save chunk metadata
        with open(save_path / "chunk_metadata.pkl", 'wb') as f:
            pickle.dump(self.chunk_metadata, f)
        
        # Save vocabulary and term frequencies
        with open(save_path / "vocabulary.json", 'w') as f:
            json.dump({
                'vocabulary': list(self.vocabulary),
                'term_frequencies': dict(self.term_frequencies.most_common(1000))  # Top 1000 terms
            }, f, indent=2)
        
        print(f"BM25 index saved to {save_path}")
    
    def load_index(self, load_path: str) -> None:
        """Load BM25 index and metadata from disk."""
        load_path = Path(load_path)
        
        # Load BM25 model
        with open(load_path / "bm25_model.pkl", 'rb') as f:
            self.bm25 = pickle.load(f)
        
        # Load tokenized corpus
        with open(load_path / "tokenized_corpus.pkl", 'rb') as f:
            self.tokenized_corpus = pickle.load(f)
        
        # Load metadata
        with open(load_path / "sparse_metadata.json", 'r') as f:
            metadata = json.load(f)
        
        self.chunk_ids = metadata['chunk_ids']
        
        # Load chunk metadata
        with open(load_path / "chunk_metadata.pkl", 'rb') as f:
            self.chunk_metadata = pickle.load(f)
        
        # Load vocabulary
        with open(load_path / "vocabulary.json", 'r') as f:
            vocab_data = json.load(f)
            self.vocabulary = set(vocab_data['vocabulary'])
            # Reconstruct term frequencies (partial)
            self.term_frequencies = Counter(vocab_data['term_frequencies'])
        
        print(f"BM25 index loaded from {load_path}")
        print(f"Index contains {len(self.chunk_ids)} chunks with {len(self.vocabulary)} terms")
    
    def search(self,
              query: str,
              top_k: int = 20,
              return_scores: bool = True) -> List[Dict]:
        """
        Search for relevant chunks using BM25.
        
        Args:
            query: Query text
            top_k: Number of top results to return
            return_scores: Whether to include BM25 scores
            
        Returns:
            List of retrieved chunks with metadata
        """
        if self.bm25 is None:
            raise ValueError("Index not built or loaded. Call build_index() or load_index() first.")
        
        # Preprocess query
        query_tokens = self.preprocess_text(query)
        
        if not query_tokens:
            return []
        
        # Get BM25 scores
        scores = self.bm25.get_scores(query_tokens)
        
        # Get top-k results
        top_indices = scores.argsort()[-top_k:][::-1]
        
        # Prepare results
        results = []
        for idx in top_indices:
            if idx >= len(self.chunk_ids):
                continue
                
            chunk_id = self.chunk_ids[idx]
            chunk_data = self.chunk_metadata[chunk_id].copy()
            
            if return_scores:
                chunk_data['bm25_score'] = float(scores[idx])
            
            chunk_data['retrieval_method'] = 'sparse'
            chunk_data['matched_terms'] = self._get_matched_terms(query_tokens, idx)
            
            results.append(chunk_data)
        
        return results
    
    def _get_matched_terms(self, query_tokens: List[str], doc_idx: int) -> List[str]:
        """Get terms that matched between query and document."""
        if doc_idx >= len(self.tokenized_corpus):
            return []
        
        doc_tokens = set(self.tokenized_corpus[doc_idx])
        matched = [token for token in query_tokens if token in doc_tokens]
        
        return matched
    
    def batch_search(self,
                    queries: List[str],
                    top_k: int = 20) -> List[List[Dict]]:
        """
        Perform batch search for multiple queries.
        
        Args:
            queries: List of query texts
            top_k: Number of top results per query
            
        Returns:
            List of result lists, one per query
        """
        all_results = []
        
        for query in tqdm(queries, desc="BM25 batch search"):
            results = self.search(query, top_k=top_k)
            all_results.append(results)
        
        return all_results
    
    def explain_score(self, query: str, chunk_id: str) -> Dict:
        """
        Explain BM25 score for a specific query-document pair.
        
        Args:
            query: Query text
            chunk_id: Chunk ID to explain
            
        Returns:
            Dictionary with score explanation
        """
        if chunk_id not in self.chunk_metadata:
            return {}
        
        # Find document index
        try:
            doc_idx = self.chunk_ids.index(chunk_id)
        except ValueError:
            return {}
        
        query_tokens = self.preprocess_text(query)
        doc_tokens = self.tokenized_corpus[doc_idx]
        
        explanation = {
            'query_terms': query_tokens,
            'doc_terms': doc_tokens,
            'doc_length': len(doc_tokens),
            'avg_doc_length': self.bm25.avgdl,
            'term_contributions': {}
        }
        
        # Calculate contribution of each query term
        doc_freqs = Counter(doc_tokens)
        total_score = 0
        
        for term in query_tokens:
            if term in doc_freqs:
                tf = doc_freqs[term]
                # Simplified BM25 calculation for explanation
                idf = math.log((len(self.tokenized_corpus) + 1) / 
                              (sum(1 for doc in self.tokenized_corpus if term in doc) + 1))
                
                numerator = tf * (self.k1 + 1)
                denominator = tf + self.k1 * (1 - self.b + self.b * len(doc_tokens) / self.bm25.avgdl)
                
                term_score = idf * numerator / denominator
                total_score += term_score
                
                explanation['term_contributions'][term] = {
                    'tf': tf,
                    'idf': idf,
                    'score': term_score
                }
        
        explanation['total_score'] = total_score
        
        return explanation
    
    def get_term_statistics(self, terms: List[str]) -> Dict[str, Dict]:
        """Get statistics for specific terms."""
        stats = {}
        
        for term in terms:
            if term in self.vocabulary:
                # Count documents containing this term
                doc_freq = sum(1 for doc in self.tokenized_corpus if term in doc)
                total_freq = self.term_frequencies.get(term, 0)
                
                stats[term] = {
                    'document_frequency': doc_freq,
                    'total_frequency': total_freq,
                    'idf': math.log(len(self.tokenized_corpus) / (doc_freq + 1))
                }
            else:
                stats[term] = {
                    'document_frequency': 0,
                    'total_frequency': 0,
                    'idf': 0,
                    'note': 'Term not in vocabulary'
                }
        
        return stats
    
    def get_index_stats(self) -> Dict:
        """Get statistics about the current index."""
        if self.bm25 is None:
            return {}
        
        doc_lengths = [len(doc) for doc in self.tokenized_corpus]
        
        stats = {
            'total_documents': len(self.tokenized_corpus),
            'vocabulary_size': len(self.vocabulary),
            'avg_document_length': self.bm25.avgdl,
            'min_document_length': min(doc_lengths) if doc_lengths else 0,
            'max_document_length': max(doc_lengths) if doc_lengths else 0,
            'total_terms': sum(len(doc) for doc in self.tokenized_corpus),
            'bm25_parameters': {
                'k1': self.k1,
                'b': self.b
            },
            'preprocessing': {
                'use_stemming': self.use_stemming,
                'remove_stopwords': self.remove_stopwords,
                'min_term_freq': self.min_term_freq
            }
        }
        
        # Top terms by frequency
        stats['top_terms'] = dict(self.term_frequencies.most_common(20))
        
        return stats


def main():
    """Test the sparse retriever."""
    # Sample data
    sample_chunks = {
        "url1": [
            {
                'chunk_id': 'chunk_1',
                'text': 'Artificial intelligence is a branch of computer science that deals with intelligent machines.',
                'title': 'AI Article',
                'chunk_index': 0,
                'token_count': 14,
                'keywords': ['artificial', 'intelligence']
            },
            {
                'chunk_id': 'chunk_2',
                'text': 'Machine learning is a subset of artificial intelligence focused on learning from data.',
                'title': 'ML Article', 
                'chunk_index': 1,
                'token_count': 13,
                'keywords': ['machine', 'learning']
            }
        ]
    }
    
    # Test retriever
    retriever = SparseRetriever()
    retriever.build_index(sample_chunks)
    
    # Search
    results = retriever.search("What is artificial intelligence?", top_k=2)
    
    print("BM25 Search Results:")
    for i, result in enumerate(results):
        print(f"{i+1}. {result['title']}: {result['text'][:50]}...")
        print(f"   BM25 Score: {result['bm25_score']:.3f}")
        print(f"   Matched Terms: {result['matched_terms']}")
    
    # Get index stats
    stats = retriever.get_index_stats()
    print(f"\nIndex Stats: {stats['total_documents']} docs, {stats['vocabulary_size']} terms")


if __name__ == "__main__":
    main()