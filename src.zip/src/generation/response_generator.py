"""
Response generation using transformer-based language models.

This module implements answer generation using:
- HuggingFace transformer models
- Context-aware prompt engineering
- Multiple generation strategies
- Response quality assessment
"""

import ssl
import os

# Configure SSL certificates using certifi
try:
    import certifi
    os.environ['SSL_CERT_FILE'] = certifi.where()
    os.environ['REQUESTS_CA_BUNDLE'] = certifi.where()
    os.environ['CURL_CA_BUNDLE'] = certifi.where()
except ImportError:
    # Fallback: disable SSL verification if certifi not available
    try:
        ssl._create_default_https_context = ssl._create_unverified_context
    except AttributeError:
        pass

import re
import time
from typing import Dict, List, Optional, Tuple, Union

import torch
from transformers import (
    AutoModelForCausalLM, AutoModelForSeq2SeqLM, 
    AutoTokenizer, GenerationConfig,
    pipeline, set_seed
)


class ResponseGenerator:
    """Generates responses using transformer-based language models."""
    
    def __init__(self,
                 model_name: str = "microsoft/DialoGPT-medium",
                 model_type: str = "causal",
                 device: str = "auto",
                 max_length: int = 512,
                 temperature: float = 0.7,
                 do_sample: bool = True):
        """
        Initialize the response generator.
        
        Args:
            model_name: HuggingFace model name
            model_type: Type of model ('causal', 'seq2seq', 'pipeline')
            device: Device to use ('cpu', 'cuda', 'auto')
            max_length: Maximum response length in tokens
            temperature: Sampling temperature
            do_sample: Whether to use sampling
        """
        self.model_name = model_name
        self.model_type = model_type
        self.max_length = max_length
        self.temperature = temperature
        self.do_sample = do_sample
        
        # Set device
        if device == "auto":
            self.device = "cuda" if torch.cuda.is_available() else "cpu"
        else:
            self.device = device
        
        print(f"Initializing response generator with {model_name} on {self.device}")
        
        # Initialize model and tokenizer
        self._initialize_model()
        
        print("Response generator initialized successfully")
    
    def _initialize_model(self):
        """Initialize the model and tokenizer based on model type."""
        try:
            # Load tokenizer
            self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
            
            # Add padding token if missing
            if self.tokenizer.pad_token is None:
                if self.tokenizer.eos_token:
                    self.tokenizer.pad_token = self.tokenizer.eos_token
                else:
                    self.tokenizer.add_special_tokens({'pad_token': '[PAD]'})
            
            if self.model_type == "pipeline":
                # Use HuggingFace pipeline for simplicity
                self.pipeline = pipeline(
                    "text-generation",
                    model=self.model_name,
                    tokenizer=self.tokenizer,
                    device=0 if self.device == "cuda" else -1,
                    torch_dtype=torch.float16 if self.device == "cuda" else torch.float32
                )
                self.model = None
                
            elif self.model_type == "causal":
                # Causal language model (GPT-style)
                self.model = AutoModelForCausalLM.from_pretrained(
                    self.model_name,
                    torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                    device_map="auto" if self.device == "cuda" else None
                )
                if self.device != "cuda":
                    self.model = self.model.to(self.device)
                self.pipeline = None
                
            elif self.model_type == "seq2seq":
                # Sequence-to-sequence model (T5, BART)
                self.model = AutoModelForSeq2SeqLM.from_pretrained(
                    self.model_name,
                    torch_dtype=torch.float16 if self.device == "cuda" else torch.float32,
                    device_map="auto" if self.device == "cuda" else None
                )
                if self.device != "cuda":
                    self.model = self.model.to(self.device)
                self.pipeline = None
                
            else:
                raise ValueError(f"Unsupported model type: {self.model_type}")
            
            # Set up generation config
            if self.model is not None:
                self.generation_config = GenerationConfig.from_pretrained(
                    self.model_name,
                    do_sample=self.do_sample,
                    temperature=self.temperature,
                    max_length=self.max_length,
                    pad_token_id=self.tokenizer.pad_token_id,
                    eos_token_id=self.tokenizer.eos_token_id,
                )
                
        except Exception as e:
            print(f"Error initializing model {self.model_name}: {e}")
            # Fallback to a smaller, more reliable model
            print("Falling back to distilgpt2...")
            self.model_name = "distilgpt2"
            self.model_type = "causal"
            self._initialize_fallback_model()
    
    def _initialize_fallback_model(self):
        """Initialize a fallback model if the primary model fails."""
        self.tokenizer = AutoTokenizer.from_pretrained(self.model_name)
        if self.tokenizer.pad_token is None:
            self.tokenizer.pad_token = self.tokenizer.eos_token
            
        self.model = AutoModelForCausalLM.from_pretrained(self.model_name)
        self.model = self.model.to(self.device)
        
        self.generation_config = GenerationConfig(
            do_sample=self.do_sample,
            temperature=self.temperature,
            max_length=self.max_length,
            pad_token_id=self.tokenizer.pad_token_id,
            eos_token_id=self.tokenizer.eos_token_id,
        )
    
    def check_retrieval_relevance(self,
                                 query: str,
                                 retrieved_chunks: List[Dict],
                                 min_score_threshold: float = 0.3) -> Tuple[bool, float]:
        """
        Check if retrieved chunks are relevant enough to answer the query.
        
        Args:
            query: User query
            retrieved_chunks: Retrieved chunks with scores
            min_score_threshold: Minimum average score threshold
            
        Returns:
            Tuple of (is_relevant, avg_score)
        """
        if not retrieved_chunks:
            return False, 0.0
        
        # Check scores
        scores = [chunk.get('score', 0.0) for chunk in retrieved_chunks[:5]]
        avg_score = sum(scores) / len(scores) if scores else 0.0
        
        # Check keyword overlap
        query_terms = set(query.lower().split())
        context_text = " ".join([chunk.get('text', '').lower() for chunk in retrieved_chunks[:3]])
        context_terms = set(context_text.split())
        
        overlap_ratio = len(query_terms & context_terms) / len(query_terms) if query_terms else 0.0
        
        # Consider relevant if:
        # 1. Average score is above threshold OR
        # 2. Good keyword overlap (>30%)
        is_relevant = avg_score >= min_score_threshold or overlap_ratio >= 0.3
        
        return is_relevant, avg_score
    
    def create_prompt(self,
                     query: str,
                     retrieved_chunks: List[Dict],
                     prompt_template: str = "qa") -> str:
        """
        Create a prompt for response generation.
        
        Args:
            query: User query
            retrieved_chunks: List of retrieved chunks with context
            prompt_template: Template type ('qa', 'chat', 'instruct')
            
        Returns:
            Formatted prompt string
        """
        # Extract context from chunks
        context_parts = []
        for i, chunk in enumerate(retrieved_chunks[:5]):  # Use top 5 chunks
            title = chunk.get('title', 'Unknown')
            text = chunk.get('text', '')
            url = chunk.get('url', '')
            score = chunk.get('score', 0.0)
            
            # Clean and truncate text
            text = self._clean_text(text)[:300]  # Limit context length
            
            context_parts.append(f"Source {i+1} - {title} (relevance: {score:.3f}):\n{text}\n")
        
        context = "\n".join(context_parts)
        
        # Generate prompt based on template
        if prompt_template == "qa":
            prompt = f"""Context information:
{context}

Question: {query}

Based on the provided context, please provide a comprehensive answer to the question. If the context doesn't contain enough information to answer the question, please say so.

Answer:"""
        
        elif prompt_template == "chat":
            prompt = f"""You are a helpful assistant that answers questions based on provided context.

Context:
{context}

User: {query}
Assistant:"""
        
        elif prompt_template == "instruct":
            prompt = f"""### Instruction:
Answer the following question using only the provided context. Be accurate and concise.

### Context:
{context}

### Question:
{query}

### Response:"""
        
        else:
            # Default template
            prompt = f"Context: {context}\n\nQuestion: {query}\n\nAnswer:"
        
        return prompt
    
    def _clean_text(self, text: str) -> str:
        """Clean text for prompt inclusion."""
        # Remove excessive whitespace
        text = re.sub(r'\s+', ' ', text)
        
        # Remove special characters that might confuse the model
        text = re.sub(r'[^\w\s\.\,\!\?\;\:\-\(\)\'\"]+', ' ', text)
        
        return text.strip()
    
    def generate_response(self,
                         query: str,
                         retrieved_chunks: List[Dict],
                         prompt_template: str = "qa",
                         max_new_tokens: Optional[int] = None,
                         num_return_sequences: int = 1,
                         min_relevance_threshold: float = 0.3) -> Dict:
        """
        Generate a response to the query using retrieved context.
        
        Args:
            query: User query
            retrieved_chunks: List of retrieved chunks with context
            prompt_template: Template type for prompt formatting
            max_new_tokens: Maximum new tokens to generate
            num_return_sequences: Number of response variants to generate
            min_relevance_threshold: Minimum relevance score to generate answer
            
        Returns:
            Dictionary with generated response and metadata
        """
        start_time = time.time()
        
        # Check if retrieved context is relevant enough
        is_relevant, avg_score = self.check_retrieval_relevance(
            query, retrieved_chunks, min_relevance_threshold
        )
        
        # If context is not relevant, return a "don't know" response
        if not is_relevant:
            no_info_response = (
                f"I apologize, but I don't have enough relevant information in my knowledge base "
                f"to answer your question about '{query}'. "
                f"My dataset focuses on technology, history, and science topics from Wikipedia. "
                f"The retrieved documents had an average relevance score of {avg_score:.3f}, "
                f"which is below the confidence threshold of {min_relevance_threshold:.3f}. "
                f"Please try asking about topics within my knowledge domain."
            )
            return {
                'query': query,
                'response': no_info_response,
                'all_responses': [no_info_response],
                'prompt': '',
                'generation_time': time.time() - start_time,
                'model_name': self.model_name,
                'prompt_template': prompt_template,
                'num_context_chunks': len(retrieved_chunks),
                'is_hallucination_prevented': True,
                'relevance_score': avg_score,
                'relevance_threshold': min_relevance_threshold,
                'context_sources': [
                    {'title': chunk.get('title', ''), 
                     'url': chunk.get('url', ''),
                     'score': chunk.get('score', 0.0)}
                    for chunk in retrieved_chunks[:5]
                ]
            }
        
        # Create prompt
        prompt = self.create_prompt(query, retrieved_chunks, prompt_template)
        
        # Check prompt length
        prompt_tokens = self.tokenizer.encode(prompt)
        if len(prompt_tokens) > self.max_length - 50:  # Reserve space for generation
            # Truncate prompt if too long
            max_prompt_length = self.max_length - 100
            prompt = self.tokenizer.decode(prompt_tokens[:max_prompt_length])
            print(f"Warning: Prompt truncated to {max_prompt_length} tokens")
        
        # Generate response
        if max_new_tokens is None:
            max_new_tokens = min(200, self.max_length - len(prompt_tokens))
        
        try:
            if self.pipeline:
                # Use pipeline
                outputs = self.pipeline(
                    prompt,
                    max_new_tokens=max_new_tokens,
                    num_return_sequences=num_return_sequences,
                    temperature=self.temperature,
                    do_sample=self.do_sample,
                    pad_token_id=self.tokenizer.pad_token_id,
                    eos_token_id=self.tokenizer.eos_token_id
                )
                
                generated_texts = [output['generated_text'] for output in outputs]
                
            else:
                # Use model directly
                inputs = self.tokenizer(prompt, return_tensors="pt", padding=True)
                inputs = inputs.to(self.device)
                
                with torch.no_grad():
                    outputs = self.model.generate(
                        **inputs,
                        max_new_tokens=max_new_tokens,
                        num_return_sequences=num_return_sequences,
                        temperature=self.temperature,
                        do_sample=self.do_sample,
                        pad_token_id=self.tokenizer.pad_token_id,
                        eos_token_id=self.tokenizer.eos_token_id
                    )
                
                generated_texts = [
                    self.tokenizer.decode(output, skip_special_tokens=True)
                    for output in outputs
                ]
            
            # Extract only the new generation (remove prompt)
            responses = []
            for text in generated_texts:
                # Remove the original prompt from the generated text
                if prompt in text:
                    response = text.replace(prompt, "").strip()
                else:
                    response = text.strip()
                
                # Clean up the response
                response = self._clean_response(response)
                responses.append(response)
            
            generation_time = time.time() - start_time
            
            # Prepare result
            result = {
                'query': query,
                'response': responses[0] if responses else "",
                'all_responses': responses,
                'prompt': prompt,
                'generation_time': generation_time,
                'model_name': self.model_name,
                'prompt_template': prompt_template,
                'num_context_chunks': len(retrieved_chunks),
                'is_hallucination_prevented': False,
                'relevance_score': avg_score,
                'relevance_threshold': min_relevance_threshold,
                'context_sources': [
                    {'title': chunk.get('title', ''), 
                     'url': chunk.get('url', ''),
                     'score': chunk.get('score', 0.0)}
                    for chunk in retrieved_chunks[:5]
                ]
            }
            
            return result
            
        except Exception as e:
            print(f"Error generating response: {e}")
            return {
                'query': query,
                'response': f"I apologize, but I encountered an error generating a response: {str(e)}",
                'all_responses': [],
                'prompt': prompt,
                'generation_time': time.time() - start_time,
                'model_name': self.model_name,
                'error': str(e)
            }
    
    def _clean_response(self, response: str) -> str:
        """Clean and post-process the generated response."""
        # Remove common generation artifacts
        response = response.strip()
        
        # Remove incomplete sentences at the end
        sentences = response.split('. ')
        if len(sentences) > 1 and len(sentences[-1]) < 10:
            response = '. '.join(sentences[:-1]) + '.'
        
        # Remove repetitive content
        response = self._remove_repetition(response)
        
        # Ensure proper capitalization
        if response and response[0].islower():
            response = response[0].upper() + response[1:]
        
        return response
    
    def _remove_repetition(self, text: str) -> str:
        """Remove repetitive sequences from text."""
        sentences = text.split('. ')
        unique_sentences = []
        
        for sentence in sentences:
            sentence = sentence.strip()
            if sentence and sentence not in unique_sentences:
                unique_sentences.append(sentence)
        
        return '. '.join(unique_sentences)
    
    def batch_generate(self,
                      queries: List[str],
                      retrieved_chunks_list: List[List[Dict]],
                      **kwargs) -> List[Dict]:
        """
        Generate responses for multiple queries in batch.
        
        Args:
            queries: List of queries
            retrieved_chunks_list: List of retrieved chunks for each query
            **kwargs: Additional arguments for generate_response
            
        Returns:
            List of response dictionaries
        """
        results = []
        
        for query, retrieved_chunks in zip(queries, retrieved_chunks_list):
            result = self.generate_response(query, retrieved_chunks, **kwargs)
            results.append(result)
        
        return results
    
    def evaluate_response_quality(self, response: str, query: str) -> Dict:
        """
        Evaluate the quality of a generated response.
        
        Args:
            response: Generated response
            query: Original query
            
        Returns:
            Dictionary with quality metrics
        """
        metrics = {}
        
        # Length metrics
        metrics['response_length'] = len(response)
        metrics['word_count'] = len(response.split())
        metrics['sentence_count'] = len([s for s in response.split('.') if s.strip()])
        
        # Basic quality checks
        metrics['has_content'] = len(response.strip()) > 0
        metrics['ends_properly'] = response.endswith(('.', '!', '?'))
        metrics['starts_capitalized'] = response and response[0].isupper()
        
        # Query relevance (simple keyword overlap)
        query_words = set(query.lower().split())
        response_words = set(response.lower().split())
        metrics['keyword_overlap'] = len(query_words & response_words) / len(query_words) if query_words else 0
        
        # Repetition check
        sentences = [s.strip() for s in response.split('.') if s.strip()]
        unique_sentences = set(sentences)
        metrics['repetition_ratio'] = (len(sentences) - len(unique_sentences)) / len(sentences) if sentences else 0
        
        # Overall quality score (simple heuristic)
        quality_score = 0
        quality_score += 1 if metrics['has_content'] else 0
        quality_score += 1 if metrics['ends_properly'] else 0
        quality_score += 1 if metrics['starts_capitalized'] else 0
        quality_score += 1 if metrics['keyword_overlap'] > 0.2 else 0
        quality_score += 1 if metrics['repetition_ratio'] < 0.2 else 0
        quality_score += 1 if 10 <= metrics['word_count'] <= 150 else 0
        
        metrics['quality_score'] = quality_score / 6  # Normalize to 0-1
        
        return metrics
    
    def get_model_info(self) -> Dict:
        """Get information about the current model."""
        return {
            'model_name': self.model_name,
            'model_type': self.model_type,
            'device': self.device,
            'max_length': self.max_length,
            'temperature': self.temperature,
            'do_sample': self.do_sample,
            'vocabulary_size': len(self.tokenizer) if self.tokenizer else None
        }


def main():
    """Test the response generator."""
    # Sample data
    sample_chunks = [
        {
            'chunk_id': 'chunk_1',
            'text': 'Artificial intelligence (AI) refers to the simulation of human intelligence in machines.',
            'title': 'Artificial Intelligence',
            'url': 'https://en.wikipedia.org/wiki/Artificial_intelligence'
        },
        {
            'chunk_id': 'chunk_2',
            'text': 'Machine learning is a subset of AI that focuses on algorithms and statistical models.',
            'title': 'Machine Learning',
            'url': 'https://en.wikipedia.org/wiki/Machine_learning'
        }
    ]
    
    # Test generator
    generator = ResponseGenerator(model_name="distilgpt2", model_type="causal")
    
    # Generate response
    result = generator.generate_response(
        query="What is artificial intelligence?",
        retrieved_chunks=sample_chunks
    )
    
    print("Generated Response:")
    print(f"Query: {result['query']}")
    print(f"Response: {result['response']}")
    print(f"Generation time: {result['generation_time']:.2f}s")
    
    # Evaluate quality
    quality = generator.evaluate_response_quality(result['response'], result['query'])
    print(f"Quality score: {quality['quality_score']:.2f}")


if __name__ == "__main__":
    main()