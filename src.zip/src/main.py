"""
Main Hybrid RAG System.

This module integrates all components to create a complete RAG pipeline:
- Data collection and processing
- Dense and sparse retrieval
- Hybrid fusion with RRF
- Response generation
"""

import argparse
import json
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from src.data.wikipedia_collector import WikipediaCollector
from src.data.text_processor import TextProcessor
from src.data.data_utils import DataUtils
from src.retrieval.dense_retrieval import DenseRetriever
from src.retrieval.sparse_retrieval import SparseRetriever
from src.retrieval.hybrid_fusion import HybridFusion
from src.generation.response_generator import ResponseGenerator


class HybridRAGSystem:
    """Complete Hybrid RAG System."""
    
    def __init__(self, 
                 config: Optional[Dict] = None,
                 data_dir: str = "data",
                 index_dir: str = "data/indexes"):
        """
        Initialize the RAG system.
        
        Args:
            config: Configuration dictionary
            data_dir: Directory for data storage
            index_dir: Directory for index storage
        """
        self.config = config or self._get_default_config()
        self.data_dir = Path(data_dir)
        self.index_dir = Path(index_dir)
        
        # Initialize components
        self.collector = None
        self.processor = None
        self.dense_retriever = None
        self.sparse_retriever = None
        self.fusion = None
        self.generator = None
        
        # Data storage
        self.articles = {}
        self.chunks = {}
        
        print("Hybrid RAG System initialized")
    
    def _get_default_config(self) -> Dict:
        """Get default configuration."""
        return {
            # Data collection
            'fixed_urls_path': 'data/fixed_urls.json',
            'min_words': 200,
            
            # Text processing
            'chunk_size': 300,
            'chunk_overlap': 50,
            
            # Dense retrieval
            'embedding_model': 'sentence-transformers/all-MiniLM-L6-v2',
            'dense_index_type': 'flat',
            'distance_metric': 'cosine',
            
            # Sparse retrieval
            'bm25_k1': 1.5,
            'bm25_b': 0.75,
            'use_stemming': True,
            'remove_stopwords': True,
            
            # Hybrid fusion
            'rrf_k': 60,
            'fusion_alpha': 0.5,
            
            # Response generation
            'llm_model': 'distilgpt2',
            'llm_type': 'causal',
            'max_length': 512,
            'temperature': 0.7,
            
            # Retrieval parameters
            'top_k_dense': 20,
            'top_k_sparse': 20,
            'top_n_final': 10
        }
    
    def initialize_components(self):
        """Initialize all system components."""
        print("Initializing system components...")
        
        # Data collector
        self.collector = WikipediaCollector(
            fixed_urls_path=self.config['fixed_urls_path'],
            min_words=self.config['min_words']
        )
        
        # Text processor
        self.processor = TextProcessor(
            chunk_size=self.config['chunk_size'],
            chunk_overlap=self.config['chunk_overlap']
        )
        
        # Dense retriever
        self.dense_retriever = DenseRetriever(
            model_name=self.config['embedding_model'],
            index_type=self.config['dense_index_type'],
            distance_metric=self.config['distance_metric']
        )
        
        # Sparse retriever
        self.sparse_retriever = SparseRetriever(
            k1=self.config['bm25_k1'],
            b=self.config['bm25_b'],
            use_stemming=self.config['use_stemming'],
            remove_stopwords=self.config['remove_stopwords']
        )
        
        # Hybrid fusion
        self.fusion = HybridFusion(
            k=self.config['rrf_k'],
            alpha=self.config['fusion_alpha']
        )
        
        # Response generator
        self.generator = ResponseGenerator(
            model_name=self.config['llm_model'],
            model_type=self.config['llm_type'],
            max_length=self.config['max_length'],
            temperature=self.config['temperature']
        )
        
        print("All components initialized successfully")
    
    def collect_and_process_data(self, force_refresh: bool = False):
        """Collect Wikipedia articles and process into chunks."""
        print("=== Data Collection and Processing ===")
        
        if not self.collector or not self.processor:
            self.initialize_components()
        
        # Collect articles
        raw_data_dir = self.data_dir / "raw"
        self.articles = self.collector.collect_all_articles(
            output_dir=str(raw_data_dir),
            force_refresh=force_refresh
        )
        
        # Process into chunks
        processed_data_dir = self.data_dir / "processed"
        self.chunks = self.processor.process_articles(
            self.articles,
            output_dir=str(processed_data_dir)
        )
        
        # Save collection stats
        collection_stats = self.collector.get_collection_stats(self.articles)
        processing_stats = self.processor.get_processing_stats(self.chunks)
        
        stats = {
            'collection': collection_stats,
            'processing': processing_stats,
            'timestamp': time.time()
        }
        
        DataUtils.save_json(stats, self.data_dir / "data_stats.json")
        
        print("Data collection and processing completed")
    
    def build_indexes(self, force_rebuild: bool = False):
        """Build dense and sparse indexes."""
        print("=== Index Building ===")
        
        if not self.chunks:
            # Try to load existing chunks
            try:
                processed_dir = self.data_dir / "processed"
                self.chunks = DataUtils.load_json(processed_dir / "chunks.json")
            except FileNotFoundError:
                print("No processed chunks found. Running data collection first...")
                self.collect_and_process_data()
        
        if not self.dense_retriever or not self.sparse_retriever:
            self.initialize_components()
        
        # Create index directory
        self.index_dir.mkdir(parents=True, exist_ok=True)
        
        # Check if indexes already exist
        dense_index_path = self.index_dir / "dense"
        sparse_index_path = self.index_dir / "sparse"
        
        if not force_rebuild and dense_index_path.exists() and sparse_index_path.exists():
            print("Loading existing indexes...")
            self.dense_retriever.load_index(str(dense_index_path))
            self.sparse_retriever.load_index(str(sparse_index_path))
        else:
            print("Building new indexes...")
            
            # Build dense index
            print("Building dense vector index...")
            self.dense_retriever.build_index(
                self.chunks,
                save_path=str(dense_index_path)
            )
            
            # Build sparse index
            print("Building sparse BM25 index...")
            self.sparse_retriever.build_index(
                self.chunks,
                save_path=str(sparse_index_path)
            )
        
        print("Index building completed")
    
    def query(self, 
              query_text: str,
              top_k_dense: Optional[int] = None,
              top_k_sparse: Optional[int] = None,
              top_n_final: Optional[int] = None,
              fusion_method: str = 'rrf',
              include_generation: bool = True) -> Dict:
        """
        Process a query through the complete RAG pipeline.
        
        Args:
            query_text: Query string
            top_k_dense: Number of dense results (None = use config)
            top_k_sparse: Number of sparse results (None = use config)
            top_n_final: Number of final results (None = use config)
            fusion_method: Fusion method ('rrf', 'score_fusion', 'rank_fusion')
            include_generation: Whether to generate response
            
        Returns:
            Dictionary with query results and timing information
        """
        start_time = time.time()
        
        # Use config defaults if not specified
        top_k_dense = top_k_dense or self.config['top_k_dense']
        top_k_sparse = top_k_sparse or self.config['top_k_sparse']  
        top_n_final = top_n_final or self.config['top_n_final']
        
        result = {
            'query': query_text,
            'parameters': {
                'top_k_dense': top_k_dense,
                'top_k_sparse': top_k_sparse,
                'top_n_final': top_n_final,
                'fusion_method': fusion_method
            }
        }
        
        # Dense retrieval
        dense_start = time.time()
        dense_results = self.dense_retriever.search(
            query_text, 
            top_k=top_k_dense
        )
        dense_time = time.time() - dense_start
        result['dense_results'] = dense_results
        result['dense_retrieval_time'] = dense_time
        
        # Sparse retrieval
        sparse_start = time.time()
        sparse_results = self.sparse_retriever.search(
            query_text,
            top_k=top_k_sparse
        )
        sparse_time = time.time() - sparse_start
        result['sparse_results'] = sparse_results
        result['sparse_retrieval_time'] = sparse_time
        
        # Hybrid fusion
        fusion_start = time.time()
        fused_results = self.fusion.fuse_results(
            dense_results,
            sparse_results,
            top_k=top_n_final,
            fusion_method=fusion_method
        )
        fusion_time = time.time() - fusion_start
        result['fused_results'] = fused_results
        result['fusion_time'] = fusion_time
        
        # Analyze fusion
        fusion_analysis = self.fusion.analyze_fusion_results(
            dense_results, sparse_results, fused_results
        )
        result['fusion_analysis'] = fusion_analysis
        
        # Response generation
        if include_generation:
            generation_start = time.time()
            generation_result = self.generator.generate_response(
                query_text,
                fused_results
            )
            generation_time = time.time() - generation_start
            
            result['generated_response'] = generation_result['response']
            result['generation_metadata'] = {
                'generation_time': generation_result['generation_time'],
                'model_name': generation_result['model_name'],
                'context_sources': generation_result['context_sources']
            }
        
        result['total_time'] = time.time() - start_time
        
        return result
    
    def batch_query(self, queries: List[str], **kwargs) -> List[Dict]:
        """Process multiple queries in batch."""
        results = []
        
        for query in queries:
            result = self.query(query, **kwargs)
            results.append(result)
        
        return results
    
    def get_system_stats(self) -> Dict:
        """Get comprehensive system statistics."""
        stats = {
            'config': self.config,
            'components_initialized': {
                'collector': self.collector is not None,
                'processor': self.processor is not None,
                'dense_retriever': self.dense_retriever is not None,
                'sparse_retriever': self.sparse_retriever is not None,
                'fusion': self.fusion is not None,
                'generator': self.generator is not None
            },
            'data_stats': {
                'articles_loaded': len(self.articles),
                'chunks_loaded': sum(len(chunks) for chunks in self.chunks.values()) if self.chunks else 0
            }
        }
        
        # Add component-specific stats
        if self.dense_retriever and self.dense_retriever.index is not None:
            stats['dense_index'] = self.dense_retriever.get_index_stats()
        
        if self.sparse_retriever and self.sparse_retriever.bm25 is not None:
            stats['sparse_index'] = self.sparse_retriever.get_index_stats()
        
        if self.generator:
            stats['generator'] = self.generator.get_model_info()
        
        return stats
    
    def save_system_state(self, save_path: str):
        """Save the current system state."""
        save_path = Path(save_path)
        save_path.mkdir(parents=True, exist_ok=True)
        
        # Save configuration
        DataUtils.save_json(self.config, save_path / "config.json")
        
        # Save system stats
        stats = self.get_system_stats()
        DataUtils.save_json(stats, save_path / "system_stats.json")
        
        print(f"System state saved to {save_path}")
    
    def load_system_state(self, load_path: str):
        """Load system state from disk."""
        load_path = Path(load_path)
        
        # Load configuration
        config_file = load_path / "config.json"
        if config_file.exists():
            self.config = DataUtils.load_json(config_file)
            print("Configuration loaded")
        
        # Initialize components with loaded config
        self.initialize_components()
        
        # Load indexes if they exist
        dense_index_path = self.index_dir / "dense"
        sparse_index_path = self.index_dir / "sparse"
        
        if dense_index_path.exists():
            self.dense_retriever.load_index(str(dense_index_path))
        
        if sparse_index_path.exists():
            self.sparse_retriever.load_index(str(sparse_index_path))
        
        print("System state loaded successfully")
    
    def run_evaluation(self, 
                      num_questions: int = 100,
                      output_dir: str = "outputs/evaluation",
                      save_results: bool = True) -> Dict:
        """
        Run comprehensive evaluation of the RAG system.
        
        Args:
            num_questions: Number of questions to generate and evaluate
            output_dir: Directory to save evaluation results
            save_results: Whether to save detailed results
            
        Returns:
            Dictionary with evaluation results
        """
        try:
            from .evaluation.evaluator import RAGEvaluator
            
            # Ensure system is initialized
            if not self.dense_retriever or not self.sparse_retriever:
                raise ValueError("System not properly initialized. Load system state first.")
            
            # Initialize evaluator
            evaluator = RAGEvaluator(
                rag_system=self,
                output_dir=output_dir
            )
            
            # Run evaluation
            results = evaluator.run_full_evaluation(
                num_questions=num_questions,
                save_results=save_results,
                run_ablation=True,
                generate_report=True
            )
            
            return results
            
        except ImportError as e:
            raise ImportError("Evaluation components not available. Make sure all dependencies are installed.")
        except Exception as e:
            raise RuntimeError(f"Evaluation failed: {e}")


def main():
    """Main entry point for the RAG system."""
    parser = argparse.ArgumentParser(description="Hybrid RAG System")
    parser.add_argument("--mode", 
                       choices=["collect", "index", "query", "evaluate", "full"],
                       default="query",
                       help="Operation mode")
    parser.add_argument("--query", type=str, help="Query text for single query mode")
    parser.add_argument("--config", type=str, help="Path to configuration file")
    parser.add_argument("--force-refresh", action="store_true", 
                       help="Force refresh of data and indexes")
    parser.add_argument("--output-dir", type=str, default="outputs",
                       help="Output directory for results")
    
    args = parser.parse_args()
    
    # Load configuration if provided
    config = None
    if args.config:
        config = DataUtils.load_json(args.config)
    
    # Initialize system
    rag_system = HybridRAGSystem(config=config)
    
    if args.mode == "collect":
        # Data collection only
        rag_system.collect_and_process_data(force_refresh=args.force_refresh)
        
    elif args.mode == "index":
        # Build indexes
        rag_system.build_indexes(force_rebuild=args.force_refresh)
        
    elif args.mode == "query":
        # Single query
        if not args.query:
            args.query = input("Enter your query: ")
        
        # Load system state
        rag_system.load_system_state("data")
        
        # Process query
        result = rag_system.query(args.query)
        
        # Display results
        print(f"\nQuery: {result['query']}")
        print(f"Generated Answer: {result.get('generated_response', 'No response generated')}")
        print(f"\nTop Retrieved Sources:")
        for i, chunk in enumerate(result['fused_results'][:5]):
            print(f"{i+1}. {chunk['title']} (Score: {chunk.get('rrf_score', 'N/A'):.3f})")
            print(f"   {chunk['text'][:100]}...")
        
        print(f"\nTiming: Total={result['total_time']:.2f}s, "
              f"Dense={result['dense_retrieval_time']:.2f}s, "
              f"Sparse={result['sparse_retrieval_time']:.2f}s, "
              f"Fusion={result['fusion_time']:.2f}s")
        
    elif args.mode == "evaluate":
        # Run comprehensive evaluation
        print("Starting comprehensive evaluation...")
        
        try:
            # Import evaluation components
            from .evaluation.evaluator import RAGEvaluator
            
            # Load system state
            rag_system.load_system_state("data")
            
            # Initialize evaluator
            evaluator = RAGEvaluator(
                rag_system=rag_system,
                output_dir=args.output_dir
            )
            
            # Run full evaluation
            results = evaluator.run_full_evaluation(
                num_questions=100,  # Full evaluation
                save_results=True,
                run_ablation=True,
                generate_report=True
            )
            
            # Display key results
            print("\n" + "="*60)
            print("EVALUATION RESULTS SUMMARY")
            print("="*60)
            
            summary = results.get('summary', {})
            primary_metrics = summary.get('primary_metrics', {})
            
            print(f"Total Questions: {summary.get('total_questions_evaluated', 'N/A')}")
            print(f"Mean Reciprocal Rank: {primary_metrics.get('mrr', 0):.3f}")
            print(f"ROUGE-L F1: {primary_metrics.get('rouge_l_f1', 0):.3f}")
            print(f"Retrieval Precision@10: {primary_metrics.get('precision_at_10', 0):.3f}")
            
            # Performance metrics
            performance = results.get('performance', {})
            print(f"Average Response Time: {performance.get('average_response_time', 0):.2f}s")
            print(f"Questions per Minute: {performance.get('questions_per_minute', 0):.1f}")
            
            # Report path
            if 'report_path' in results:
                print(f"\nDetailed report saved to: {results['report_path']}")
            
            print("="*60)
            
        except Exception as e:
            print(f"Evaluation failed: {e}")
            print("Make sure the system is properly built and indexed first.")
            return
        
    elif args.mode == "full":
        # Complete pipeline
        print("Running complete RAG system pipeline...")
        
        # Data collection and processing
        rag_system.collect_and_process_data(force_refresh=args.force_refresh)
        
        # Build indexes
        rag_system.build_indexes(force_rebuild=args.force_refresh)
        
        # Save system state
        rag_system.save_system_state("data")
        
        print("\nSystem ready! You can now:")
        print("1. Run queries: python src/main.py --mode query")
        print("2. Start the web interface: streamlit run src/ui/streamlit_app.py")
        print("3. Run evaluation: python src/main.py --mode evaluate")


if __name__ == "__main__":
    main()