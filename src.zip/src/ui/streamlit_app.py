"""
Streamlit Web Interface for Hybrid RAG System.

This module provides an interactive web interface featuring:
- Query input and response display
- Retrieved chunks with source information
- Performance metrics and timing
- System configuration options
- Real-time retrieval analysis
"""

import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st
from streamlit_option_menu import option_menu

# Add src to path for imports
sys.path.append(str(Path(__file__).parent.parent))

try:
    from main import HybridRAGSystem
    from data.data_utils import DataUtils
except ImportError as e:
    st.error(f"Import error: {e}")
    st.error("Make sure you're running from the project root directory")
    st.stop()


class StreamlitRAGApp:
    """Streamlit application for the Hybrid RAG system."""
    
    def __init__(self):
        """Initialize the Streamlit app."""
        self.setup_page_config()
        self.initialize_session_state()
    
    def setup_page_config(self):
        """Configure Streamlit page settings."""
        st.set_page_config(
            page_title="Hybrid RAG System",
            page_icon="🔍",
            layout="wide",
            initial_sidebar_state="expanded"
        )
        
        # Custom CSS for better styling
        st.markdown("""
        <style>
        .main > div {
            padding-top: 2rem;
        }
        .stAlert > div {
            padding-top: 1rem;
        }
        .source-box {
            border: 1px solid #ddd;
            border-radius: 5px;
            padding: 1rem;
            margin: 0.5rem 0;
            background-color: #f8f9fa;
        }
        .metric-container {
            background-color: #f0f2f6;
            padding: 1rem;
            border-radius: 10px;
            margin: 0.5rem 0;
        }
        </style>
        """, unsafe_allow_html=True)
    
    def initialize_session_state(self):
        """Initialize Streamlit session state variables."""
        if 'rag_system' not in st.session_state:
            st.session_state.rag_system = None
        if 'system_ready' not in st.session_state:
            st.session_state.system_ready = False
        if 'query_history' not in st.session_state:
            st.session_state.query_history = []
        if 'current_result' not in st.session_state:
            st.session_state.current_result = None
    
    def load_rag_system(self):
        """Load and initialize the RAG system."""
        try:
            with st.spinner("Initializing RAG system..."):
                if st.session_state.rag_system is None:
                    st.session_state.rag_system = HybridRAGSystem()
                    
                # Try to load existing system state
                try:
                    st.session_state.rag_system.load_system_state("data")
                    st.session_state.system_ready = True
                    st.success("✅ RAG system loaded successfully!")
                except Exception as e:
                    st.warning(f"⚠️ Could not load existing indexes: {e}")
                    st.info("💡 Run data collection and indexing first using the sidebar options.")
                    st.session_state.system_ready = False
                    
        except Exception as e:
            st.error(f"❌ Failed to initialize RAG system: {e}")
            st.session_state.system_ready = False
    
    def sidebar_controls(self):
        """Create sidebar with system controls and configuration."""
        with st.sidebar:
            st.title("🔍 RAG System")
            st.markdown("---")
            
            # System Status
            st.subheader("📊 System Status")
            if st.session_state.system_ready:
                st.success("✅ Ready")
                
                # Display system stats
                if st.session_state.rag_system:
                    stats = st.session_state.rag_system.get_system_stats()
                    
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("Articles", stats['data_stats']['articles_loaded'])
                    with col2:
                        st.metric("Chunks", stats['data_stats']['chunks_loaded'])
            else:
                st.error("❌ Not Ready")
            
            st.markdown("---")
            
            # System Operations
            st.subheader("⚙️ System Operations")
            
            col1, col2 = st.columns(2)
            
            with col1:
                if st.button("📚 Collect Data", help="Collect Wikipedia articles"):
                    self.collect_data()
            
            with col2:
                if st.button("🏗️ Build Indexes", help="Build retrieval indexes"):
                    self.build_indexes()
            
            if st.button("🔄 Reload System", help="Reload system components"):
                st.session_state.rag_system = None
                st.session_state.system_ready = False
                self.load_rag_system()
                st.experimental_rerun()
            
            st.markdown("---")
            
            # Query Parameters
            st.subheader("⚡ Query Parameters")
            
            top_k_dense = st.slider(
                "Dense Retrieval Top-K",
                min_value=5, max_value=50, value=20,
                help="Number of chunks to retrieve using dense vectors"
            )
            
            top_k_sparse = st.slider(
                "Sparse Retrieval Top-K", 
                min_value=5, max_value=50, value=20,
                help="Number of chunks to retrieve using BM25"
            )
            
            top_n_final = st.slider(
                "Final Results Count",
                min_value=3, max_value=20, value=10,
                help="Number of final chunks after fusion"
            )
            
            fusion_method = st.selectbox(
                "Fusion Method",
                options=["rrf", "score_fusion", "rank_fusion"],
                index=0,
                help="Method to combine dense and sparse results"
            )
            
            st.session_state.query_params = {
                'top_k_dense': top_k_dense,
                'top_k_sparse': top_k_sparse,
                'top_n_final': top_n_final,
                'fusion_method': fusion_method
            }
            
            st.markdown("---")
            
            # Advanced Settings
            with st.expander("🔧 Advanced Settings"):
                include_generation = st.checkbox("Generate Response", value=True)
                show_fusion_analysis = st.checkbox("Show Fusion Analysis", value=False)
                show_individual_results = st.checkbox("Show Individual Results", value=False)
                
                st.session_state.advanced_settings = {
                    'include_generation': include_generation,
                    'show_fusion_analysis': show_fusion_analysis,
                    'show_individual_results': show_individual_results
                }
    
    def collect_data(self):
        """Collect Wikipedia data."""
        if st.session_state.rag_system is None:
            st.session_state.rag_system = HybridRAGSystem()
        
        with st.spinner("Collecting Wikipedia articles... This may take several minutes."):
            try:
                st.session_state.rag_system.collect_and_process_data()
                st.success("✅ Data collection completed!")
            except Exception as e:
                st.error(f"❌ Data collection failed: {e}")
    
    def build_indexes(self):
        """Build retrieval indexes."""
        if st.session_state.rag_system is None:
            st.session_state.rag_system = HybridRAGSystem()
        
        with st.spinner("Building retrieval indexes... This may take several minutes."):
            try:
                st.session_state.rag_system.build_indexes()
                st.session_state.system_ready = True
                st.success("✅ Indexes built successfully!")
            except Exception as e:
                st.error(f"❌ Index building failed: {e}")
    
    def query_interface(self):
        """Main query interface."""
        st.title("🔍 Hybrid RAG Query System")
        st.markdown("Ask questions and get AI-powered answers from 500 Wikipedia articles using hybrid retrieval.")
        
        # Query input
        query_col, button_col = st.columns([4, 1])
        
        with query_col:
            query = st.text_input(
                "Enter your question:",
                placeholder="e.g., What is artificial intelligence?",
                key="query_input"
            )
        
        with button_col:
            st.markdown("<br>", unsafe_allow_html=True)  # Add spacing
            search_clicked = st.button("🔍 Search", type="primary")
        
        # Example queries
        st.markdown("**💡 Example queries:**")
        example_queries = [
            "What is artificial intelligence?",
            "How does machine learning work?", 
            "What are the main causes of climate change?",
            "Who was Napoleon Bonaparte?",
            "How do quantum computers work?"
        ]
        
        cols = st.columns(len(example_queries))
        for i, example in enumerate(example_queries):
            with cols[i]:
                if st.button(f"💬 {example[:20]}...", key=f"example_{i}"):
                    st.session_state.query_input = example
                    search_clicked = True
        
        # Process query
        if search_clicked and query:
            if not st.session_state.system_ready:
                st.error("❌ System not ready. Please collect data and build indexes first.")
                return
            
            self.process_query(query)
        
        # Display results
        if st.session_state.current_result:
            self.display_query_results()
    
    def process_query(self, query: str):
        """Process a query through the RAG system."""
        try:
            with st.spinner("Processing query..."):
                start_time = time.time()
                
                result = st.session_state.rag_system.query(
                    query,
                    **st.session_state.query_params,
                    include_generation=st.session_state.advanced_settings['include_generation']
                )
                
                # Add to query history
                st.session_state.query_history.append({
                    'query': query,
                    'timestamp': time.time(),
                    'total_time': result['total_time']
                })
                
                st.session_state.current_result = result
                
        except Exception as e:
            st.error(f"❌ Query processing failed: {e}")
            st.exception(e)
    
    def display_query_results(self):
        """Display query results with formatting."""
        result = st.session_state.current_result
        
        # Performance metrics
        st.markdown("---")
        st.subheader("⚡ Performance Metrics")
        
        col1, col2, col3, col4, col5 = st.columns(5)
        
        with col1:
            st.metric("Total Time", f"{result['total_time']:.2f}s")
        with col2:
            st.metric("Dense Retrieval", f"{result['dense_retrieval_time']:.2f}s")
        with col3:
            st.metric("Sparse Retrieval", f"{result['sparse_retrieval_time']:.2f}s") 
        with col4:
            st.metric("Fusion", f"{result['fusion_time']:.2f}s")
        with col5:
            if 'generation_metadata' in result:
                st.metric("Generation", f"{result['generation_metadata']['generation_time']:.2f}s")
        
        # Generated Response
        if 'generated_response' in result and result['generated_response']:
            st.markdown("---")
            st.subheader("🤖 Generated Answer")
            
            # Display response in a nice box
            st.markdown(f"""
            <div class="source-box">
            <p style="font-size: 1.1em; line-height: 1.6;">{result['generated_response']}</p>
            </div>
            """, unsafe_allow_html=True)
            
            # Response quality assessment
            if hasattr(st.session_state.rag_system.generator, 'evaluate_response_quality'):
                quality = st.session_state.rag_system.generator.evaluate_response_quality(
                    result['generated_response'], result['query']
                )
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Quality Score", f"{quality['quality_score']:.2f}")
                with col2:
                    st.metric("Word Count", quality['word_count'])
                with col3:
                    st.metric("Keyword Overlap", f"{quality['keyword_overlap']:.2f}")
        
        # Retrieved Sources
        st.markdown("---")
        st.subheader("📚 Retrieved Sources")
        
        fused_results = result.get('fused_results', [])
        
        for i, chunk in enumerate(fused_results[:5]):  # Show top 5
            with st.expander(f"📄 Source {i+1}: {chunk['title']}", expanded=(i < 2)):
                
                col1, col2 = st.columns([3, 1])
                
                with col1:
                    st.markdown(f"**Content:**")
                    st.markdown(chunk['text'])
                    
                    if chunk.get('url'):
                        st.markdown(f"**URL:** [{chunk['url']}]({chunk['url']})")
                
                with col2:
                    st.markdown("**Scores:**")
                    if 'rrf_score' in chunk:
                        st.metric("RRF Score", f"{chunk['rrf_score']:.3f}")
                    if 'similarity_score' in chunk:
                        st.metric("Dense Score", f"{chunk['similarity_score']:.3f}")
                    if 'bm25_score' in chunk:
                        st.metric("BM25 Score", f"{chunk['bm25_score']:.3f}")
        
        # Individual retrieval results (if enabled)
        if st.session_state.advanced_settings['show_individual_results']:
            self.display_individual_results(result)
        
        # Fusion analysis (if enabled)
        if st.session_state.advanced_settings['show_fusion_analysis']:
            self.display_fusion_analysis(result)
    
    def display_individual_results(self, result: Dict):
        """Display individual dense and sparse retrieval results."""
        st.markdown("---")
        st.subheader("🔍 Individual Retrieval Results")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**🔢 Dense Retrieval (Vector Similarity)**")
            dense_results = result.get('dense_results', [])
            
            for i, chunk in enumerate(dense_results[:5]):
                score = chunk.get('similarity_score', 0)
                st.markdown(f"{i+1}. **{chunk['title']}** (Score: {score:.3f})")
                st.markdown(f"   {chunk['text'][:100]}...")
        
        with col2:
            st.markdown("**📝 Sparse Retrieval (BM25)**")
            sparse_results = result.get('sparse_results', [])
            
            for i, chunk in enumerate(sparse_results[:5]):
                score = chunk.get('bm25_score', 0)
                st.markdown(f"{i+1}. **{chunk['title']}** (Score: {score:.3f})")
                st.markdown(f"   {chunk['text'][:100]}...")
                if 'matched_terms' in chunk:
                    st.markdown(f"   **Matched terms:** {', '.join(chunk['matched_terms'])}")
    
    def display_fusion_analysis(self, result: Dict):
        """Display fusion analysis and visualizations."""
        st.markdown("---")
        st.subheader("📊 Fusion Analysis")
        
        fusion_analysis = result.get('fusion_analysis', {})
        
        if fusion_analysis:
            # Input statistics
            input_stats = fusion_analysis.get('input_stats', {})
            fusion_stats = fusion_analysis.get('fusion_stats', {})
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("**Input Statistics:**")
                st.json(input_stats)
            
            with col2:
                st.markdown("**Fusion Statistics:**") 
                st.json(fusion_stats)
            
            # Contribution visualization
            if 'contribution_percentages' in fusion_analysis:
                contrib = fusion_analysis['contribution_percentages']
                
                fig = go.Figure(data=[
                    go.Bar(
                        x=['Dense Only', 'Sparse Only', 'Both Methods'],
                        y=[contrib['dense_only'], contrib['sparse_only'], contrib['both_methods']],
                        marker_color=['#FF6B6B', '#4ECDC4', '#45B7D1']
                    )
                ])
                
                fig.update_layout(
                    title="Contribution of Retrieval Methods",
                    yaxis_title="Percentage of Results",
                    xaxis_title="Method"
                )
                
                st.plotly_chart(fig, use_container_width=True)
    
    def analytics_page(self):
        """Analytics and system monitoring page."""
        st.title("📈 System Analytics")
        
        if not st.session_state.query_history:
            st.info("No query history available. Run some queries first!")
            return
        
        # Query history analysis
        st.subheader("📝 Query History")
        
        history_df = pd.DataFrame(st.session_state.query_history)
        history_df['timestamp'] = pd.to_datetime(history_df['timestamp'], unit='s')
        
        # Query count over time
        fig = px.line(
            history_df, 
            x='timestamp', 
            y=history_df.index,
            title="Queries Over Time",
            labels={'y': 'Query Count', 'timestamp': 'Time'}
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Performance analysis
        st.subheader("⚡ Performance Analysis")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("Total Queries", len(history_df))
            st.metric("Average Response Time", f"{history_df['total_time'].mean():.2f}s")
        
        with col2:
            st.metric("Fastest Query", f"{history_df['total_time'].min():.2f}s")
            st.metric("Slowest Query", f"{history_df['total_time'].max():.2f}s")
        
        # Response time distribution
        fig = px.histogram(
            history_df,
            x='total_time',
            title="Response Time Distribution",
            labels={'total_time': 'Response Time (seconds)', 'count': 'Frequency'}
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Recent queries table
        st.subheader("🕐 Recent Queries")
        recent_queries = history_df.tail(10).sort_values('timestamp', ascending=False)
        st.dataframe(recent_queries[['timestamp', 'query', 'total_time']], use_container_width=True)
    
    def system_info_page(self):
        """System information and configuration page."""
        st.title("ℹ️ System Information")
        
        if st.session_state.rag_system:
            stats = st.session_state.rag_system.get_system_stats()
            
            # Configuration
            st.subheader("⚙️ System Configuration")
            config_col1, config_col2 = st.columns(2)
            
            with config_col1:
                st.json(stats.get('config', {}))
            
            with config_col2:
                st.markdown("**Component Status:**")
                components = stats.get('components_initialized', {})
                for component, status in components.items():
                    status_icon = "✅" if status else "❌"
                    st.markdown(f"{status_icon} {component.replace('_', ' ').title()}")
            
            # Index Statistics
            if 'dense_index' in stats:
                st.subheader("🔢 Dense Index Statistics")
                st.json(stats['dense_index'])
            
            if 'sparse_index' in stats:
                st.subheader("📝 Sparse Index Statistics")
                sparse_stats = stats['sparse_index']
                
                col1, col2, col3 = st.columns(3)
                with col1:
                    st.metric("Documents", sparse_stats.get('total_documents', 0))
                with col2:
                    st.metric("Vocabulary Size", sparse_stats.get('vocabulary_size', 0))
                with col3:
                    st.metric("Avg Doc Length", f"{sparse_stats.get('avg_document_length', 0):.1f}")
                
                # Top terms visualization
                if 'top_terms' in sparse_stats:
                    top_terms = sparse_stats['top_terms']
                    terms_df = pd.DataFrame(
                        [(term, freq) for term, freq in top_terms.items()],
                        columns=['Term', 'Frequency']
                    )
                    
                    fig = px.bar(
                        terms_df.head(20),
                        x='Frequency',
                        y='Term',
                        orientation='h',
                        title="Top 20 Terms in Corpus"
                    )
                    fig.update_layout(height=600)
                    st.plotly_chart(fig, use_container_width=True)
            
            # Generator Information
            if 'generator' in stats:
                st.subheader("🤖 Language Model Information")
                st.json(stats['generator'])
        else:
            st.warning("RAG system not initialized. Please initialize the system first.")
    
    def run(self):
        """Run the Streamlit application."""
        # Load RAG system
        self.load_rag_system()
        
        # Sidebar controls
        self.sidebar_controls()
        
        # Main navigation
        selected = option_menu(
            menu_title=None,
            options=["Query", "Analytics", "System Info"],
            icons=["search", "graph-up", "info-circle"],
            menu_icon="cast",
            default_index=0,
            orientation="horizontal",
        )
        
        # Page routing
        if selected == "Query":
            self.query_interface()
        elif selected == "Analytics":
            self.analytics_page()
        elif selected == "System Info":
            self.system_info_page()


def main():
    """Main entry point for the Streamlit app."""
    try:
        app = StreamlitRAGApp()
        app.run()
    except Exception as e:
        st.error(f"Application error: {e}")
        st.exception(e)


if __name__ == "__main__":
    main()