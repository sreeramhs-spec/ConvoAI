"""
Automated question generation for RAG evaluation.

This module generates diverse questions from Wikipedia content:
- Extractive questions from text
- Different question types (factual, comparative, inferential)
- Answer extraction and validation
- Question difficulty assessment
"""

import json
import random
import re
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple

import nltk
import spacy
from nltk.tokenize import sent_tokenize, word_tokenize
from transformers import pipeline, AutoTokenizer, AutoModelForSeq2SeqLM


class QuestionGenerator:
    """Generates evaluation questions from Wikipedia content."""
    
    def __init__(self,
                 question_model: str = "valhalla/t5-small-qg-hl",
                 use_templates: bool = True,
                 min_answer_length: int = 3,
                 max_questions_per_article: int = 5):
        """
        Initialize the question generator.
        
        Args:
            question_model: HuggingFace model for question generation
            use_templates: Whether to use template-based generation
            min_answer_length: Minimum answer length in words
            max_questions_per_article: Maximum questions per article
        """
        self.question_model_name = question_model
        self.use_templates = use_templates
        self.min_answer_length = min_answer_length
        self.max_questions_per_article = max_questions_per_article
        
        # Initialize NLP components
        self._initialize_nlp()
        
        # Initialize question generation model
        self._initialize_qg_model()
        
        # Question templates by type
        self.question_templates = self._get_question_templates()
        
        print("Question generator initialized successfully")
    
    def _initialize_nlp(self):
        """Initialize NLTK and spaCy components."""
        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('punkt')
        
        try:
            self.nlp = spacy.load("en_core_web_sm")
        except OSError:
            print("Warning: spaCy model not found. Some features may be limited.")
            self.nlp = None
    
    def _initialize_qg_model(self):
        """Initialize question generation model."""
        try:
            print(f"Loading question generation model: {self.question_model_name}")
            self.qg_pipeline = pipeline(
                "text2text-generation",
                model=self.question_model_name,
                tokenizer=self.question_model_name
            )
            print("Question generation model loaded successfully")
        except Exception as e:
            print(f"Warning: Could not load QG model {self.question_model_name}: {e}")
            self.qg_pipeline = None
            print("Falling back to template-based question generation")
    
    def _get_question_templates(self) -> Dict[str, List[str]]:
        """Get question templates organized by type."""
        return {
            'factual': [
                "What is {entity}?",
                "Who was {person}?",
                "When did {event} occur?", 
                "Where is {location} located?",
                "How does {process} work?",
                "What are the main features of {concept}?",
                "What is the purpose of {object}?",
                "Who invented {invention}?",
                "What causes {phenomenon}?",
                "What is the definition of {term}?"
            ],
            'comparative': [
                "What is the difference between {concept1} and {concept2}?",
                "How does {concept1} compare to {concept2}?",
                "Which is larger: {entity1} or {entity2}?",
                "What are the similarities between {concept1} and {concept2}?",
                "How is {concept1} different from {concept2}?"
            ],
            'inferential': [
                "Why is {concept} important?",
                "What are the implications of {event}?",
                "How might {concept} affect {domain}?",
                "What can we learn from {example}?",
                "What are the advantages of {approach}?",
                "What challenges does {field} face?",
                "How has {concept} evolved over time?"
            ],
            'multi_hop': [
                "What role did {person} play in {event}?",
                "How did {event1} influence {event2}?", 
                "What connection exists between {concept1} and {concept2}?",
                "How does {principle} apply to {application}?",
                "What impact did {innovation} have on {field}?"
            ]
        }
    
    def extract_entities_and_concepts(self, text: str) -> Dict[str, List[str]]:
        """Extract named entities and key concepts from text."""
        entities = {
            'person': [],
            'location': [],
            'organization': [],
            'event': [],
            'concept': [],
            'date': [],
            'number': []
        }
        
        if self.nlp:
            doc = self.nlp(text)
            
            # Extract named entities
            for ent in doc.ents:
                if ent.label_ in ['PERSON']:
                    entities['person'].append(ent.text)
                elif ent.label_ in ['GPE', 'LOC']:
                    entities['location'].append(ent.text)
                elif ent.label_ in ['ORG']:
                    entities['organization'].append(ent.text)
                elif ent.label_ in ['EVENT']:
                    entities['event'].append(ent.text)
                elif ent.label_ in ['DATE']:
                    entities['date'].append(ent.text)
                elif ent.label_ in ['CARDINAL', 'QUANTITY']:
                    entities['number'].append(ent.text)
            
            # Extract key concepts (important nouns)
            for token in doc:
                if (token.pos_ == 'NOUN' and 
                    not token.is_stop and 
                    len(token.text) > 3 and
                    token.text.lower() not in [e.lower() for sublist in entities.values() for e in sublist]):
                    entities['concept'].append(token.text)
        else:
            # Fallback: simple pattern matching
            # This is a simplified approach
            words = word_tokenize(text)
            capitalized_words = [w for w in words if w[0].isupper() and len(w) > 2]
            entities['concept'] = capitalized_words[:10]  # Limit to avoid noise
        
        # Remove duplicates and limit length
        for key in entities:
            entities[key] = list(set(entities[key]))[:10]
        
        return entities
    
    def generate_template_questions(self, 
                                  text: str,
                                  title: str,
                                  url: str,
                                  num_questions: int = 3) -> List[Dict]:
        """Generate questions using templates."""
        questions = []
        
        # Extract entities and concepts
        entities = self.extract_entities_and_concepts(text)
        
        # Generate different types of questions
        question_types = ['factual', 'comparative', 'inferential', 'multi_hop']
        
        for _ in range(num_questions):
            # Randomly select question type
            q_type = random.choice(question_types)
            templates = self.question_templates[q_type]
            template = random.choice(templates)
            
            # Fill template based on available entities
            question = self._fill_template(template, entities, text)
            
            if question:
                # Extract potential answer
                answer = self._extract_answer(question, text, entities)
                
                if answer and len(answer.split()) >= self.min_answer_length:
                    questions.append({
                        'question': question,
                        'answer': answer,
                        'question_type': q_type,
                        'source_title': title,
                        'source_url': url,
                        'generation_method': 'template',
                        'entities_used': self._get_entities_in_question(question, entities)
                    })
        
        return questions
    
    def _fill_template(self, template: str, entities: Dict, text: str) -> Optional[str]:
        """Fill a question template with appropriate entities."""
        placeholders = re.findall(r'\{(\w+)\}', template)
        
        filled_template = template
        
        for placeholder in placeholders:
            if placeholder in entities and entities[placeholder]:
                # Choose a random entity of the required type
                entity = random.choice(entities[placeholder])
                filled_template = filled_template.replace(f'{{{placeholder}}}', entity)
            elif placeholder.endswith(('1', '2')):
                # Handle comparative placeholders (concept1, concept2, etc.)
                base_type = placeholder[:-1]
                if base_type in entities and len(entities[base_type]) >= 2:
                    if placeholder.endswith('1'):
                        entity = entities[base_type][0]
                    else:
                        entity = entities[base_type][1]
                    filled_template = filled_template.replace(f'{{{placeholder}}}', entity)
                else:
                    return None
            else:
                # If we can't fill the placeholder, try concept as fallback
                if entities['concept']:
                    entity = random.choice(entities['concept'])
                    filled_template = filled_template.replace(f'{{{placeholder}}}', entity)
                else:
                    return None
        
        # Check if all placeholders were filled
        if '{' in filled_template and '}' in filled_template:
            return None
        
        return filled_template
    
    def _extract_answer(self, question: str, text: str, entities: Dict) -> Optional[str]:
        """Extract a potential answer from the text for a given question."""
        # This is a simplified answer extraction
        # In a more sophisticated system, you'd use reading comprehension models
        
        sentences = sent_tokenize(text)
        
        # Find entities mentioned in the question
        question_entities = self._get_entities_in_question(question, entities)
        
        # Find sentences that contain these entities
        candidate_sentences = []
        for sentence in sentences:
            sentence_lower = sentence.lower()
            question_lower = question.lower()
            
            # Count entity overlap
            entity_overlap = sum(1 for entity in question_entities 
                               if entity.lower() in sentence_lower)
            
            if entity_overlap > 0:
                candidate_sentences.append((sentence, entity_overlap))
        
        if not candidate_sentences:
            return None
        
        # Sort by entity overlap and take the best sentence
        candidate_sentences.sort(key=lambda x: x[1], reverse=True)
        best_sentence = candidate_sentences[0][0]
        
        # Extract a shorter answer phrase if possible
        answer = self._extract_answer_phrase(question, best_sentence)
        
        return answer or best_sentence
    
    def _get_entities_in_question(self, question: str, entities: Dict) -> List[str]:
        """Get entities that appear in the question."""
        question_lower = question.lower()
        found_entities = []
        
        for entity_type, entity_list in entities.items():
            for entity in entity_list:
                if entity.lower() in question_lower:
                    found_entities.append(entity)
        
        return found_entities
    
    def _extract_answer_phrase(self, question: str, sentence: str) -> Optional[str]:
        """Extract a specific answer phrase from a sentence."""
        # Simple pattern-based answer extraction
        question_lower = question.lower()
        
        # What is questions
        if question_lower.startswith('what is'):
            # Look for "X is Y" patterns
            match = re.search(r'(\w+(?:\s+\w+)*)\s+is\s+(.*?)(?:\.|,|;|$)', sentence)
            if match:
                return match.group(2).strip()
        
        # Who was questions
        elif question_lower.startswith('who was'):
            # Look for person descriptions
            match = re.search(r'(\w+(?:\s+\w+)*)\s+was\s+(.*?)(?:\.|,|;|$)', sentence)
            if match:
                return match.group(2).strip()
        
        # When did questions
        elif question_lower.startswith('when did'):
            # Look for dates and time expressions
            if self.nlp:
                doc = self.nlp(sentence)
                dates = [ent.text for ent in doc.ents if ent.label_ == 'DATE']
                if dates:
                    return dates[0]
        
        # Default: return first 15 words of sentence
        words = sentence.split()[:15]
        return ' '.join(words)
    
    def generate_model_questions(self,
                                text: str,
                                title: str,
                                url: str,
                                num_questions: int = 3) -> List[Dict]:
        """Generate questions using the transformer model."""
        if not self.qg_pipeline:
            return []
        
        questions = []
        sentences = sent_tokenize(text)
        
        # Select important sentences for question generation
        selected_sentences = self._select_important_sentences(sentences, num_questions * 2)
        
        for sentence in selected_sentences[:num_questions]:
            try:
                # Highlight important parts (simple approach)
                highlighted_text = self._highlight_answer_candidates(sentence)
                
                # Generate question
                result = self.qg_pipeline(
                    highlighted_text,
                    max_length=64,
                    num_return_sequences=1,
                    temperature=0.7
                )
                
                if result:
                    question = result[0]['generated_text'].strip()
                    
                    # Clean up the question
                    question = self._clean_question(question)
                    
                    if question and len(question) > 10:
                        # Extract answer from highlighted text
                        answer = self._extract_highlighted_answer(highlighted_text, sentence)
                        
                        questions.append({
                            'question': question,
                            'answer': answer or sentence,
                            'question_type': 'generated',
                            'source_title': title,
                            'source_url': url,
                            'generation_method': 'model',
                            'source_sentence': sentence
                        })
                        
                        if len(questions) >= num_questions:
                            break
                            
            except Exception as e:
                print(f"Error generating question from sentence: {e}")
                continue
        
        return questions
    
    def _select_important_sentences(self, sentences: List[str], num_sentences: int) -> List[str]:
        """Select important sentences for question generation."""
        # Score sentences based on various criteria
        scored_sentences = []
        
        for sentence in sentences:
            score = 0
            words = word_tokenize(sentence.lower())
            
            # Length score (prefer medium length sentences)
            word_count = len(words)
            if 10 <= word_count <= 25:
                score += 2
            elif 8 <= word_count <= 30:
                score += 1
            
            # Named entity score
            if self.nlp:
                doc = self.nlp(sentence)
                entities = len([ent for ent in doc.ents if ent.label_ in ['PERSON', 'ORG', 'GPE', 'DATE']])
                score += entities
            
            # Content word score
            content_words = ['is', 'was', 'are', 'were', 'called', 'known', 'invented', 'created', 'founded']
            for word in content_words:
                if word in words:
                    score += 1
            
            scored_sentences.append((sentence, score))
        
        # Sort by score and return top sentences
        scored_sentences.sort(key=lambda x: x[1], reverse=True)
        return [sentence for sentence, score in scored_sentences[:num_sentences]]
    
    def _highlight_answer_candidates(self, sentence: str) -> str:
        """Highlight potential answer candidates in the sentence."""
        # Simple highlighting: mark named entities
        if not self.nlp:
            return sentence
        
        doc = self.nlp(sentence)
        highlighted = sentence
        
        # Sort entities by position (reverse order to maintain text positions)
        entities = sorted(doc.ents, key=lambda x: x.start_char, reverse=True)
        
        for ent in entities:
            if ent.label_ in ['PERSON', 'ORG', 'GPE', 'DATE', 'QUANTITY']:
                # Add highlighting markers
                highlighted = (highlighted[:ent.start_char] + 
                             f"<hl>{ent.text}<hl>" + 
                             highlighted[ent.end_char:])
        
        return highlighted
    
    def _extract_highlighted_answer(self, highlighted_text: str, original_sentence: str) -> Optional[str]:
        """Extract answer from highlighted text."""
        # Find highlighted segments
        matches = re.findall(r'<hl>(.*?)<hl>', highlighted_text)
        if matches:
            return matches[0]
        return None
    
    def _clean_question(self, question: str) -> str:
        """Clean and normalize generated question."""
        # Remove extra whitespace
        question = re.sub(r'\s+', ' ', question).strip()
        
        # Ensure question ends with question mark
        if not question.endswith('?'):
            question += '?'
        
        # Capitalize first letter
        if question:
            question = question[0].upper() + question[1:]
        
        # Remove common generation artifacts
        artifacts = ['<hl>', '</hl>', '<pad>', '</s>']
        for artifact in artifacts:
            question = question.replace(artifact, '')
        
        return question
    
    def generate_questions_from_corpus(self,
                                     chunks: Dict[str, List[Dict]],
                                     target_count: int = 100,
                                     output_path: Optional[str] = None) -> List[Dict]:
        """
        Generate questions from entire corpus.
        
        Args:
            chunks: Dictionary of processed chunks
            target_count: Target number of questions to generate
            output_path: Path to save questions
            
        Returns:
            List of generated questions
        """
        print(f"Generating {target_count} questions from corpus...")
        
        all_questions = []
        articles_processed = 0
        
        # Calculate questions per article
        total_articles = len(chunks)
        questions_per_article = max(1, target_count // total_articles)
        
        for url, chunk_list in chunks.items():
            if len(all_questions) >= target_count:
                break
            
            # Combine chunks for this article
            article_text = ' '.join([chunk['text'] for chunk in chunk_list])
            title = chunk_list[0]['title'] if chunk_list else 'Unknown'
            
            # Limit text length for processing
            if len(article_text) > 2000:
                article_text = article_text[:2000]
            
            # Generate questions using both methods
            template_questions = []
            model_questions = []
            
            if self.use_templates:
                template_questions = self.generate_template_questions(
                    article_text, title, url, 
                    num_questions=min(questions_per_article, self.max_questions_per_article)
                )
            
            if self.qg_pipeline:
                model_questions = self.generate_model_questions(
                    article_text, title, url,
                    num_questions=min(questions_per_article, self.max_questions_per_article)
                )
            
            # Combine and select best questions
            article_questions = template_questions + model_questions
            
            # Add to main list
            all_questions.extend(article_questions)
            articles_processed += 1
            
            if articles_processed % 10 == 0:
                print(f"Processed {articles_processed}/{total_articles} articles, "
                      f"generated {len(all_questions)} questions")
        
        # Ensure we have enough questions
        if len(all_questions) < target_count:
            print(f"Warning: Only generated {len(all_questions)} questions, "
                  f"target was {target_count}")
        
        # Select diverse questions
        final_questions = self._select_diverse_questions(all_questions, target_count)
        
        # Add question IDs and metadata
        for i, question in enumerate(final_questions):
            question['question_id'] = f"q_{i+1:03d}"
            question['difficulty'] = self._assess_question_difficulty(question)
        
        print(f"Generated {len(final_questions)} final questions")
        
        # Save questions if output path provided
        if output_path:
            output_file = Path(output_path)
            output_file.parent.mkdir(parents=True, exist_ok=True)
            
            with open(output_file, 'w') as f:
                json.dump(final_questions, f, indent=2)
            
            print(f"Questions saved to {output_file}")
        
        return final_questions
    
    def _select_diverse_questions(self, 
                                questions: List[Dict], 
                                target_count: int) -> List[Dict]:
        """Select diverse questions from the generated set."""
        if len(questions) <= target_count:
            return questions
        
        # Group questions by type and source
        by_type = {}
        by_source = {}
        
        for q in questions:
            q_type = q.get('question_type', 'unknown')
            source = q.get('source_title', 'unknown')
            
            if q_type not in by_type:
                by_type[q_type] = []
            by_type[q_type].append(q)
            
            if source not in by_source:
                by_source[source] = []
            by_source[source].append(q)
        
        # Try to maintain balance across types and sources
        selected = []
        questions_per_type = target_count // len(by_type)
        
        for q_type, type_questions in by_type.items():
            type_selected = min(len(type_questions), questions_per_type)
            
            # Randomly sample from this type
            sampled = random.sample(type_questions, type_selected)
            selected.extend(sampled)
        
        # Fill remaining slots randomly
        remaining_count = target_count - len(selected)
        if remaining_count > 0:
            remaining_questions = [q for q in questions if q not in selected]
            if remaining_questions:
                additional = random.sample(
                    remaining_questions, 
                    min(len(remaining_questions), remaining_count)
                )
                selected.extend(additional)
        
        return selected[:target_count]
    
    def _assess_question_difficulty(self, question: Dict) -> str:
        """Assess the difficulty level of a question."""
        q_text = question['question'].lower()
        q_type = question.get('question_type', 'unknown')
        
        # Simple heuristics for difficulty assessment
        if q_type in ['factual'] and any(word in q_text for word in ['what is', 'who is', 'when']):
            return 'easy'
        elif q_type in ['comparative', 'multi_hop']:
            return 'hard'
        elif 'why' in q_text or 'how' in q_text:
            return 'medium'
        else:
            return 'medium'
    
    def get_generation_stats(self, questions: List[Dict]) -> Dict:
        """Get statistics about generated questions."""
        if not questions:
            return {}
        
        # Count by type
        type_counts = {}
        method_counts = {}
        difficulty_counts = {}
        
        for q in questions:
            q_type = q.get('question_type', 'unknown')
            method = q.get('generation_method', 'unknown')
            difficulty = q.get('difficulty', 'unknown')
            
            type_counts[q_type] = type_counts.get(q_type, 0) + 1
            method_counts[method] = method_counts.get(method, 0) + 1
            difficulty_counts[difficulty] = difficulty_counts.get(difficulty, 0) + 1
        
        # Average question length
        question_lengths = [len(q['question'].split()) for q in questions]
        avg_question_length = sum(question_lengths) / len(question_lengths)
        
        # Average answer length
        answer_lengths = [len(q['answer'].split()) for q in questions if q.get('answer')]
        avg_answer_length = sum(answer_lengths) / len(answer_lengths) if answer_lengths else 0
        
        return {
            'total_questions': len(questions),
            'by_type': type_counts,
            'by_method': method_counts,
            'by_difficulty': difficulty_counts,
            'avg_question_length': avg_question_length,
            'avg_answer_length': avg_answer_length,
            'unique_sources': len(set(q.get('source_title', '') for q in questions))
        }


def main():
    """Test the question generator."""
    generator = QuestionGenerator()
    
    # Test text
    test_text = """
    Artificial intelligence (AI) is intelligence demonstrated by machines, 
    in contrast to the natural intelligence displayed by humans and animals. 
    Leading AI textbooks define the field as the study of "intelligent agents": 
    any device that perceives its environment and takes actions that maximize 
    its chance of successfully achieving its goals. John McCarthy coined the 
    term "artificial intelligence" in 1956.
    """
    
    # Generate questions
    questions = generator.generate_template_questions(
        test_text, 
        "Artificial Intelligence",
        "https://example.com",
        num_questions=3
    )
    
    print("Generated Questions:")
    for i, q in enumerate(questions, 1):
        print(f"\n{i}. Question: {q['question']}")
        print(f"   Answer: {q['answer']}")
        print(f"   Type: {q['question_type']}")


if __name__ == "__main__":
    main()