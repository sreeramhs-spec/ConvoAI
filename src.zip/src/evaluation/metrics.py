"""
Comprehensive evaluation metrics for RAG systems.

This module implements various evaluation metrics including:
- Mean Reciprocal Rank (MRR) at URL level
- ROUGE-L for answer quality assessment
- Retrieval Precision@K for context relevance
- Custom semantic similarity metrics
- Confidence calibration measures
"""

import json
import math
from collections import defaultdict
from typing import Dict, List, Optional, Set, Tuple, Union

import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer

try:
    from rouge_score import rouge_scorer
    ROUGE_AVAILABLE = True
except ImportError:
    ROUGE_AVAILABLE = False
    print("Warning: rouge-score not available. ROUGE metrics will be disabled.")

try:
    from bert_score import score as bert_score
    BERT_SCORE_AVAILABLE = True
except ImportError:
    BERT_SCORE_AVAILABLE = False
    print("Warning: bert-score not available. BERTScore metrics will be disabled.")


class MetricsCalculator:
    """Calculates comprehensive evaluation metrics for RAG systems."""
    
    def __init__(self, 
                 embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2",
                 rouge_types: List[str] = None):
        """
        Initialize the metrics calculator.
        
        Args:
            embedding_model: Model for semantic similarity calculations
            rouge_types: ROUGE metric types to calculate
        """
        self.embedding_model_name = embedding_model
        self.rouge_types = rouge_types or ['rouge1', 'rouge2', 'rougeL']
        
        # Initialize embedding model for semantic similarity
        try:
            self.embedding_model = SentenceTransformer(embedding_model)
        except Exception as e:
            print(f"Warning: Could not load embedding model {embedding_model}: {e}")
            self.embedding_model = None
        
        # Initialize ROUGE scorer
        if ROUGE_AVAILABLE:
            self.rouge_scorer = rouge_scorer.RougeScorer(
                self.rouge_types, use_stemmer=True
            )
        else:
            self.rouge_scorer = None
        
        print("Metrics calculator initialized")
    
    def calculate_mrr_url_level(self, 
                               questions: List[Dict],
                               retrieval_results: List[List[Dict]]) -> Dict:
        """
        Calculate Mean Reciprocal Rank at URL level.
        
        This is the mandatory metric that measures how quickly the system
        identifies the correct source document (Wikipedia URL).
        
        Args:
            questions: List of questions with ground truth URLs
            retrieval_results: List of retrieval results for each question
            
        Returns:
            Dictionary with MRR metrics and analysis
        """
        reciprocal_ranks = []
        detailed_results = []
        
        for i, (question, results) in enumerate(zip(questions, retrieval_results)):
            # Get ground truth URL(s)
            ground_truth_url = question.get('source_url', '')
            if not ground_truth_url:
                continue
            
            # Find rank of first correct URL
            rank = None
            for j, result in enumerate(results, 1):
                result_url = result.get('url', '')
                if result_url == ground_truth_url:
                    rank = j
                    break
            
            # Calculate reciprocal rank
            if rank is not None:
                rr = 1.0 / rank
                reciprocal_ranks.append(rr)
                
                detailed_results.append({
                    'question_id': question.get('question_id', f'q_{i}'),
                    'question': question.get('question', ''),
                    'ground_truth_url': ground_truth_url,
                    'found_at_rank': rank,
                    'reciprocal_rank': rr
                })
            else:
                # URL not found in results
                reciprocal_ranks.append(0.0)
                detailed_results.append({
                    'question_id': question.get('question_id', f'q_{i}'),
                    'question': question.get('question', ''),
                    'ground_truth_url': ground_truth_url,
                    'found_at_rank': None,
                    'reciprocal_rank': 0.0
                })
        
        # Calculate overall MRR
        mrr = np.mean(reciprocal_ranks) if reciprocal_ranks else 0.0
        
        # Additional statistics
        found_count = sum(1 for rr in reciprocal_ranks if rr > 0)
        total_count = len(reciprocal_ranks)
        hit_rate = found_count / total_count if total_count > 0 else 0.0
        
        # Rank distribution
        rank_distribution = defaultdict(int)
        for result in detailed_results:
            rank = result['found_at_rank']
            if rank is not None:
                if rank <= 1:
                    rank_distribution['@1'] += 1
                if rank <= 3:
                    rank_distribution['@3'] += 1
                if rank <= 5:
                    rank_distribution['@5'] += 1
                if rank <= 10:
                    rank_distribution['@10'] += 1
        
        return {
            'metric_name': 'Mean Reciprocal Rank (URL Level)',
            'mrr': mrr,
            'hit_rate': hit_rate,
            'total_questions': total_count,
            'questions_found': found_count,
            'precision_at_k': {
                k: count / total_count for k, count in rank_distribution.items()
            },
            'detailed_results': detailed_results,
            'interpretation': {
                'description': 'Measures how quickly the system identifies correct source documents',
                'range': '0.0 to 1.0 (higher is better)',
                'significance': f'MRR of {mrr:.3f} means on average the correct URL appears at rank {1/mrr:.1f}' if mrr > 0 else 'No correct URLs found'
            }
        }
    
    def calculate_rouge_l(self,
                         questions: List[Dict],
                         generated_answers: List[str]) -> Dict:
        """
        Calculate ROUGE-L scores for answer quality assessment.
        
        ROUGE-L measures the longest common subsequence between
        generated answers and reference answers, providing insight
        into content overlap and fluency.
        
        Args:
            questions: List of questions with reference answers
            generated_answers: List of generated answers
            
        Returns:
            Dictionary with ROUGE-L metrics and analysis
        """
        if not self.rouge_scorer:
            return {
                'metric_name': 'ROUGE-L',
                'error': 'ROUGE scorer not available',
                'rouge_l_f1': 0.0,
                'rouge_l_precision': 0.0,
                'rouge_l_recall': 0.0
            }
        
        rouge_scores = []
        detailed_results = []
        
        for i, (question, generated_answer) in enumerate(zip(questions, generated_answers)):
            reference_answer = question.get('answer', '')
            if not reference_answer or not generated_answer:
                continue
            
            # Calculate ROUGE scores
            scores = self.rouge_scorer.score(reference_answer, generated_answer)
            rouge_l = scores['rougeL']
            
            rouge_scores.append({
                'precision': rouge_l.precision,
                'recall': rouge_l.recall,
                'f1': rouge_l.fmeasure
            })
            
            detailed_results.append({
                'question_id': question.get('question_id', f'q_{i}'),
                'question': question.get('question', '')[:100] + '...',
                'reference_answer': reference_answer[:150] + '...',
                'generated_answer': generated_answer[:150] + '...',
                'rouge_l_f1': rouge_l.fmeasure,
                'rouge_l_precision': rouge_l.precision,
                'rouge_l_recall': rouge_l.recall
            })
        
        # Calculate averages
        if rouge_scores:
            avg_precision = np.mean([s['precision'] for s in rouge_scores])
            avg_recall = np.mean([s['recall'] for s in rouge_scores])
            avg_f1 = np.mean([s['f1'] for s in rouge_scores])
        else:
            avg_precision = avg_recall = avg_f1 = 0.0
        
        return {
            'metric_name': 'ROUGE-L (Answer Quality)',
            'rouge_l_precision': avg_precision,
            'rouge_l_recall': avg_recall,
            'rouge_l_f1': avg_f1,
            'total_evaluated': len(rouge_scores),
            'detailed_results': detailed_results[:10],  # Show top 10 for brevity
            'interpretation': {
                'description': 'Measures longest common subsequence overlap between generated and reference answers',
                'range': '0.0 to 1.0 (higher is better)',
                'precision_meaning': 'How much of the generated answer overlaps with reference',
                'recall_meaning': 'How much of the reference answer is captured in generated answer',
                'f1_meaning': 'Harmonic mean of precision and recall',
                'significance': self._interpret_rouge_score(avg_f1)
            }
        }
    
    def calculate_retrieval_precision_at_k(self,
                                          questions: List[Dict],
                                          retrieval_results: List[List[Dict]],
                                          k_values: List[int] = None) -> Dict:
        """
        Calculate Retrieval Precision@K for context relevance assessment.
        
        This measures the proportion of retrieved chunks that come from
        the correct source document, evaluating retrieval quality.
        
        Args:
            questions: List of questions with ground truth
            retrieval_results: List of retrieval results for each question
            k_values: List of K values to evaluate
            
        Returns:
            Dictionary with Precision@K metrics and analysis
        """
        k_values = k_values or [1, 3, 5, 10, 20]
        
        precision_at_k = {k: [] for k in k_values}
        detailed_results = []
        
        for i, (question, results) in enumerate(zip(questions, retrieval_results)):
            ground_truth_url = question.get('source_url', '')
            if not ground_truth_url:
                continue
            
            question_precision = {}
            
            for k in k_values:
                top_k_results = results[:k]
                relevant_count = sum(1 for result in top_k_results 
                                   if result.get('url', '') == ground_truth_url)
                precision = relevant_count / k if k > 0 else 0.0
                precision_at_k[k].append(precision)
                question_precision[f'precision@{k}'] = precision
            
            detailed_results.append({
                'question_id': question.get('question_id', f'q_{i}'),
                'question': question.get('question', '')[:100] + '...',
                'ground_truth_url': ground_truth_url,
                **question_precision
            })
        
        # Calculate average precision at each K
        avg_precision_at_k = {}
        for k in k_values:
            if precision_at_k[k]:
                avg_precision_at_k[f'precision@{k}'] = np.mean(precision_at_k[k])
            else:
                avg_precision_at_k[f'precision@{k}'] = 0.0
        
        return {
            'metric_name': 'Retrieval Precision@K',
            **avg_precision_at_k,
            'total_evaluated': len([q for q in questions if q.get('source_url')]),
            'detailed_results': detailed_results[:10],
            'interpretation': {
                'description': 'Measures proportion of retrieved chunks from correct source document',
                'range': '0.0 to 1.0 (higher is better)',
                'precision_at_1_meaning': 'Whether the top result is from the correct source',
                'precision_at_k_meaning': 'Average proportion of top-K results from correct source',
                'significance': self._interpret_precision_at_k(avg_precision_at_k.get('precision@10', 0))
            }
        }
    
    def calculate_semantic_similarity(self,
                                    questions: List[Dict],
                                    generated_answers: List[str]) -> Dict:
        """
        Calculate semantic similarity between generated and reference answers.
        
        This custom metric uses sentence embeddings to measure semantic
        closeness beyond surface-level text overlap.
        
        Args:
            questions: List of questions with reference answers
            generated_answers: List of generated answers
            
        Returns:
            Dictionary with semantic similarity metrics
        """
        if not self.embedding_model:
            return {
                'metric_name': 'Semantic Similarity',
                'error': 'Embedding model not available',
                'semantic_similarity': 0.0
            }
        
        similarities = []
        detailed_results = []
        
        reference_answers = []
        generated_answers_clean = []
        
        for i, (question, generated_answer) in enumerate(zip(questions, generated_answers)):
            reference_answer = question.get('answer', '')
            if not reference_answer or not generated_answer:
                continue
            
            reference_answers.append(reference_answer)
            generated_answers_clean.append(generated_answer)
        
        if not reference_answers:
            return {
                'metric_name': 'Semantic Similarity',
                'semantic_similarity': 0.0,
                'total_evaluated': 0
            }
        
        # Get embeddings for all answers at once (more efficient)
        try:
            ref_embeddings = self.embedding_model.encode(reference_answers)
            gen_embeddings = self.embedding_model.encode(generated_answers_clean)
            
            # Calculate pairwise cosine similarities
            for i, (ref_emb, gen_emb) in enumerate(zip(ref_embeddings, gen_embeddings)):
                similarity = cosine_similarity([ref_emb], [gen_emb])[0][0]
                similarities.append(similarity)
                
                detailed_results.append({
                    'question_id': questions[i].get('question_id', f'q_{i}'),
                    'semantic_similarity': similarity,
                    'reference_answer': reference_answers[i][:100] + '...',
                    'generated_answer': generated_answers_clean[i][:100] + '...'
                })
        
        except Exception as e:
            print(f"Error calculating semantic similarity: {e}")
            return {
                'metric_name': 'Semantic Similarity',
                'error': str(e),
                'semantic_similarity': 0.0
            }
        
        avg_similarity = np.mean(similarities) if similarities else 0.0
        
        return {
            'metric_name': 'Semantic Similarity (Custom)',
            'semantic_similarity': avg_similarity,
            'total_evaluated': len(similarities),
            'std_deviation': np.std(similarities) if similarities else 0.0,
            'detailed_results': detailed_results[:10],
            'interpretation': {
                'description': 'Measures semantic closeness using sentence embeddings',
                'range': '-1.0 to 1.0 (higher is better, >0.5 is good)',
                'methodology': f'Uses {self.embedding_model_name} embeddings with cosine similarity',
                'significance': self._interpret_semantic_similarity(avg_similarity)
            }
        }
    
    def calculate_confidence_calibration(self,
                                       questions: List[Dict],
                                       generated_answers: List[str],
                                       confidence_scores: List[float] = None) -> Dict:
        """
        Calculate confidence calibration metrics.
        
        This innovative metric measures how well the system's confidence
        correlates with actual answer correctness.
        
        Args:
            questions: List of questions
            generated_answers: List of generated answers  
            confidence_scores: List of confidence scores (if available)
            
        Returns:
            Dictionary with calibration metrics
        """
        if not confidence_scores:
            # Generate pseudo-confidence scores based on answer characteristics
            confidence_scores = self._estimate_confidence_scores(generated_answers)
        
        # Calculate answer correctness using multiple signals
        correctness_scores = []
        for question, generated_answer in zip(questions, generated_answers):
            correctness = self._estimate_answer_correctness(question, generated_answer)
            correctness_scores.append(correctness)
        
        if len(confidence_scores) != len(correctness_scores):
            return {
                'metric_name': 'Confidence Calibration',
                'error': 'Mismatched confidence and correctness arrays'
            }
        
        # Calculate calibration curve (binned analysis)
        bins = 10
        bin_boundaries = np.linspace(0, 1, bins + 1)
        bin_lowers = bin_boundaries[:-1]
        bin_uppers = bin_boundaries[1:]
        
        calibration_data = []
        ece = 0.0  # Expected Calibration Error
        
        for bin_lower, bin_upper in zip(bin_lowers, bin_uppers):
            in_bin = [(conf >= bin_lower) & (conf < bin_upper) 
                     for conf in confidence_scores]
            prop_in_bin = np.mean(in_bin)
            
            if prop_in_bin > 0:
                accuracy_in_bin = np.mean([correctness_scores[i] 
                                         for i, in_b in enumerate(in_bin) if in_b])
                avg_confidence_in_bin = np.mean([confidence_scores[i] 
                                               for i, in_b in enumerate(in_bin) if in_b])
                
                calibration_data.append({
                    'bin_lower': bin_lower,
                    'bin_upper': bin_upper,
                    'avg_confidence': avg_confidence_in_bin,
                    'accuracy': accuracy_in_bin,
                    'proportion': prop_in_bin,
                    'calibration_error': abs(avg_confidence_in_bin - accuracy_in_bin)
                })
                
                ece += prop_in_bin * abs(avg_confidence_in_bin - accuracy_in_bin)
        
        # Overall correlation
        correlation = np.corrcoef(confidence_scores, correctness_scores)[0, 1] if len(confidence_scores) > 1 else 0.0
        
        return {
            'metric_name': 'Confidence Calibration (Innovation)',
            'expected_calibration_error': ece,
            'confidence_correctness_correlation': correlation,
            'total_evaluated': len(confidence_scores),
            'calibration_curve': calibration_data,
            'interpretation': {
                'description': 'Measures how well confidence scores correlate with answer correctness',
                'ece_meaning': 'Expected Calibration Error - lower is better (0 = perfect calibration)',
                'correlation_meaning': 'Pearson correlation between confidence and correctness',
                'significance': self._interpret_calibration(ece, correlation)
            }
        }
    
    def _estimate_confidence_scores(self, generated_answers: List[str]) -> List[float]:
        """Estimate confidence scores based on answer characteristics."""
        confidence_scores = []
        
        for answer in generated_answers:
            confidence = 0.5  # Base confidence
            
            # Length factor (moderate length suggests more confident)
            word_count = len(answer.split())
            if 20 <= word_count <= 100:
                confidence += 0.2
            elif word_count < 5:
                confidence -= 0.3
            
            # Definitiveness indicators
            definitive_phrases = ['is', 'are', 'was', 'were', 'definitely', 'specifically']
            if any(phrase in answer.lower() for phrase in definitive_phrases):
                confidence += 0.1
            
            # Uncertainty indicators  
            uncertain_phrases = ['might', 'could', 'possibly', 'perhaps', 'unclear', 'unknown']
            if any(phrase in answer.lower() for phrase in uncertain_phrases):
                confidence -= 0.2
            
            # Ensure confidence is in [0, 1]
            confidence = max(0.0, min(1.0, confidence))
            confidence_scores.append(confidence)
        
        return confidence_scores
    
    def _estimate_answer_correctness(self, question: Dict, generated_answer: str) -> float:
        """Estimate answer correctness using multiple signals."""
        correctness = 0.0
        
        reference_answer = question.get('answer', '')
        if not reference_answer:
            return 0.5  # Neutral if no reference
        
        # Simple word overlap
        ref_words = set(reference_answer.lower().split())
        gen_words = set(generated_answer.lower().split())
        
        if ref_words:
            word_overlap = len(ref_words & gen_words) / len(ref_words)
            correctness += word_overlap * 0.4
        
        # Length similarity
        ref_len = len(reference_answer.split())
        gen_len = len(generated_answer.split())
        
        if ref_len > 0:
            length_sim = 1 - abs(ref_len - gen_len) / max(ref_len, gen_len)
            correctness += length_sim * 0.2
        
        # Semantic similarity (if available)
        if self.embedding_model:
            try:
                ref_emb = self.embedding_model.encode([reference_answer])
                gen_emb = self.embedding_model.encode([generated_answer])
                sem_sim = cosine_similarity(ref_emb, gen_emb)[0][0]
                correctness += sem_sim * 0.4
            except:
                correctness += 0.2  # Default bonus
        else:
            correctness += 0.2
        
        return max(0.0, min(1.0, correctness))
    
    def _interpret_rouge_score(self, rouge_f1: float) -> str:
        """Interpret ROUGE-L F1 score."""
        if rouge_f1 >= 0.6:
            return "Excellent overlap with reference answers"
        elif rouge_f1 >= 0.4:
            return "Good overlap with reference answers"
        elif rouge_f1 >= 0.2:
            return "Moderate overlap with reference answers"
        else:
            return "Low overlap with reference answers"
    
    def _interpret_precision_at_k(self, precision_10: float) -> str:
        """Interpret Precision@10 score."""
        if precision_10 >= 0.8:
            return "Excellent retrieval - most results from correct sources"
        elif precision_10 >= 0.6:
            return "Good retrieval - majority of results from correct sources"
        elif precision_10 >= 0.4:
            return "Fair retrieval - some results from correct sources"
        else:
            return "Poor retrieval - few results from correct sources"
    
    def _interpret_semantic_similarity(self, similarity: float) -> str:
        """Interpret semantic similarity score."""
        if similarity >= 0.8:
            return "Very high semantic alignment with reference answers"
        elif similarity >= 0.6:
            return "High semantic alignment with reference answers"
        elif similarity >= 0.4:
            return "Moderate semantic alignment with reference answers"
        else:
            return "Low semantic alignment with reference answers"
    
    def _interpret_calibration(self, ece: float, correlation: float) -> str:
        """Interpret calibration metrics."""
        calibration_quality = "good" if ece < 0.1 else "fair" if ece < 0.2 else "poor"
        correlation_quality = "strong" if abs(correlation) > 0.7 else "moderate" if abs(correlation) > 0.4 else "weak"
        
        return f"Calibration quality is {calibration_quality} (ECE={ece:.3f}), confidence-correctness correlation is {correlation_quality} (r={correlation:.3f})"
    
    def calculate_all_metrics(self,
                             questions: List[Dict],
                             retrieval_results: List[List[Dict]],
                             generated_answers: List[str],
                             confidence_scores: List[float] = None) -> Dict:
        """
        Calculate all evaluation metrics.
        
        Args:
            questions: List of evaluation questions
            retrieval_results: List of retrieval results for each question
            generated_answers: List of generated answers
            confidence_scores: Optional confidence scores
            
        Returns:
            Dictionary with all calculated metrics
        """
        print("Calculating comprehensive evaluation metrics...")
        
        all_metrics = {}
        
        # 1. Mean Reciprocal Rank (Mandatory)
        print("Calculating MRR at URL level...")
        mrr_results = self.calculate_mrr_url_level(questions, retrieval_results)
        all_metrics['mrr_url_level'] = mrr_results
        
        # 2. ROUGE-L (Custom Metric 1)
        print("Calculating ROUGE-L scores...")
        rouge_results = self.calculate_rouge_l(questions, generated_answers)
        all_metrics['rouge_l'] = rouge_results
        
        # 3. Retrieval Precision@K (Custom Metric 2)
        print("Calculating Retrieval Precision@K...")
        precision_results = self.calculate_retrieval_precision_at_k(questions, retrieval_results)
        all_metrics['retrieval_precision_at_k'] = precision_results
        
        # 4. Semantic Similarity (Additional Custom Metric)
        print("Calculating Semantic Similarity...")
        similarity_results = self.calculate_semantic_similarity(questions, generated_answers)
        all_metrics['semantic_similarity'] = similarity_results
        
        # 5. Confidence Calibration (Innovation Metric)
        print("Calculating Confidence Calibration...")
        calibration_results = self.calculate_confidence_calibration(
            questions, generated_answers, confidence_scores
        )
        all_metrics['confidence_calibration'] = calibration_results
        
        # Overall summary
        all_metrics['summary'] = {
            'total_questions_evaluated': len(questions),
            'primary_metrics': {
                'mrr': mrr_results.get('mrr', 0.0),
                'rouge_l_f1': rouge_results.get('rouge_l_f1', 0.0),
                'precision_at_10': precision_results.get('precision@10', 0.0)
            },
            'innovative_metrics': {
                'semantic_similarity': similarity_results.get('semantic_similarity', 0.0),
                'expected_calibration_error': calibration_results.get('expected_calibration_error', 1.0)
            }
        }
        
        print("All metrics calculated successfully")
        return all_metrics


def main():
    """Test the metrics calculator."""
    calculator = MetricsCalculator()
    
    # Sample data
    questions = [
        {
            'question_id': 'q_001',
            'question': 'What is artificial intelligence?',
            'answer': 'Artificial intelligence is the simulation of human intelligence in machines.',
            'source_url': 'https://en.wikipedia.org/wiki/Artificial_intelligence'
        }
    ]
    
    retrieval_results = [[
        {
            'chunk_id': 'chunk_1',
            'url': 'https://en.wikipedia.org/wiki/Artificial_intelligence',
            'text': 'AI is machine intelligence...'
        },
        {
            'chunk_id': 'chunk_2', 
            'url': 'https://en.wikipedia.org/wiki/Machine_learning',
            'text': 'ML is a subset of AI...'
        }
    ]]
    
    generated_answers = [
        'Artificial intelligence refers to machine intelligence that simulates human cognitive abilities.'
    ]
    
    # Calculate metrics
    results = calculator.calculate_all_metrics(questions, retrieval_results, generated_answers)
    
    print("Evaluation Results:")
    print(f"MRR: {results['mrr_url_level']['mrr']:.3f}")
    print(f"ROUGE-L F1: {results['rouge_l']['rouge_l_f1']:.3f}")
    print(f"Precision@10: {results['retrieval_precision_at_k']['precision@10']:.3f}")


if __name__ == "__main__":
    main()