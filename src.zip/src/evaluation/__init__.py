"""
Evaluation framework components for the hybrid RAG system.

This package provides comprehensive evaluation capabilities including:
- Automated question generation from Wikipedia corpus
- Multi-metric evaluation (MRR, ROUGE-L, Precision@K, Semantic Similarity)
- Ablation studies comparing different system configurations
- Error analysis and failure categorization
- Comprehensive reporting with recommendations
"""

from .question_generator import QuestionGenerator
from .metrics import MetricsCalculator
from .evaluator import RAGEvaluator

__all__ = ['QuestionGenerator', 'MetricsCalculator', 'RAGEvaluator']