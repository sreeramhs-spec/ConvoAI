"""
Advanced Evaluation Visualizations
Creates interactive dashboards and visualizations for advanced RAG evaluation metrics
"""

import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import pandas as pd
import numpy as np
from typing import Dict, List, Any
from collections import defaultdict


class EvaluationVisualizer:
    """Creates comprehensive visualizations for evaluation results"""
    
    def __init__(self):
        self.color_palette = {
            'primary': '#1f77b4',
            'secondary': '#ff7f0e', 
            'success': '#2ca02c',
            'warning': '#d62728',
            'info': '#9467bd',
            'light': '#17becf'
        }
    
    def create_adversarial_testing_dashboard(self, adversarial_results: Dict[str, Any]):
        """Create dashboard for adversarial testing results"""
        
        st.subheader("🎯 Adversarial Testing Results")
        
        # Summary metrics
        col1, col2, col3, col4 = st.columns(4)
        
        total_tests = sum(len(results) for results in adversarial_results.values())
        passed_tests = sum(
            len([r for r in results if r.get('has_answer', False)]) 
            for results in adversarial_results.values()
        )
        pass_rate = passed_tests / total_tests if total_tests > 0 else 0
        
        with col1:
            st.metric("Total Tests", total_tests)
        with col2:
            st.metric("Passed Tests", passed_tests)
        with col3:
            st.metric("Pass Rate", f"{pass_rate:.1%}")
        with col4:
            avg_confidence = np.mean([
                r.get('confidence', 0) 
                for results in adversarial_results.values()
                for r in results
            ])
            st.metric("Avg Confidence", f"{avg_confidence:.2f}")
        
        # Performance by category
        col1, col2 = st.columns(2)
        
        with col1:
            # Category performance breakdown
            category_data = []
            for category, results in adversarial_results.items():
                category_passed = len([r for r in results if r.get('has_answer', False)])
                category_total = len(results)
                category_rate = category_passed / category_total if category_total > 0 else 0
                
                category_data.append({
                    'Category': category.replace('_', ' ').title(),
                    'Pass Rate': category_rate,
                    'Total Tests': category_total,
                    'Passed Tests': category_passed
                })
            
            df_categories = pd.DataFrame(category_data)
            
            fig = px.bar(df_categories, x='Category', y='Pass Rate',
                        title="Performance by Adversarial Category",
                        color='Pass Rate',
                        color_continuous_scale='RdYlGn')
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Response time distribution
            response_times = [
                r.get('response_time', 0) 
                for results in adversarial_results.values()
                for r in results
            ]
            
            fig = px.histogram(x=response_times, nbins=20,
                              title="Response Time Distribution",
                              labels={'x': 'Response Time (s)', 'y': 'Count'})
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        # Detailed results table
        st.subheader("📊 Detailed Results by Category")
        
        tab_names = list(adversarial_results.keys())
        tabs = st.tabs([name.replace('_', ' ').title() for name in tab_names])
        
        for tab, (category, results) in zip(tabs, adversarial_results.items()):
            with tab:
                if results:
                    df_results = pd.DataFrame(results)
                    st.dataframe(df_results, use_container_width=True)
                else:
                    st.info("No results available for this category")
    
    def create_ablation_study_dashboard(self, ablation_df: pd.DataFrame):
        """Create dashboard for ablation study results"""
        
        st.subheader("🔬 Ablation Study Results")
        
        # Method comparison
        col1, col2 = st.columns(2)
        
        with col1:
            # Average performance by method
            method_performance = ablation_df.groupby('method').agg({
                'mrr': 'mean',
                'precision': 'mean', 
                'recall': 'mean',
                'f1': 'mean'
            }).reset_index()
            
            fig = px.bar(method_performance.melt(id_vars=['method'], 
                                               value_vars=['mrr', 'precision', 'recall', 'f1']),
                        x='method', y='value', color='variable',
                        title="Average Performance by Method",
                        barmode='group')
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Top-K performance analysis
            topk_performance = ablation_df.groupby('top_k')['mrr'].mean().reset_index()
            
            fig = px.line(topk_performance, x='top_k', y='mrr',
                         title="Performance vs Top-K Values",
                         markers=True)
            fig.update_layout(height=400)
            st.plotly_chart(fig, use_container_width=True)
        
        # RRF parameter analysis
        if 'rrf_k' in ablation_df.columns:
            st.subheader("🔄 RRF Parameter Analysis")
            
            hybrid_results = ablation_df[ablation_df['method'].str.contains('hybrid', na=False)]
            if not hybrid_results.empty:
                col1, col2 = st.columns(2)
                
                with col1:
                    # RRF-K vs Performance
                    rrf_performance = hybrid_results.groupby('rrf_k')['mrr'].mean().reset_index()
                    
                    fig = px.line(rrf_performance, x='rrf_k', y='mrr',
                                 title="RRF-K Parameter Impact",
                                 markers=True)
                    fig.update_layout(height=300)
                    st.plotly_chart(fig, use_container_width=True)
                
                with col2:
                    # Heatmap of parameter combinations
                    heatmap_data = hybrid_results.pivot_table(
                        values='mrr', index='rrf_k', columns='top_k', aggfunc='mean'
                    )
                    
                    fig = px.imshow(heatmap_data,
                                   title="Parameter Combination Heatmap",
                                   aspect='auto')
                    fig.update_layout(height=300)
                    st.plotly_chart(fig, use_container_width=True)
        
        # Statistical significance tests
        st.subheader("📈 Statistical Analysis")
        
        # Show best performing configurations
        best_configs = ablation_df.nlargest(5, 'mrr')[['method', 'top_k', 'rrf_k', 'mrr', 'f1']]
        st.write("**Top 5 Configurations:**")
        st.dataframe(best_configs, use_container_width=True)
    
    def create_confidence_calibration_dashboard(self, evaluation_results: List[Dict]):
        """Create dashboard for confidence calibration analysis"""
        
        st.subheader("🎯 Confidence Calibration Analysis")
        
        # Extract confidence and correctness data
        confidences = [r['confidence']['overall'] for r in evaluation_results]
        correctness = [r['score'] > 0.7 for r in evaluation_results]  # Binary correctness
        scores = [r['score'] for r in evaluation_results]
        
        col1, col2 = st.columns(2)
        
        with col1:
            # Confidence vs Correctness scatter plot
            df_calib = pd.DataFrame({
                'Confidence': confidences,
                'Score': scores,
                'Correct': correctness
            })
            
            fig = px.scatter(df_calib, x='Confidence', y='Score',
                           color='Correct',
                           title="Confidence vs Actual Performance",
                           trendline="ols")
            fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode='lines',
                                   name='Perfect Calibration', 
                                   line=dict(dash='dash', color='red')))
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Confidence distribution
            fig = px.histogram(x=confidences, nbins=20,
                              title="Confidence Score Distribution",
                              labels={'x': 'Confidence', 'y': 'Count'})
            st.plotly_chart(fig, use_container_width=True)
        
        # Calibration curve (if sklearn available)
        try:
            from sklearn.calibration import calibration_curve
            
            prob_true, prob_pred = calibration_curve(correctness, confidences, n_bins=5)
            
            fig = go.Figure()
            fig.add_trace(go.Scatter(x=prob_pred, y=prob_true,
                                   mode='lines+markers',
                                   name='Calibration Curve',
                                   line=dict(color='blue', width=3)))
            fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1],
                                   mode='lines',
                                   name='Perfect Calibration',
                                   line=dict(dash='dash', color='red')))
            
            fig.update_layout(
                title="Calibration Curve",
                xaxis_title="Mean Predicted Probability",
                yaxis_title="Fraction of Positives",
                height=400
            )
            
            st.plotly_chart(fig, use_container_width=True)
            
        except ImportError:
            st.info("Sklearn not available for detailed calibration curve")
    
    def create_novel_metrics_dashboard(self, novel_metrics: Dict[str, Any]):
        """Create dashboard for novel metrics"""
        
        st.subheader("🆕 Novel Metrics Dashboard")
        
        # Summary metrics
        col1, col2, col3 = st.columns(3)
        
        entity_metrics = novel_metrics.get('entity_coverage', {})
        diversity_metrics = novel_metrics.get('answer_diversity', {})
        hallucination_metrics = novel_metrics.get('hallucination_rate', {})
        
        with col1:
            st.metric(
                "Entity Coverage Rate",
                f"{entity_metrics.get('entity_coverage_rate', 0):.1%}",
                delta=f"{entity_metrics.get('covered_entities', 0)}/{entity_metrics.get('total_entities', 0)}"
            )
        
        with col2:
            st.metric(
                "Answer Diversity",
                f"{diversity_metrics.get('diversity_score', 0):.2f}",
                delta="Higher is better"
            )
        
        with col3:
            st.metric(
                "Hallucination Rate",
                f"{hallucination_metrics.get('hallucination_rate', 0):.1%}",
                delta="Lower is better"
            )
        
        # Detailed breakdowns
        col1, col2 = st.columns(2)
        
        with col1:
            # Diversity components
            diversity_components = {
                'Lexical Diversity': diversity_metrics.get('lexical_diversity', 0),
                'Semantic Diversity': diversity_metrics.get('semantic_diversity', 0)
            }
            
            fig = px.bar(x=list(diversity_components.keys()),
                        y=list(diversity_components.values()),
                        title="Diversity Components")
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Hallucination distribution
            if 'per_answer_scores' in hallucination_metrics:
                scores = hallucination_metrics['per_answer_scores']
                
                fig = px.histogram(x=scores, nbins=20,
                                  title="Hallucination Score Distribution",
                                  labels={'x': 'Hallucination Score', 'y': 'Count'})
                st.plotly_chart(fig, use_container_width=True)
    
    def create_llm_judge_dashboard(self, evaluation_results: List[Dict]):
        """Create dashboard for LLM-as-Judge evaluation"""
        
        st.subheader("⚖️ LLM-as-Judge Evaluation")
        
        # Extract LLM evaluation data
        criteria_scores = defaultdict(list)
        overall_scores = []
        
        for result in evaluation_results:
            llm_eval = result.get('llm_evaluation', {})
            
            for criterion, eval_data in llm_eval.items():
                if criterion != 'overall':
                    criteria_scores[criterion].append(eval_data.get('score', 0))
                else:
                    overall_scores.append(eval_data.get('score', 0))
        
        # Summary metrics
        col1, col2, col3, col4 = st.columns(4)
        
        criteria_names = ['factual_accuracy', 'completeness', 'relevance', 'coherence']
        
        for col, criterion in zip([col1, col2, col3, col4], criteria_names):
            with col:
                avg_score = np.mean(criteria_scores.get(criterion, [0]))
                st.metric(
                    criterion.replace('_', ' ').title(),
                    f"{avg_score:.2f}",
                    delta=f"out of 1.0"
                )
        
        # Detailed analysis
        col1, col2 = st.columns(2)
        
        with col1:
            # Radar chart of criteria
            categories = [name.replace('_', ' ').title() for name in criteria_names]
            values = [np.mean(criteria_scores.get(name, [0])) for name in criteria_names]
            
            fig = go.Figure()
            fig.add_trace(go.Scatterpolar(
                r=values + [values[0]],  # Close the polygon
                theta=categories + [categories[0]],
                fill='toself',
                name='LLM Judge Scores'
            ))
            
            fig.update_layout(
                polar=dict(
                    radialaxis=dict(
                        visible=True,
                        range=[0, 1]
                    )),
                showlegend=True,
                title="LLM Judge Criteria Scores"
            )
            
            st.plotly_chart(fig, use_container_width=True)
        
        with col2:
            # Score distribution comparison
            score_data = []
            for criterion in criteria_names:
                for score in criteria_scores.get(criterion, []):
                    score_data.append({
                        'Criterion': criterion.replace('_', ' ').title(),
                        'Score': score
                    })
            
            if score_data:
                df_scores = pd.DataFrame(score_data)
                
                fig = px.box(df_scores, x='Criterion', y='Score',
                            title="Score Distribution by Criterion")
                st.plotly_chart(fig, use_container_width=True)
        
        # Examples of high/low scoring responses
        st.subheader("📝 Example Evaluations")
        
        # Sort by overall score
        sorted_results = sorted(evaluation_results, 
                              key=lambda x: x.get('llm_evaluation', {}).get('overall', {}).get('score', 0),
                              reverse=True)
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.write("**🏆 Best Performance Example:**")
            if sorted_results:
                best_result = sorted_results[0]
                st.write(f"**Question:** {best_result.get('question', 'N/A')}")
                st.write(f"**Answer:** {best_result.get('answer', 'N/A')[:200]}...")
                
                llm_eval = best_result.get('llm_evaluation', {})
                overall_score = llm_eval.get('overall', {}).get('score', 0)
                st.write(f"**Overall Score:** {overall_score:.2f}")
        
        with col2:
            st.write("**⚠️ Needs Improvement Example:**")
            if sorted_results:
                worst_result = sorted_results[-1]
                st.write(f"**Question:** {worst_result.get('question', 'N/A')}")
                st.write(f"**Answer:** {worst_result.get('answer', 'N/A')[:200]}...")
                
                llm_eval = worst_result.get('llm_evaluation', {})
                overall_score = llm_eval.get('overall', {}).get('score', 0)
                st.write(f"**Overall Score:** {overall_score:.2f}")
    
    def create_error_analysis_dashboard(self, error_analysis: Dict[str, Any]):
        """Create dashboard for error analysis"""
        
        st.subheader("🔍 Error Analysis Dashboard")
        
        # Summary metrics
        col1, col2, col3 = st.columns(3)
        
        total_failures = error_analysis.get('total_failures', 0)
        failure_breakdown = error_analysis.get('failure_breakdown', {})
        patterns = error_analysis.get('patterns', [])
        
        with col1:
            st.metric("Total Failures", total_failures)
        with col2:
            most_common_failure = max(failure_breakdown.items(), key=lambda x: x[1]) if failure_breakdown else ("None", 0)
            st.metric("Most Common Failure", most_common_failure[0].replace('_', ' ').title())
        with col3:
            st.metric("Pattern Count", len(patterns))
        
        # Failure breakdown
        if failure_breakdown:
            col1, col2 = st.columns(2)
            
            with col1:
                # Failure type distribution
                failure_df = pd.DataFrame([
                    {'Failure Type': k.replace('_', ' ').title(), 'Count': v}
                    for k, v in failure_breakdown.items()
                ])
                
                fig = px.pie(failure_df, values='Count', names='Failure Type',
                            title="Failure Type Distribution")
                st.plotly_chart(fig, use_container_width=True)
            
            with col2:
                # Failure type bar chart
                fig = px.bar(failure_df, x='Failure Type', y='Count',
                            title="Failure Counts by Type")
                st.plotly_chart(fig, use_container_width=True)
        
        # Pattern analysis
        if patterns:
            st.subheader("🔍 Identified Patterns")
            for pattern in patterns:
                st.warning(f"⚠️ {pattern}")
        
        # Failure examples
        st.subheader("📊 Failure Examples by Category")
        
        failure_examples = error_analysis.get('failure_examples', {})
        if failure_examples:
            for category, examples in failure_examples.items():
                with st.expander(f"{category.replace('_', ' ').title()} Examples"):
                    for i, example in enumerate(examples, 1):
                        st.write(f"**Example {i}:**")
                        st.write(f"- Question: {example.get('question', 'N/A')}")
                        st.write(f"- Answer: {example.get('answer', 'N/A')}")
                        st.write(f"- Score: {example.get('score', 0):.2f}")
                        st.markdown("---")
    
    def create_comprehensive_dashboard(self, comprehensive_results: Dict[str, Any]):
        """Create main comprehensive dashboard"""
        
        st.title("🧪 Advanced RAG Evaluation Dashboard")
        
        # Overview metrics
        summary_stats = comprehensive_results.get('summary_stats', {})
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.metric("Total Questions", summary_stats.get('total_questions', 0))
        with col2:
            st.metric("Average Score", f"{summary_stats.get('average_score', 0):.2f}")
        with col3:
            st.metric("Average Confidence", f"{summary_stats.get('average_confidence', 0):.2f}")
        with col4:
            # Calculate overall system health score
            avg_score = summary_stats.get('average_score', 0)
            health_score = "🟢 Excellent" if avg_score > 0.8 else "🟡 Good" if avg_score > 0.6 else "🔴 Needs Work"
            st.metric("System Health", health_score)
        
        # Create tabbed interface for different evaluations
        tab1, tab2, tab3, tab4, tab5, tab6 = st.tabs([
            "🎯 Adversarial Testing",
            "🔬 Ablation Studies", 
            "🎯 Confidence Calibration",
            "🆕 Novel Metrics",
            "⚖️ LLM Judge",
            "🔍 Error Analysis"
        ])
        
        with tab1:
            self.create_adversarial_testing_dashboard(comprehensive_results.get('adversarial_testing', {}))
        
        with tab2:
            ablation_df = comprehensive_results.get('ablation_studies')
            if ablation_df is not None and not ablation_df.empty:
                self.create_ablation_study_dashboard(ablation_df)
            else:
                st.info("No ablation study data available")
        
        with tab3:
            evaluation_results = comprehensive_results.get('evaluation_results', [])
            if evaluation_results:
                self.create_confidence_calibration_dashboard(evaluation_results)
            else:
                st.info("No evaluation results available")
        
        with tab4:
            novel_metrics = comprehensive_results.get('novel_metrics', {})
            if novel_metrics:
                self.create_novel_metrics_dashboard(novel_metrics)
            else:
                st.info("No novel metrics data available")
        
        with tab5:
            evaluation_results = comprehensive_results.get('evaluation_results', [])
            if evaluation_results:
                self.create_llm_judge_dashboard(evaluation_results)
            else:
                st.info("No LLM judge data available")
        
        with tab6:
            error_analysis = comprehensive_results.get('error_analysis', {})
            if error_analysis:
                self.create_error_analysis_dashboard(error_analysis)
            else:  
                st.info("No error analysis data available")