"""
Advanced RAG Evaluation Framework
Implements comprehensive evaluation techniques including adversarial testing,
ablation studies, error analysis, LLM-as-Judge, confidence calibration, and novel metrics.
"""

import json
import time
import math
import numpy as np
import pandas as pd
from collections import defaultdict, Counter
from typing import List, Dict, Tuple, Optional, Any
from pathlib import Path
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots

# Try importing optional dependencies
try:
    from sklearn.calibration import calibration_curve
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

try:
    from sentence_transformers import SentenceTransformer
    TRANSFORMERS_AVAILABLE = True
except ImportError:
    TRANSFORMERS_AVAILABLE = False


class AdversarialTester:
    """Implements adversarial testing for RAG systems"""
    
    def __init__(self):
        self.test_categories = {
            'ambiguous': 'Questions with multiple valid interpretations',
            'negated': 'Questions with negation that could confuse the system',
            'multi_hop': 'Questions requiring multiple reasoning steps',
            'paraphrased': 'Same questions phrased differently',
            'unanswerable': 'Questions that cannot be answered from the corpus'
        }
    
    def generate_adversarial_questions(self, base_questions: List[str], num_variants: int = 3) -> Dict[str, List[str]]:
        """Generate adversarial variants of base questions"""
        adversarial_tests = defaultdict(list)
        
        for question in base_questions[:10]:  # Limit for demo
            # Ambiguous questions
            ambiguous_variants = [
                f"What about {question.lower().replace('?', '')}?",
                f"Tell me something about {question.lower().replace('what is', '').replace('?', '')}",
                f"Regarding {question.lower().replace('?', '')}, what can you say?"
            ]
            adversarial_tests['ambiguous'].extend(ambiguous_variants[:num_variants])
            
            # Negated questions
            negated_variants = [
                f"What is NOT {question.lower().replace('what is', '').replace('?', '')}?",
                f"Which aspects are NOT related to {question.lower().replace('what is', '').replace('?', '')}?",
                f"What doesn't {question.lower().replace('what', '').replace('?', '')}?"
            ]
            adversarial_tests['negated'].extend(negated_variants[:num_variants])
            
            # Multi-hop questions
            multi_hop_variants = [
                f"How does {question.lower().replace('what is', '').replace('?', '')} relate to artificial intelligence and what are the implications?",
                f"What are the advantages and disadvantages of {question.lower().replace('what is', '').replace('?', '')} in modern applications?",
                f"Compare {question.lower().replace('what is', '').replace('?', '')} with similar concepts and explain the differences"
            ]
            adversarial_tests['multi_hop'].extend(multi_hop_variants[:num_variants])
            
            # Paraphrased questions
            paraphrased_variants = [
                question.replace('what is', 'can you explain'),
                question.replace('what is', 'what does'),
                question.replace('?', ' mean?')
            ]
            adversarial_tests['paraphrased'].extend(paraphrased_variants[:num_variants])
            
            # Unanswerable questions
            unanswerable_variants = [
                f"What will be the future price of {question.lower().replace('what is', '').replace('?', '')}?",
                f"What is my personal opinion on {question.lower().replace('what is', '').replace('?', '')}?",
                f"What happened to {question.lower().replace('what is', '').replace('?', '')} yesterday?"
            ]
            adversarial_tests['unanswerable'].extend(unanswerable_variants[:num_variants])
        
        return dict(adversarial_tests)
    
    def evaluate_robustness(self, rag_system, adversarial_questions: Dict[str, List[str]]) -> Dict[str, Any]:
        """Evaluate system robustness against adversarial questions"""
        results = {}
        
        for category, questions in adversarial_questions.items():
            category_results = []
            
            for question in questions:
                try:
                    # Mock evaluation - in real implementation, use actual RAG system
                    start_time = time.time()
                    
                    # Simulate response (replace with actual RAG call)
                    response_time = np.random.uniform(0.5, 2.0)
                    confidence = np.random.uniform(0.3, 0.9)
                    has_answer = np.random.choice([True, False], p=[0.7, 0.3])
                    
                    category_results.append({
                        'question': question,
                        'response_time': response_time,
                        'confidence': confidence,
                        'has_answer': has_answer,
                        'category': category
                    })
                    
                except Exception as e:
                    category_results.append({
                        'question': question,
                        'error': str(e),
                        'category': category
                    })
            
            results[category] = category_results
        
        return results


class AblationStudy:
    """Performs ablation studies on retrieval methods"""
    
    def __init__(self):
        self.methods = {
            'dense_only': 'Dense retrieval (semantic similarity) only',
            'sparse_only': 'Sparse retrieval (BM25) only',
            'hybrid': 'Hybrid fusion of dense and sparse',
            'hybrid_weighted': 'Weighted hybrid with different alpha values'
        }
    
    def run_ablation_study(self, questions: List[str], top_k_values: List[int] = [5, 10, 20],
                          rrf_k_values: List[int] = [20, 60, 100]) -> pd.DataFrame:
        """Run comprehensive ablation study"""
        results = []
        
        for question in questions[:20]:  # Limit for demo
            for method in self.methods.keys():
                for top_k in top_k_values:
                    if method in ['hybrid', 'hybrid_weighted']:
                        for rrf_k in rrf_k_values:
                            # Simulate retrieval performance
                            mrr = self._simulate_performance(method, top_k, rrf_k)
                            precision = mrr * np.random.uniform(0.8, 1.2)
                            recall = mrr * np.random.uniform(0.7, 1.1)
                            
                            results.append({
                                'question': question,
                                'method': method,
                                'top_k': top_k,
                                'rrf_k': rrf_k if method.startswith('hybrid') else None,
                                'mrr': mrr,
                                'precision': min(1.0, precision),
                                'recall': min(1.0, recall),
                                'f1': 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
                            })
                    else:
                        # For non-hybrid methods
                        mrr = self._simulate_performance(method, top_k)
                        precision = mrr * np.random.uniform(0.8, 1.2)
                        recall = mrr * np.random.uniform(0.7, 1.1)
                        
                        results.append({
                            'question': question,
                            'method': method,
                            'top_k': top_k,
                            'rrf_k': None,
                            'mrr': mrr,
                            'precision': min(1.0, precision),
                            'recall': min(1.0, recall),
                            'f1': 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0
                        })
        
        return pd.DataFrame(results)
    
    def _simulate_performance(self, method: str, top_k: int, rrf_k: int = None) -> float:
        """Simulate performance metrics based on method and parameters"""
        base_scores = {
            'dense_only': 0.65,
            'sparse_only': 0.58,
            'hybrid': 0.78,
            'hybrid_weighted': 0.82
        }
        
        base_score = base_scores.get(method, 0.6)
        
        # Adjust based on top_k
        top_k_factor = min(1.0, 0.7 + (top_k / 50))
        
        # Adjust based on rrf_k for hybrid methods
        rrf_factor = 1.0
        if rrf_k and method.startswith('hybrid'):
            rrf_factor = 0.9 + (60 - abs(60 - rrf_k)) / 200
        
        # Add some noise
        noise = np.random.uniform(0.95, 1.05)
        
        return min(1.0, base_score * top_k_factor * rrf_factor * noise)


class ConfidenceCalibrator:
    """Estimates answer confidence and calibration"""
    
    def __init__(self):
        if TRANSFORMERS_AVAILABLE:
            try:
                self.confidence_model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
            except:
                self.confidence_model = None
        else:
            self.confidence_model = None
    
    def estimate_confidence(self, question: str, answer: str, retrieved_docs: List[str]) -> Dict[str, float]:
        """Estimate confidence based on multiple factors"""
        
        # Factor 1: Answer length (longer might indicate more confidence)
        length_confidence = min(1.0, len(answer.split()) / 50)
        
        # Factor 2: Keyword overlap with question  
        question_words = set(question.lower().split())
        answer_words = set(answer.lower().split())
        overlap = len(question_words.intersection(answer_words))
        overlap_confidence = min(1.0, overlap / max(1, len(question_words)))
        
        # Factor 3: Source document similarity (if available)
        source_confidence = 0.7  # Default
        if self.confidence_model and retrieved_docs:
            try:
                question_embedding = self.confidence_model.encode([question])
                doc_embeddings = self.confidence_model.encode(retrieved_docs[:3])
                similarities = cosine_similarity(question_embedding, doc_embeddings)[0]
                source_confidence = max(similarities) if len(similarities) > 0 else 0.7
            except:
                pass
        
        # Factor 4: Answer specificity (fewer hedging words = higher confidence)
        hedge_words = {'maybe', 'perhaps', 'might', 'could', 'possibly', 'probably'}
        answer_lower = answer.lower()
        hedge_count = sum(1 for word in hedge_words if word in answer_lower)
        specificity_confidence = max(0.3, 1.0 - (hedge_count * 0.1))
        
        # Combine factors
        overall_confidence = (
            length_confidence * 0.2 +
            overlap_confidence * 0.3 +
            source_confidence * 0.3 +
            specificity_confidence * 0.2
        )
        
        return {
            'overall': overall_confidence,
            'length': length_confidence,
            'overlap': overlap_confidence,
            'source_similarity': source_confidence,
            'specificity': specificity_confidence
        }
    
    @staticmethod
    def calculate_calibration(predictions: List[float], correctness: List[bool]) -> Tuple[np.ndarray, np.ndarray]:
        """Calculate calibration curve"""
        if not SKLEARN_AVAILABLE:
            return np.array([]), np.array([])
        
        try:
            prob_true, prob_pred = calibration_curve(correctness, predictions, n_bins=5)
            return prob_true, prob_pred
        except Exception:
            return np.array([]), np.array([])


class NovelMetrics:
    """Custom metrics for RAG evaluation"""
    
    def __init__(self):
        if TRANSFORMERS_AVAILABLE:
            try:
                self.embedding_model = SentenceTransformer('sentence-transformers/all-MiniLM-L6-v2')
            except:
                self.embedding_model = None
        else:
            self.embedding_model = None
    
    def entity_coverage(self, questions: List[str], answers: List[str]) -> Dict[str, float]:
        """Calculate entity coverage in answers"""
        # Simple entity extraction (in practice, use NER)
        import re
        
        total_entities = set()
        covered_entities = set()
        
        for question, answer in zip(questions, answers):
            # Extract potential entities (capitalize words)
            question_entities = set(re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', question))
            answer_entities = set(re.findall(r'\b[A-Z][a-z]+(?:\s+[A-Z][a-z]+)*\b', answer))
            
            total_entities.update(question_entities)
            covered_entities.update(question_entities.intersection(answer_entities))
        
        coverage_rate = len(covered_entities) / len(total_entities) if total_entities else 0
        
        return {
            'entity_coverage_rate': coverage_rate,
            'total_entities': len(total_entities),
            'covered_entities': len(covered_entities)
        }
    
    def answer_diversity(self, answers: List[str]) -> Dict[str, float]:
        """Calculate diversity of generated answers"""
        if not answers:
            return {'diversity_score': 0.0}
        
        # Calculate lexical diversity
        all_words = []
        unique_words = set()
        
        for answer in answers:
            words = answer.lower().split()
            all_words.extend(words)
            unique_words.update(words)
        
        lexical_diversity = len(unique_words) / len(all_words) if all_words else 0
        
        # Calculate semantic diversity (if embeddings available)
        semantic_diversity = 0.5  # Default
        if self.embedding_model and len(answers) > 1:
            try:
                embeddings = self.embedding_model.encode(answers)
                similarities = cosine_similarity(embeddings)
                # Average pairwise similarity (lower = more diverse)
                avg_similarity = np.mean(similarities[np.triu_indices(len(similarities), k=1)])
                semantic_diversity = 1 - avg_similarity
            except:
                pass
        
        return {
            'diversity_score': (lexical_diversity + semantic_diversity) / 2,
            'lexical_diversity': lexical_diversity,
            'semantic_diversity': semantic_diversity
        }
    
    def hallucination_rate(self, answers: List[str], source_docs: List[List[str]]) -> Dict[str, float]:
        """Estimate hallucination rate based on source overlap"""
        hallucination_scores = []
        
        for answer, docs in zip(answers, source_docs):
            if not docs:
                hallucination_scores.append(1.0)  # High hallucination if no sources
                continue
            
            answer_words = set(answer.lower().split())
            source_words = set()
            for doc in docs:
                source_words.update(doc.lower().split())
            
            # Calculate overlap
            overlap = len(answer_words.intersection(source_words))
            overlap_rate = overlap / len(answer_words) if answer_words else 0
            
            # Hallucination is inverse of overlap
            hallucination_score = 1 - overlap_rate
            hallucination_scores.append(hallucination_score)
        
        return {
            'hallucination_rate': np.mean(hallucination_scores),
            'per_answer_scores': hallucination_scores
        }


class LLMAsJudge:
    """Use LLM to evaluate factual accuracy, completeness, relevance, and coherence"""
    
    def __init__(self):
        # In practice, this would use an actual LLM API
        self.evaluation_criteria = {
            'factual_accuracy': 'Is the answer factually correct?',
            'completeness': 'Does the answer fully address the question?',
            'relevance': 'Is the answer relevant to the question?',
            'coherence': 'Is the answer well-structured and coherent?'
        }
    
    def evaluate_response(self, question: str, answer: str, source_docs: List[str]) -> Dict[str, Any]:
        """Evaluate response using LLM as judge"""
        
        # Simulate LLM evaluation (replace with actual LLM API call)
        evaluation = {}
        
        for criterion, description in self.evaluation_criteria.items():
            # Simulate scoring based on simple heuristics
            if criterion == 'factual_accuracy':
                # Higher score for longer answers with more source overlap
                source_text = ' '.join(source_docs[:3]) if source_docs else ''
                overlap = self._calculate_overlap(answer, source_text)
                score = min(1.0, overlap + np.random.uniform(0, 0.3))
                
            elif criterion == 'completeness':
                # Score based on answer length relative to question complexity
                question_complexity = len(question.split())
                answer_length = len(answer.split())
                score = min(1.0, answer_length / max(question_complexity * 2, 10))
                
            elif criterion == 'relevance':
                # Score based on keyword overlap
                score = self._calculate_overlap(question, answer)
                
            else:  # coherence
                # Simple coherence heuristic
                sentences = answer.split('.')
                avg_sentence_length = np.mean([len(s.split()) for s in sentences if s.strip()])
                score = min(1.0, max(0.3, 1 - abs(avg_sentence_length - 15) / 20))
            
            # Add some noise
            score = max(0, min(1, score + np.random.uniform(-0.1, 0.1)))
            
            evaluation[criterion] = {
                'score': score,
                'explanation': f"Simulated evaluation for {criterion}",
                'max_score': 1.0
            }
        
        # Overall score
        overall_score = np.mean([eval_data['score'] for eval_data in evaluation.values()])
        evaluation['overall'] = {
            'score': overall_score,
            'explanation': "Weighted average of all criteria"
        }
        
        return evaluation
    
    def _calculate_overlap(self, text1: str, text2: str) -> float:
        """Calculate word overlap between two texts"""
        words1 = set(text1.lower().split())
        words2 = set(text2.lower().split())
        
        if not words1:
            return 0.0
        
        intersection = words1.intersection(words2)
        return len(intersection) / len(words1)


class ErrorAnalyzer:
    """Categorize and analyze failure modes"""
    
    def __init__(self):
        self.failure_categories = {
            'retrieval_failure': 'Relevant documents not retrieved',
            'generation_failure': 'Poor answer generation despite good retrieval',
            'context_failure': 'Context not properly utilized',
            'knowledge_gap': 'Required information not in corpus',
            'query_ambiguity': 'Question too ambiguous to answer properly'
        }
    
    def analyze_failures(self, results: List[Dict]) -> Dict[str, Any]:
        """Analyze and categorize failures"""
        
        failure_analysis = {
            'total_failures': 0,
            'failure_breakdown': defaultdict(int),
            'failure_examples': defaultdict(list),
            'patterns': []
        }
        
        for result in results:
            # Simulate failure classification
            if result.get('score', 1.0) < 0.5:  # Consider as failure
                failure_analysis['total_failures'] += 1
                
                # Classify failure type (simplified heuristic)
                question = result.get('question', '')
                answer = result.get('answer', '')
                
                if len(answer) < 10:
                    category = 'generation_failure'
                elif '?' in question and 'not' in question.lower():
                    category = 'query_ambiguity'
                elif len(question.split()) > 20:
                    category = 'context_failure'
                else:
                    category = 'retrieval_failure'
                
                failure_analysis['failure_breakdown'][category] += 1
                
                if len(failure_analysis['failure_examples'][category]) < 3:
                    failure_analysis['failure_examples'][category].append({
                        'question': question,
                        'answer': answer,
                        'score': result.get('score', 0)
                    })
        
        # Identify patterns
        total_questions = len(results)
        failure_rate = failure_analysis['total_failures'] / total_questions if total_questions > 0 else 0
        
        if failure_rate > 0.3:
            failure_analysis['patterns'].append("High overall failure rate detected")
        
        return dict(failure_analysis)


class AdvancedEvaluationSuite:
    """Main class that orchestrates all evaluation components"""
    
    def __init__(self):
        self.adversarial_tester = AdversarialTester()
        self.ablation_study = AblationStudy()
        self.confidence_calibrator = ConfidenceCalibrator()
        self.novel_metrics = NovelMetrics()
        self.llm_judge = LLMAsJudge()
        self.error_analyzer = ErrorAnalyzer()
    
    def run_comprehensive_evaluation(self, 
                                   questions: List[str], 
                                   rag_system=None,
                                   num_samples: int = 50) -> Dict[str, Any]:
        """Run complete evaluation suite"""
        
        st.info("🧪 Running comprehensive evaluation suite...")
        
        # Step 1: Adversarial Testing
        st.write("### 1️⃣ Adversarial Testing")
        with st.spinner("Generating adversarial questions..."):
            adversarial_questions = self.adversarial_tester.generate_adversarial_questions(questions[:10])
            adversarial_results = self.adversarial_tester.evaluate_robustness(rag_system, adversarial_questions)
        
        # Step 2: Ablation Studies
        st.write("### 2️⃣ Ablation Studies")
        with st.spinner("Running ablation studies..."):
            ablation_df = self.ablation_study.run_ablation_study(questions[:20])
        
        # Step 3: Generate mock results for other evaluations
        st.write("### 3️⃣ Generating Evaluation Results")
        with st.spinner("Processing evaluations..."):
            evaluation_results = []
            for i, question in enumerate(questions[:num_samples]):
                # Mock results - replace with actual RAG evaluation
                answer = f"This is a generated answer for: {question}"
                retrieved_docs = [f"Document {j} content for {question}" for j in range(3)]
                
                # Get confidence estimates
                confidence = self.confidence_calibrator.estimate_confidence(question, answer, retrieved_docs)
                
                # Get LLM judge evaluation
                llm_eval = self.llm_judge.evaluate_response(question, answer, retrieved_docs)
                
                evaluation_results.append({
                    'question': question,
                    'answer': answer,
                    'retrieved_docs': retrieved_docs,
                    'confidence': confidence,
                    'llm_evaluation': llm_eval,
                    'score': llm_eval['overall']['score']
                })
        
        # Step 4: Calculate novel metrics
        st.write("### 4️⃣ Novel Metrics")
        with st.spinner("Calculating novel metrics..."):
            answers = [r['answer'] for r in evaluation_results]
            source_docs = [r['retrieved_docs'] for r in evaluation_results]
            
            entity_metrics = self.novel_metrics.entity_coverage(questions[:num_samples], answers)
            diversity_metrics = self.novel_metrics.answer_diversity(answers)
            hallucination_metrics = self.novel_metrics.hallucination_rate(answers, source_docs)
        
        # Step 5: Error Analysis
        st.write("### 5️⃣ Error Analysis")
        with st.spinner("Analyzing errors..."):
            error_analysis = self.error_analyzer.analyze_failures(evaluation_results)
        
        # Compile comprehensive results
        comprehensive_results = {
            'adversarial_testing': adversarial_results,
            'ablation_studies': ablation_df,
            'evaluation_results': evaluation_results,
            'novel_metrics': {
                'entity_coverage': entity_metrics,
                'answer_diversity': diversity_metrics,
                'hallucination_rate': hallucination_metrics
            },
            'error_analysis': error_analysis,
            'summary_stats': {
                'total_questions': len(evaluation_results),
                'average_score': np.mean([r['score'] for r in evaluation_results]),
                'average_confidence': np.mean([r['confidence']['overall'] for r in evaluation_results])
            }
        }
        
        return comprehensive_results