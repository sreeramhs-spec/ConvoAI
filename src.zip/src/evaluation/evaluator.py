"""
Comprehensive evaluation framework for the Hybrid RAG system.

This module orchestrates the complete evaluation pipeline including:
- Question generation from the corpus
- System evaluation with generated questions
- Comprehensive metrics calculation
- Ablation studies
- Error analysis and failure categorization
- Report generation
"""

import json
import os
import time
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

from .question_generator import QuestionGenerator
from .metrics import MetricsCalculator
from ..main import HybridRAGSystem


class RAGEvaluator:
    """Comprehensive evaluation framework for RAG systems."""
    
    def __init__(self,
                 rag_system: HybridRAGSystem,
                 question_generator: Optional[QuestionGenerator] = None,
                 metrics_calculator: Optional[MetricsCalculator] = None,
                 output_dir: str = "outputs/evaluation"):
        """
        Initialize the RAG evaluator.
        
        Args:
            rag_system: The RAG system to evaluate
            question_generator: Question generator instance
            metrics_calculator: Metrics calculator instance
            output_dir: Directory to save evaluation results
        """
        self.rag_system = rag_system
        self.question_generator = question_generator or QuestionGenerator()
        self.metrics_calculator = metrics_calculator or MetricsCalculator()
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # Evaluation state
        self.evaluation_results = {}
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        print(f"RAG Evaluator initialized. Results will be saved to: {self.output_dir}")
    
    def run_full_evaluation(self,
                           num_questions: int = 100,
                           save_results: bool = True,
                           run_ablation: bool = True,
                           generate_report: bool = True) -> Dict:
        """
        Run the complete evaluation pipeline.
        
        Args:
            num_questions: Number of questions to generate and evaluate
            save_results: Whether to save detailed results
            run_ablation: Whether to run ablation studies
            generate_report: Whether to generate evaluation report
            
        Returns:
            Complete evaluation results
        """
        print(f"\n{'='*60}")
        print(f"STARTING COMPREHENSIVE RAG EVALUATION")
        print(f"{'='*60}")
        print(f"Target questions: {num_questions}")
        print(f"Timestamp: {self.timestamp}")
        print(f"Output directory: {self.output_dir}")
        
        # Step 1: Generate evaluation questions
        print(f"\n{'-'*40}")
        print("STEP 1: GENERATING EVALUATION QUESTIONS")
        print(f"{'-'*40}")
        
        questions = self._generate_evaluation_questions(num_questions)
        print(f"Generated {len(questions)} evaluation questions")
        
        if save_results:
            self._save_questions(questions)
        
        # Step 2: Run main evaluation
        print(f"\n{'-'*40}")
        print("STEP 2: RUNNING MAIN EVALUATION")
        print(f"{'-'*40}")
        
        main_results = self._evaluate_system(questions, system_config="hybrid")
        
        # Step 3: Run ablation studies
        if run_ablation:
            print(f"\n{'-'*40}")
            print("STEP 3: RUNNING ABLATION STUDIES")
            print(f"{'-'*40}")
            
            ablation_results = self._run_ablation_studies(questions)
            main_results['ablation_studies'] = ablation_results
        
        # Step 4: Error analysis
        print(f"\n{'-'*40}")
        print("STEP 4: PERFORMING ERROR ANALYSIS")
        print(f"{'-'*40}")
        
        error_analysis = self._perform_error_analysis(questions, main_results)
        main_results['error_analysis'] = error_analysis
        
        # Step 5: Generate comprehensive report
        if generate_report:
            print(f"\n{'-'*40}")
            print("STEP 5: GENERATING EVALUATION REPORT")
            print(f"{'-'*40}")
            
            report_path = self._generate_comprehensive_report(main_results)
            main_results['report_path'] = str(report_path)
        
        # Save final results
        if save_results:
            results_path = self.output_dir / f"evaluation_results_{self.timestamp}.json"
            with open(results_path, 'w') as f:
                json.dump(main_results, f, indent=2, default=str)
            print(f"Complete results saved to: {results_path}")
        
        self.evaluation_results = main_results
        
        print(f"\n{'='*60}")
        print(f"EVALUATION COMPLETED SUCCESSFULLY")
        print(f"{'='*60}")
        
        return main_results
    
    def _generate_evaluation_questions(self, num_questions: int) -> List[Dict]:
        """Generate evaluation questions from the corpus."""
        # Load processed documents for question generation
        processed_data_dir = Path("data/processed")
        if not processed_data_dir.exists():
            raise FileNotFoundError(f"Processed data directory not found: {processed_data_dir}")
        
        # Find the most recent processed articles file
        article_files = list(processed_data_dir.glob("processed_articles_*.json"))
        if not article_files:
            raise FileNotFoundError("No processed articles found. Run data collection first.")
        
        latest_file = max(article_files, key=lambda x: x.stat().st_mtime)
        print(f"Using processed articles from: {latest_file}")
        
        with open(latest_file, 'r') as f:
            articles = json.load(f)
        
        # Generate questions
        questions = self.question_generator.generate_questions_from_corpus(
            articles, num_questions=num_questions
        )
        
        return questions
    
    def _evaluate_system(self,
                        questions: List[Dict],
                        system_config: str = "hybrid") -> Dict:
        """Evaluate the RAG system with given questions."""
        print(f"Evaluating system with {len(questions)} questions...")
        
        # Storage for results
        retrieval_results = []
        generated_answers = []
        response_times = []
        confidence_scores = []
        
        # Process each question
        for i, question in enumerate(questions):
            if i % 10 == 0:
                print(f"Processing question {i+1}/{len(questions)}")
            
            try:
                start_time = time.time()
                
                # Query the RAG system
                query_text = question['question']
                response = self.rag_system.query(
                    query_text,
                    fusion_method='rrf',  # Use RRF fusion
                    top_k=10,
                    fusion_params={'k': 60}
                )
                
                end_time = time.time()
                response_time = end_time - start_time
                
                # Extract results
                retrieval_results.append(response.get('retrieved_chunks', []))
                generated_answers.append(response.get('generated_answer', ''))
                response_times.append(response_time)
                
                # Estimate confidence (system doesn't provide this directly)
                confidence = self._estimate_confidence_from_response(response)
                confidence_scores.append(confidence)
                
            except Exception as e:
                print(f"Error processing question {i}: {e}")
                # Add empty/default results for failed questions
                retrieval_results.append([])
                generated_answers.append("")
                response_times.append(0.0)
                confidence_scores.append(0.0)
        
        # Calculate comprehensive metrics
        print("Calculating evaluation metrics...")
        metrics_results = self.metrics_calculator.calculate_all_metrics(
            questions, retrieval_results, generated_answers, confidence_scores
        )
        
        # Add performance metrics
        metrics_results['performance'] = {
            'average_response_time': np.mean(response_times),
            'median_response_time': np.median(response_times),
            'total_evaluation_time': sum(response_times),
            'questions_per_minute': len(questions) / (sum(response_times) / 60) if sum(response_times) > 0 else 0
        }
        
        # Add system configuration
        metrics_results['system_config'] = {
            'config_name': system_config,
            'dense_model': self.rag_system.dense_retriever.model_name if hasattr(self.rag_system, 'dense_retriever') else 'unknown',
            'sparse_method': 'BM25',
            'fusion_method': 'RRF (Reciprocal Rank Fusion)',
            'generation_model': self.rag_system.response_generator.model_name if hasattr(self.rag_system.response_generator, 'model_name') else 'unknown'
        }
        
        return metrics_results
    
    def _run_ablation_studies(self, questions: List[Dict]) -> Dict:
        """Run ablation studies comparing different configurations."""
        print("Running ablation studies...")
        
        ablation_results = {}
        
        # Test configurations
        configs = {
            'dense_only': 'Dense retrieval only (no sparse)',
            'sparse_only': 'Sparse retrieval only (no dense)', 
            'no_fusion': 'Simple concatenation instead of RRF',
            'hybrid_rrf': 'Full hybrid with RRF (baseline)'
        }
        
        for config_name, config_description in configs.items():
            print(f"Evaluating configuration: {config_name}")
            
            try:
                # Modify system configuration for ablation
                config_results = self._evaluate_ablation_config(questions, config_name)
                ablation_results[config_name] = {
                    'description': config_description,
                    'results': config_results
                }
            except Exception as e:
                print(f"Error in ablation study {config_name}: {e}")
                ablation_results[config_name] = {
                    'description': config_description,
                    'error': str(e)
                }
        
        # Comparative analysis
        ablation_results['comparative_analysis'] = self._analyze_ablation_results(ablation_results)
        
        return ablation_results
    
    def _evaluate_ablation_config(self, questions: List[Dict], config: str) -> Dict:
        """Evaluate a specific ablation configuration."""
        # Sample subset for faster ablation (use first 20 questions)
        sample_questions = questions[:20]
        
        retrieval_results = []
        generated_answers = []
        
        for question in sample_questions:
            query_text = question['question']
            
            if config == 'dense_only':
                # Use only dense retrieval
                dense_results = self.rag_system.dense_retriever.search(query_text, top_k=10)
                retrieval_results.append(dense_results)
                
            elif config == 'sparse_only':
                # Use only sparse retrieval
                sparse_results = self.rag_system.sparse_retriever.search(query_text, top_k=10)
                retrieval_results.append(sparse_results)
                
            elif config == 'no_fusion':
                # Simple concatenation without RRF
                dense_results = self.rag_system.dense_retriever.search(query_text, top_k=5)
                sparse_results = self.rag_system.sparse_retriever.search(query_text, top_k=5)
                combined_results = dense_results + sparse_results
                retrieval_results.append(combined_results)
                
            else:  # hybrid_rrf (baseline)
                response = self.rag_system.query(query_text, top_k=10)
                retrieval_results.append(response.get('retrieved_chunks', []))
            
            # Generate answer using retrieved context
            context_text = ' '.join([chunk.get('text', '') for chunk in retrieval_results[-1][:5]])
            generated_answer = self.rag_system.response_generator.generate_response(query_text, context_text)
            generated_answers.append(generated_answer)
        
        # Calculate metrics for this configuration
        config_metrics = self.metrics_calculator.calculate_all_metrics(
            sample_questions, retrieval_results, generated_answers
        )
        
        return config_metrics
    
    def _analyze_ablation_results(self, ablation_results: Dict) -> Dict:
        """Analyze ablation study results comparatively."""
        analysis = {}
        
        # Extract key metrics for comparison
        metric_names = ['mrr', 'rouge_l_f1', 'precision@10', 'semantic_similarity']
        
        comparison_data = {}
        for config_name, config_data in ablation_results.items():
            if config_name == 'comparative_analysis':
                continue
            
            if 'error' in config_data:
                continue
            
            results = config_data.get('results', {})
            comparison_data[config_name] = {}
            
            # Extract metrics
            comparison_data[config_name]['mrr'] = results.get('mrr_url_level', {}).get('mrr', 0)
            comparison_data[config_name]['rouge_l_f1'] = results.get('rouge_l', {}).get('rouge_l_f1', 0)
            comparison_data[config_name]['precision@10'] = results.get('retrieval_precision_at_k', {}).get('precision@10', 0)
            comparison_data[config_name]['semantic_similarity'] = results.get('semantic_similarity', {}).get('semantic_similarity', 0)
        
        # Find best performing configuration for each metric
        analysis['best_configs'] = {}
        for metric in metric_names:
            best_config = max(comparison_data.keys(), 
                            key=lambda x: comparison_data[x].get(metric, 0))
            best_score = comparison_data[best_config].get(metric, 0)
            analysis['best_configs'][metric] = {
                'config': best_config,
                'score': best_score
            }
        
        # Overall ranking
        config_scores = {}
        for config in comparison_data:
            # Average normalized scores
            scores = [comparison_data[config].get(metric, 0) for metric in metric_names]
            config_scores[config] = np.mean(scores)
        
        ranked_configs = sorted(config_scores.items(), key=lambda x: x[1], reverse=True)
        analysis['overall_ranking'] = ranked_configs
        
        # Key insights
        analysis['insights'] = []
        
        if 'hybrid_rrf' in config_scores and len(config_scores) > 1:
            hybrid_score = config_scores['hybrid_rrf']
            other_scores = [score for config, score in config_scores.items() if config != 'hybrid_rrf']
            
            if hybrid_score == max(config_scores.values()):
                analysis['insights'].append("Hybrid RRF achieves the best overall performance")
            
            improvement = hybrid_score - max(other_scores) if other_scores else 0
            if improvement > 0.1:
                analysis['insights'].append(f"Hybrid approach shows significant improvement ({improvement:.2f}) over individual methods")
        
        return analysis
    
    def _perform_error_analysis(self, questions: List[Dict], main_results: Dict) -> Dict:
        """Perform detailed error analysis on evaluation results."""
        print("Performing error analysis...")
        
        error_analysis = {
            'timestamp': datetime.now().isoformat(),
            'failure_categories': defaultdict(int),
            'error_patterns': [],
            'low_performing_questions': [],
            'recommendations': []
        }
        
        # Analyze MRR results for failures
        mrr_details = main_results.get('mrr_url_level', {}).get('detailed_results', [])
        
        for result in mrr_details:
            if result['reciprocal_rank'] == 0:
                # URL not found - categorize the failure
                question_text = result.get('question', '').lower()
                
                # Categorize by question type
                if any(word in question_text for word in ['what', 'who', 'where', 'when']):
                    if 'what' in question_text:
                        error_analysis['failure_categories']['factual_what_questions'] += 1
                    elif 'who' in question_text:
                        error_analysis['failure_categories']['person_identification'] += 1
                    elif 'where' in question_text:
                        error_analysis['failure_categories']['location_questions'] += 1
                    elif 'when' in question_text:
                        error_analysis['failure_categories']['temporal_questions'] += 1
                else:
                    error_analysis['failure_categories']['other_question_types'] += 1
                
                # Add to low performing questions
                error_analysis['low_performing_questions'].append({
                    'question_id': result.get('question_id'),
                    'question': result.get('question'),
                    'ground_truth_url': result.get('ground_truth_url'),
                    'failure_type': 'url_not_found'
                })
        
        # Analyze ROUGE-L results for answer quality issues
        rouge_details = main_results.get('rouge_l', {}).get('detailed_results', [])
        
        low_rouge_threshold = 0.2
        for result in rouge_details:
            if result.get('rouge_l_f1', 0) < low_rouge_threshold:
                error_analysis['failure_categories']['low_answer_quality'] += 1
                error_analysis['low_performing_questions'].append({
                    'question_id': result.get('question_id'),
                    'question': result.get('question'),
                    'rouge_l_f1': result.get('rouge_l_f1'),
                    'failure_type': 'poor_answer_quality'
                })
        
        # Identify error patterns
        if error_analysis['failure_categories']['factual_what_questions'] > 5:
            error_analysis['error_patterns'].append({
                'pattern': 'High failure rate on factual "what" questions',
                'frequency': error_analysis['failure_categories']['factual_what_questions'],
                'likely_cause': 'Dense retrieval may struggle with factual information extraction'
            })
        
        if error_analysis['failure_categories']['low_answer_quality'] > 10:
            error_analysis['error_patterns'].append({
                'pattern': 'Frequent low-quality answer generation',
                'frequency': error_analysis['failure_categories']['low_answer_quality'],
                'likely_cause': 'Generation model may need better prompting or fine-tuning'
            })
        
        # Generate recommendations
        total_failures = sum(error_analysis['failure_categories'].values())
        total_questions = len(questions)
        failure_rate = total_failures / total_questions if total_questions > 0 else 0
        
        if failure_rate > 0.3:
            error_analysis['recommendations'].append("High failure rate detected. Consider improving retrieval coverage or question generation diversity")
        
        if error_analysis['failure_categories']['person_identification'] > 3:
            error_analysis['recommendations'].append("Consider adding named entity recognition to improve person-related question handling")
        
        if error_analysis['failure_categories']['temporal_questions'] > 3:
            error_analysis['recommendations'].append("Temporal reasoning appears weak. Consider incorporating time-aware retrieval methods")
        
        # Convert defaultdict to regular dict for JSON serialization
        error_analysis['failure_categories'] = dict(error_analysis['failure_categories'])
        
        return error_analysis
    
    def _estimate_confidence_from_response(self, response: Dict) -> float:
        """Estimate confidence from system response characteristics."""
        confidence = 0.5  # Base confidence
        
        # Check retrieval scores
        retrieved_chunks = response.get('retrieved_chunks', [])
        if retrieved_chunks:
            scores = [chunk.get('score', 0) for chunk in retrieved_chunks[:3]]
            if scores:
                avg_score = np.mean(scores)
                confidence += min(avg_score * 0.3, 0.3)  # Max boost of 0.3
        
        # Check answer length and characteristics
        answer = response.get('generated_answer', '')
        if len(answer.split()) > 10:
            confidence += 0.1
        
        # Uncertainty indicators reduce confidence
        if any(phrase in answer.lower() for phrase in ['unsure', 'unclear', 'unknown', 'might be']):
            confidence -= 0.2
        
        return max(0.0, min(1.0, confidence))
    
    def _generate_comprehensive_report(self, results: Dict) -> Path:
        """Generate a comprehensive evaluation report."""
        report_path = self.output_dir / f"evaluation_report_{self.timestamp}.md"
        
        with open(report_path, 'w') as f:
            f.write(f"# Hybrid RAG System - Comprehensive Evaluation Report\n\n")
            f.write(f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            # Executive Summary
            f.write("## Executive Summary\n\n")
            
            summary = results.get('summary', {})
            primary_metrics = summary.get('primary_metrics', {})
            
            f.write(f"- **Total Questions Evaluated:** {summary.get('total_questions_evaluated', 'N/A')}\n")
            f.write(f"- **Mean Reciprocal Rank (MRR):** {primary_metrics.get('mrr', 0):.3f}\n")
            f.write(f"- **ROUGE-L F1:** {primary_metrics.get('rouge_l_f1', 0):.3f}\n")
            f.write(f"- **Retrieval Precision@10:** {primary_metrics.get('precision_at_10', 0):.3f}\n\n")
            
            # System Configuration
            f.write("## System Configuration\n\n")
            config = results.get('system_config', {})
            f.write(f"- **Dense Model:** {config.get('dense_model', 'Unknown')}\n")
            f.write(f"- **Sparse Method:** {config.get('sparse_method', 'Unknown')}\n")
            f.write(f"- **Fusion Method:** {config.get('fusion_method', 'Unknown')}\n")
            f.write(f"- **Generation Model:** {config.get('generation_model', 'Unknown')}\n\n")
            
            # Detailed Metrics
            f.write("## Detailed Metrics\n\n")
            
            # MRR Results
            mrr_results = results.get('mrr_url_level', {})
            f.write("### Mean Reciprocal Rank (URL Level)\n\n")
            f.write(f"- **MRR Score:** {mrr_results.get('mrr', 0):.3f}\n")
            f.write(f"- **Hit Rate:** {mrr_results.get('hit_rate', 0):.3f}\n")
            f.write(f"- **Questions Found:** {mrr_results.get('questions_found', 0)}/{mrr_results.get('total_questions', 0)}\n")
            
            precision_at_k = mrr_results.get('precision_at_k', {})
            f.write("- **Precision@K:**\n")
            for k, precision in precision_at_k.items():
                f.write(f"  - {k}: {precision:.3f}\n")
            f.write("\n")
            
            # ROUGE Results
            rouge_results = results.get('rouge_l', {})
            f.write("### ROUGE-L (Answer Quality)\n\n")
            f.write(f"- **ROUGE-L F1:** {rouge_results.get('rouge_l_f1', 0):.3f}\n")
            f.write(f"- **ROUGE-L Precision:** {rouge_results.get('rouge_l_precision', 0):.3f}\n")
            f.write(f"- **ROUGE-L Recall:** {rouge_results.get('rouge_l_recall', 0):.3f}\n\n")
            
            # Performance Metrics
            performance = results.get('performance', {})
            f.write("### Performance Metrics\n\n")
            f.write(f"- **Average Response Time:** {performance.get('average_response_time', 0):.2f} seconds\n")
            f.write(f"- **Median Response Time:** {performance.get('median_response_time', 0):.2f} seconds\n")
            f.write(f"- **Questions per Minute:** {performance.get('questions_per_minute', 0):.1f}\n\n")
            
            # Ablation Studies
            ablation = results.get('ablation_studies', {})
            if ablation:
                f.write("## Ablation Studies\n\n")
                
                comparative_analysis = ablation.get('comparative_analysis', {})
                overall_ranking = comparative_analysis.get('overall_ranking', [])
                
                if overall_ranking:
                    f.write("### Configuration Ranking\n\n")
                    for i, (config, score) in enumerate(overall_ranking, 1):
                        f.write(f"{i}. **{config}:** {score:.3f}\n")
                    f.write("\n")
                
                insights = comparative_analysis.get('insights', [])
                if insights:
                    f.write("### Key Insights\n\n")
                    for insight in insights:
                        f.write(f"- {insight}\n")
                    f.write("\n")
            
            # Error Analysis
            error_analysis = results.get('error_analysis', {})
            if error_analysis:
                f.write("## Error Analysis\n\n")
                
                failure_categories = error_analysis.get('failure_categories', {})
                if failure_categories:
                    f.write("### Failure Categories\n\n")
                    for category, count in failure_categories.items():
                        f.write(f"- **{category.replace('_', ' ').title()}:** {count}\n")
                    f.write("\n")
                
                recommendations = error_analysis.get('recommendations', [])
                if recommendations:
                    f.write("### Recommendations\n\n")
                    for rec in recommendations:
                        f.write(f"- {rec}\n")
                    f.write("\n")
            
            # Technical Details
            f.write("## Technical Details\n\n")
            f.write("### Evaluation Methodology\n\n")
            f.write("1. **Question Generation:** Template-based and model-based question generation from Wikipedia corpus\n")
            f.write("2. **Retrieval Evaluation:** Mean Reciprocal Rank at URL level to measure source document accuracy\n")
            f.write("3. **Answer Quality:** ROUGE-L F1 score comparing generated answers to reference answers\n")
            f.write("4. **Context Relevance:** Precision@K measuring proportion of relevant retrieved chunks\n")
            f.write("5. **Semantic Assessment:** Sentence embedding similarity for semantic alignment\n")
            f.write("6. **Innovation Metrics:** Confidence calibration and expected calibration error\n\n")
            
            f.write("### Custom Metrics Justification\n\n")
            f.write("1. **ROUGE-L:** Selected for its focus on longest common subsequence, which better captures content overlap than n-gram based metrics for factual question answering.\n")
            f.write("2. **Retrieval Precision@K:** Critical for RAG systems as retrieval quality directly impacts generation quality. Measures whether the system retrieves information from correct source documents.\n\n")
            
        print(f"Comprehensive report generated: {report_path}")
        return report_path
    
    def _save_questions(self, questions: List[Dict]):
        """Save generated questions for later analysis."""
        questions_path = self.output_dir / f"evaluation_questions_{self.timestamp}.json"
        with open(questions_path, 'w') as f:
            json.dump(questions, f, indent=2)
        print(f"Questions saved to: {questions_path}")


def main():
    """Run a sample evaluation."""
    from ..main import HybridRAGSystem
    
    # Initialize components
    rag_system = HybridRAGSystem()
    evaluator = RAGEvaluator(rag_system)
    
    # Run small-scale evaluation
    results = evaluator.run_full_evaluation(
        num_questions=20,  # Small test
        save_results=True,
        run_ablation=True,
        generate_report=True
    )
    
    print("Evaluation completed!")
    print(f"Main MRR: {results['mrr_url_level']['mrr']:.3f}")
    print(f"Report saved to: {results.get('report_path', 'N/A')}")


if __name__ == "__main__":
    main()