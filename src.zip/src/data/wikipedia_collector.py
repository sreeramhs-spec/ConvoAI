"""
Wikipedia data collection module.

This module handles the collection of Wikipedia articles, including:
- Loading fixed URLs
- Randomly sampling additional URLs
- Extracting and cleaning article content
- Validating article quality (minimum word count)
"""

import json
import random
import re
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlparse

import requests
import wikipedia
from bs4 import BeautifulSoup
from tqdm import tqdm


class WikipediaCollector:
    """Collects and processes Wikipedia articles."""
    
    def __init__(self, 
                 fixed_urls_path: str = "data/fixed_urls.json",
                 min_words: int = 200,
                 max_retries: int = 3):
        """
        Initialize the Wikipedia collector.
        
        Args:
            fixed_urls_path: Path to fixed URLs JSON file
            min_words: Minimum word count for valid articles
            max_retries: Maximum retry attempts for failed requests
        """
        self.fixed_urls_path = Path(fixed_urls_path)
        self.min_words = min_words
        self.max_retries = max_retries
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': 'HybridRAGSystem/1.0 (Educational Research)'
        })
        
    def load_fixed_urls(self) -> List[str]:
        """Load the fixed set of 200 Wikipedia URLs."""
        try:
            with open(self.fixed_urls_path, 'r') as f:
                urls = json.load(f)
            if len(urls) != 200:
                raise ValueError(f"Expected 200 fixed URLs, got {len(urls)}")
            return urls
        except FileNotFoundError:
            raise FileNotFoundError(f"Fixed URLs file not found: {self.fixed_urls_path}")
    
    def get_random_wikipedia_urls(self, count: int = 300) -> List[str]:
        """
        Generate random Wikipedia URLs by sampling from various categories.
        
        Args:
            count: Number of random URLs to generate
            
        Returns:
            List of Wikipedia URLs
        """
        urls = []
        categories = [
            "Science", "Technology", "History", "Geography", "Literature",
            "Art", "Music", "Sports", "Politics", "Philosophy", "Religion",
            "Economics", "Medicine", "Biology", "Physics", "Chemistry",
            "Mathematics", "Psychology", "Sociology", "Anthropology"
        ]
        
        urls_per_category = count // len(categories)
        remainder = count % len(categories)
        
        for i, category in enumerate(tqdm(categories, desc="Sampling random URLs")):
            category_count = urls_per_category + (1 if i < remainder else 0)
            
            try:
                # Search for pages in this category
                search_results = wikipedia.search(category, results=category_count * 2)
                
                for title in search_results:
                    if len(urls) >= count:
                        break
                        
                    try:
                        # Get the page URL
                        page = wikipedia.page(title)
                        urls.append(page.url)
                        
                        if len(urls) >= count:
                            break
                            
                    except (wikipedia.exceptions.DisambiguationError,
                            wikipedia.exceptions.PageError,
                            wikipedia.exceptions.RedirectError):
                        continue
                    except Exception as e:
                        print(f"Error processing {title}: {e}")
                        continue
                        
            except Exception as e:
                print(f"Error searching category {category}: {e}")
                continue
                
            time.sleep(0.1)  # Rate limiting
        
        # Fill remaining slots with truly random pages
        while len(urls) < count:
            try:
                random_title = wikipedia.random()
                page = wikipedia.page(random_title)
                urls.append(page.url)
            except:
                continue
                
        return urls[:count]
    
    def extract_article_content(self, url: str) -> Optional[Dict[str, str]]:
        """
        Extract content from a Wikipedia URL.
        
        Args:
            url: Wikipedia article URL
            
        Returns:
            Dictionary with title, content, and metadata or None if extraction fails
        """
        for attempt in range(self.max_retries):
            try:
                # Extract title from URL
                title = self._extract_title_from_url(url)
                
                # Try wikipedia library first
                try:
                    page = wikipedia.page(title)
                    content = page.content
                    summary = page.summary
                    
                    # Clean the content
                    content = self._clean_wikipedia_text(content)
                    
                    # Validate content length
                    word_count = len(content.split())
                    if word_count < self.min_words:
                        return None
                    
                    return {
                        'url': url,
                        'title': page.title,
                        'content': content,
                        'summary': summary,
                        'word_count': word_count,
                        'language': 'en'
                    }
                    
                except (wikipedia.exceptions.DisambiguationError,
                        wikipedia.exceptions.PageError,
                        wikipedia.exceptions.RedirectError):
                    # Fallback to direct HTTP request
                    return self._extract_via_http(url)
                    
            except Exception as e:
                if attempt == self.max_retries - 1:
                    print(f"Failed to extract content from {url} after {self.max_retries} attempts: {e}")
                    return None
                time.sleep(1)  # Wait before retry
                
        return None
    
    def _extract_title_from_url(self, url: str) -> str:
        """Extract Wikipedia title from URL."""
        parsed = urlparse(url)
        title = parsed.path.split('/')[-1]
        return title.replace('_', ' ')
    
    def _extract_via_http(self, url: str) -> Optional[Dict[str, str]]:
        """Extract content via direct HTTP request as fallback."""
        try:
            response = self.session.get(url, timeout=10)
            response.raise_for_status()
            
            soup = BeautifulSoup(response.content, 'html.parser')
            
            # Extract title
            title_elem = soup.find('h1', {'class': 'firstHeading'})
            title = title_elem.get_text() if title_elem else "Unknown Title"
            
            # Extract main content
            content_elem = soup.find('div', {'id': 'mw-content-text'})
            if not content_elem:
                return None
            
            # Remove unwanted elements
            for elem in content_elem.find_all(['table', 'div.navbox', 
                                             'div.infobox', 'div.mbox']):
                elem.decompose()
            
            # Extract text
            paragraphs = content_elem.find_all('p')
            content = '\n\n'.join([p.get_text() for p in paragraphs])
            
            # Clean content
            content = self._clean_wikipedia_text(content)
            
            # Validate content length
            word_count = len(content.split())
            if word_count < self.min_words:
                return None
            
            return {
                'url': url,
                'title': title,
                'content': content,
                'summary': content[:500] + "..." if len(content) > 500 else content,
                'word_count': word_count,
                'language': 'en'
            }
            
        except Exception as e:
            print(f"HTTP extraction failed for {url}: {e}")
            return None
    
    def _clean_wikipedia_text(self, text: str) -> str:
        """Clean Wikipedia text content."""
        # Remove citation markers [1], [2], etc.
        text = re.sub(r'\[\d+\]', '', text)
        
        # Remove multiple spaces and newlines
        text = re.sub(r'\s+', ' ', text)
        
        # Remove Wikipedia-specific formatting
        text = re.sub(r'\{\{[^}]+\}\}', '', text)
        
        # Clean up parenthetical references
        text = re.sub(r'\([^)]*\d{4}[^)]*\)', '', text)  # Remove years in parentheses
        
        # Remove leading/trailing whitespace
        text = text.strip()
        
        return text
    
    def collect_all_articles(self, 
                           output_dir: str = "data/raw",
                           force_refresh: bool = False) -> Dict[str, Dict]:
        """
        Collect all articles (200 fixed + 300 random).
        
        Args:
            output_dir: Directory to save raw articles
            force_refresh: Whether to re-download existing articles
            
        Returns:
            Dictionary mapping URLs to article data
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Load existing data if available
        articles_file = output_path / "articles.json"
        if articles_file.exists() and not force_refresh:
            with open(articles_file, 'r') as f:
                existing_articles = json.load(f)
        else:
            existing_articles = {}
        
        # Get all URLs
        print("Loading fixed URLs...")
        fixed_urls = self.load_fixed_urls()
        
        print("Generating random URLs...")
        random_urls = self.get_random_wikipedia_urls(300)
        
        all_urls = fixed_urls + random_urls
        print(f"Total URLs to process: {len(all_urls)}")
        
        # Collect articles
        articles = {}
        failed_urls = []
        
        for url in tqdm(all_urls, desc="Collecting articles"):
            if url in existing_articles and not force_refresh:
                articles[url] = existing_articles[url]
                continue
            
            article_data = self.extract_article_content(url)
            if article_data:
                articles[url] = article_data
            else:
                failed_urls.append(url)
            
            # Save periodically
            if len(articles) % 50 == 0:
                with open(articles_file, 'w') as f:
                    json.dump(articles, f, indent=2)
        
        # Final save
        with open(articles_file, 'w') as f:
            json.dump(articles, f, indent=2)
        
        # Save failed URLs for debugging
        if failed_urls:
            with open(output_path / "failed_urls.json", 'w') as f:
                json.dump(failed_urls, f, indent=2)
        
        print(f"Successfully collected {len(articles)} articles")
        print(f"Failed to collect {len(failed_urls)} articles")
        
        return articles
    
    def get_collection_stats(self, articles: Dict[str, Dict]) -> Dict:
        """Get statistics about the collected articles."""
        if not articles:
            return {}
        
        word_counts = [article['word_count'] for article in articles.values()]
        
        stats = {
            'total_articles': len(articles),
            'total_words': sum(word_counts),
            'avg_words_per_article': sum(word_counts) / len(word_counts),
            'min_words': min(word_counts),
            'max_words': max(word_counts),
            'articles_by_length': {
                'short (200-500 words)': len([w for w in word_counts if 200 <= w < 500]),
                'medium (500-1000 words)': len([w for w in word_counts if 500 <= w < 1000]),
                'long (1000+ words)': len([w for w in word_counts if w >= 1000])
            }
        }
        
        return stats


def main():
    """Main function for testing the collector."""
    collector = WikipediaCollector()
    
    # Test with a small sample
    print("Testing Wikipedia collection...")
    
    # Collect articles
    articles = collector.collect_all_articles(force_refresh=True)
    
    # Print statistics
    stats = collector.get_collection_stats(articles)
    print("\nCollection Statistics:")
    for key, value in stats.items():
        print(f"{key}: {value}")


if __name__ == "__main__":
    main()