"""
Data utilities and helper functions.
"""

import json
import pickle
from pathlib import Path
from typing import Any, Dict, List, Optional, Union

import pandas as pd


class DataUtils:
    """Utility functions for data management."""
    
    @staticmethod
    def save_json(data: Any, filepath: Union[str, Path]) -> None:
        """Save data as JSON file."""
        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'w', encoding='utf-8') as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
    
    @staticmethod
    def load_json(filepath: Union[str, Path]) -> Any:
        """Load data from JSON file."""
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    @staticmethod
    def save_pickle(data: Any, filepath: Union[str, Path]) -> None:
        """Save data as pickle file."""
        filepath = Path(filepath)
        filepath.parent.mkdir(parents=True, exist_ok=True)
        
        with open(filepath, 'wb') as f:
            pickle.dump(data, f)
    
    @staticmethod
    def load_pickle(filepath: Union[str, Path]) -> Any:
        """Load data from pickle file."""
        with open(filepath, 'rb') as f:
            return pickle.load(f)
    
    @staticmethod
    def chunks_to_dataframe(chunks: Dict[str, List[Dict]]) -> pd.DataFrame:
        """Convert chunks dictionary to pandas DataFrame."""
        rows = []
        
        for url, chunk_list in chunks.items():
            for chunk in chunk_list:
                row = {
                    'chunk_id': chunk['chunk_id'],
                    'url': url,
                    'title': chunk['title'],
                    'text': chunk['text'],
                    'chunk_index': chunk['chunk_index'],
                    'token_count': chunk['token_count'],
                    'word_count': chunk['word_count'],
                    'keywords': ', '.join(chunk.get('keywords', []))
                }
                rows.append(row)
        
        return pd.DataFrame(rows)
    
    @staticmethod
    def validate_urls(urls: List[str]) -> Dict[str, List[str]]:
        """Validate Wikipedia URLs."""
        valid_urls = []
        invalid_urls = []
        
        wikipedia_patterns = [
            'en.wikipedia.org/wiki/',
            'wikipedia.org/wiki/'
        ]
        
        for url in urls:
            if any(pattern in url for pattern in wikipedia_patterns):
                valid_urls.append(url)
            else:
                invalid_urls.append(url)
        
        return {
            'valid': valid_urls,
            'invalid': invalid_urls
        }
    
    @staticmethod
    def merge_datasets(datasets: List[Dict], merge_key: str = 'url') -> Dict:
        """Merge multiple datasets on a common key."""
        merged = {}
        
        for dataset in datasets:
            for key, value in dataset.items():
                if key not in merged:
                    merged[key] = value
                else:
                    # Handle conflicts by preferring newer data
                    merged[key].update(value)
        
        return merged
    
    @staticmethod
    def calculate_storage_size(data: Any) -> Dict[str, float]:
        """Calculate storage requirements for data."""
        import sys
        
        # Get size in memory
        memory_size = sys.getsizeof(data)
        
        # Estimate JSON size
        json_str = json.dumps(data)
        json_size = len(json_str.encode('utf-8'))
        
        # Estimate pickle size
        pickle_data = pickle.dumps(data)
        pickle_size = len(pickle_data)
        
        return {
            'memory_mb': memory_size / (1024 * 1024),
            'json_mb': json_size / (1024 * 1024),
            'pickle_mb': pickle_size / (1024 * 1024)
        }
    
    @staticmethod
    def clean_directory(directory: Union[str, Path], 
                       extensions: Optional[List[str]] = None) -> None:
        """Clean files from directory with specified extensions."""
        directory = Path(directory)
        
        if not directory.exists():
            return
        
        if extensions is None:
            extensions = ['.json', '.pkl', '.csv', '.txt']
        
        for file_path in directory.iterdir():
            if file_path.is_file() and file_path.suffix in extensions:
                file_path.unlink()
                print(f"Removed: {file_path}")


def main():
    """Test data utilities."""
    utils = DataUtils()
    
    # Test data
    test_data = {
        'test': 'value',
        'number': 42,
        'list': [1, 2, 3]
    }
    
    # Test save/load JSON
    utils.save_json(test_data, 'test_data.json')
    loaded_data = utils.load_json('test_data.json')
    print("JSON save/load test:", loaded_data == test_data)
    
    # Test storage calculation
    storage = utils.calculate_storage_size(test_data)
    print("Storage sizes:", storage)


if __name__ == "__main__":
    main()