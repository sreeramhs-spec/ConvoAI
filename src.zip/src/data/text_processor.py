"""
Text processing and chunking module.

This module handles:
- Text preprocessing and cleaning
- Chunking text into overlapping segments
- Token counting and validation
- Metadata extraction and management
"""

import re
import uuid
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import nltk
import spacy
from nltk.tokenize import sent_tokenize, word_tokenize
from transformers import AutoTokenizer


class TextProcessor:
    """Handles text preprocessing and chunking operations."""
    
    def __init__(self, 
                 chunk_size: int = 300,
                 chunk_overlap: int = 50,
                 tokenizer_name: str = "sentence-transformers/all-MiniLM-L6-v2"):
        """
        Initialize the text processor.
        
        Args:
            chunk_size: Maximum tokens per chunk
            chunk_overlap: Number of overlapping tokens between chunks
            tokenizer_name: HuggingFace tokenizer to use for token counting
        """
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap
        
        # Initialize tokenizer
        try:
            self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)
        except Exception as e:
            print(f"Warning: Could not load tokenizer {tokenizer_name}: {e}")
            print("Falling back to simple word-based tokenization")
            self.tokenizer = None
        
        # Initialize spaCy for advanced processing
        try:
            self.nlp = spacy.load("en_core_web_sm")
        except OSError:
            print("Warning: spaCy model not found. Some features may be limited.")
            self.nlp = None
            
        # Download required NLTK data
        try:
            nltk.data.find('tokenizers/punkt')
        except LookupError:
            nltk.download('punkt')
            
        try:
            nltk.data.find('corpora/stopwords')
        except LookupError:
            nltk.download('stopwords')
    
    def preprocess_text(self, text: str) -> str:
        """
        Clean and preprocess text.
        
        Args:
            text: Raw text to preprocess
            
        Returns:
            Cleaned text
        """
        # Basic cleaning
        text = self._basic_cleaning(text)
        
        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text)
        text = text.strip()
        
        return text
    
    def _basic_cleaning(self, text: str) -> str:
        """Perform basic text cleaning."""
        # Remove special characters but keep basic punctuation
        text = re.sub(r'[^\w\s\.\,\!\?\;\:\-\(\)\'\"]+', ' ', text)
        
        # Fix common issues
        text = re.sub(r'\.{2,}', '.', text)  # Multiple periods
        text = re.sub(r'\s+([\.!?;,])', r'\1', text)  # Space before punctuation
        text = re.sub(r'([\.!?])\s*([A-Z])', r'\1 \2', text)  # Sentence boundaries
        
        return text
    
    def count_tokens(self, text: str) -> int:
        """
        Count tokens in text using the configured tokenizer.
        
        Args:
            text: Text to count tokens for
            
        Returns:
            Number of tokens
        """
        if self.tokenizer:
            try:
                tokens = self.tokenizer.encode(text, add_special_tokens=False)
                return len(tokens)
            except Exception:
                pass
        
        # Fallback to simple word tokenization
        return len(word_tokenize(text))
    
    def chunk_text(self, 
                   text: str, 
                   title: str = "",
                   url: str = "",
                   preserve_sentences: bool = True) -> List[Dict[str, any]]:
        """
        Split text into overlapping chunks.
        
        Args:
            text: Text to chunk
            title: Document title for metadata
            url: Document URL for metadata
            preserve_sentences: Whether to avoid breaking sentences
            
        Returns:
            List of chunk dictionaries with metadata
        """
        if not text or not text.strip():
            return []
        
        # Preprocess text
        text = self.preprocess_text(text)
        
        # Split into sentences for sentence-aware chunking
        if preserve_sentences:
            sentences = sent_tokenize(text)
        else:
            # Split by periods as fallback
            sentences = [s.strip() for s in text.split('.') if s.strip()]
            sentences = [s + '.' for s in sentences[:-1]] + [sentences[-1]]
        
        chunks = []
        current_chunk = ""
        current_chunk_tokens = 0
        
        for sentence in sentences:
            sentence_tokens = self.count_tokens(sentence)
            
            # If adding this sentence would exceed chunk size
            if (current_chunk_tokens + sentence_tokens > self.chunk_size and 
                current_chunk.strip()):
                
                # Save current chunk
                chunk_data = self._create_chunk_data(
                    current_chunk, title, url, len(chunks)
                )
                chunks.append(chunk_data)
                
                # Start new chunk with overlap
                overlap_text = self._get_overlap_text(current_chunk)
                current_chunk = overlap_text + " " + sentence
                current_chunk_tokens = self.count_tokens(current_chunk)
                
            else:
                # Add sentence to current chunk
                if current_chunk:
                    current_chunk += " " + sentence
                else:
                    current_chunk = sentence
                current_chunk_tokens += sentence_tokens
        
        # Add final chunk
        if current_chunk.strip():
            chunk_data = self._create_chunk_data(
                current_chunk, title, url, len(chunks)
            )
            chunks.append(chunk_data)
        
        return chunks
    
    def _get_overlap_text(self, text: str) -> str:
        """Extract overlap text from the end of current chunk."""
        if not text:
            return ""
        
        words = text.split()
        if len(words) <= self.chunk_overlap:
            return text
        
        # Take last N words for overlap
        overlap_words = words[-self.chunk_overlap:]
        overlap_text = " ".join(overlap_words)
        
        # Ensure we don't break in the middle of a sentence
        sentences = sent_tokenize(overlap_text)
        if len(sentences) > 1:
            # Take complete sentences from the end
            return " ".join(sentences[-1:])
        
        return overlap_text
    
    def _create_chunk_data(self, 
                          chunk_text: str, 
                          title: str, 
                          url: str, 
                          chunk_id: int) -> Dict[str, any]:
        """Create a chunk data dictionary with metadata."""
        chunk_uuid = str(uuid.uuid4())
        
        return {
            'chunk_id': chunk_uuid,
            'chunk_index': chunk_id,
            'text': chunk_text.strip(),
            'title': title,
            'url': url,
            'token_count': self.count_tokens(chunk_text),
            'char_count': len(chunk_text),
            'word_count': len(chunk_text.split()),
            'metadata': {
                'source_type': 'wikipedia',
                'chunk_method': 'sentence_aware',
                'overlap_tokens': self.chunk_overlap
            }
        }
    
    def extract_keywords(self, text: str, top_k: int = 10) -> List[str]:
        """
        Extract key terms from text using spaCy.
        
        Args:
            text: Text to extract keywords from
            top_k: Number of top keywords to return
            
        Returns:
            List of keywords
        """
        if not self.nlp:
            # Fallback to simple frequency-based extraction
            words = word_tokenize(text.lower())
            stopwords = set(['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 
                           'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were'])
            words = [w for w in words if w.isalpha() and w not in stopwords]
            
            from collections import Counter
            word_freq = Counter(words)
            return [word for word, count in word_freq.most_common(top_k)]
        
        # Use spaCy for better keyword extraction
        doc = self.nlp(text)
        
        # Extract named entities and important tokens
        keywords = []
        
        # Add named entities
        for ent in doc.ents:
            if ent.label_ in ['PERSON', 'ORG', 'GPE', 'EVENT', 'PRODUCT']:
                keywords.append(ent.text.lower())
        
        # Add important tokens (nouns, adjectives)
        for token in doc:
            if (token.pos_ in ['NOUN', 'ADJ'] and 
                not token.is_stop and 
                not token.is_punct and 
                len(token.text) > 2):
                keywords.append(token.lemma_.lower())
        
        # Remove duplicates and return top-k
        keywords = list(set(keywords))
        return keywords[:top_k]
    
    def process_articles(self, 
                        articles: Dict[str, Dict],
                        output_dir: str = "data/processed") -> Dict[str, List[Dict]]:
        """
        Process all articles into chunks.
        
        Args:
            articles: Dictionary of article data
            output_dir: Directory to save processed chunks
            
        Returns:
            Dictionary mapping article URLs to lists of chunks
        """
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        all_chunks = {}
        chunk_metadata = []
        
        print(f"Processing {len(articles)} articles into chunks...")
        
        for url, article_data in articles.items():
            # Extract chunks
            chunks = self.chunk_text(
                text=article_data['content'],
                title=article_data['title'],
                url=url
            )
            
            # Add keywords to each chunk
            for chunk in chunks:
                chunk['keywords'] = self.extract_keywords(chunk['text'])
            
            all_chunks[url] = chunks
            
            # Collect metadata
            for chunk in chunks:
                chunk_metadata.append({
                    'chunk_id': chunk['chunk_id'],
                    'url': url,
                    'title': chunk['title'],
                    'chunk_index': chunk['chunk_index'],
                    'token_count': chunk['token_count'],
                    'word_count': chunk['word_count']
                })
        
        # Save processed chunks
        import json
        
        # Save all chunks
        with open(output_path / "chunks.json", 'w') as f:
            json.dump(all_chunks, f, indent=2)
        
        # Save chunk metadata
        with open(output_path / "chunk_metadata.json", 'w') as f:
            json.dump(chunk_metadata, f, indent=2)
        
        # Save processing stats
        stats = self.get_processing_stats(all_chunks)
        with open(output_path / "processing_stats.json", 'w') as f:
            json.dump(stats, f, indent=2)
        
        print(f"Processed {sum(len(chunks) for chunks in all_chunks.values())} chunks")
        
        return all_chunks
    
    def get_processing_stats(self, all_chunks: Dict[str, List[Dict]]) -> Dict:
        """Get statistics about processed chunks."""
        if not all_chunks:
            return {}
        
        all_chunk_list = [chunk for chunks in all_chunks.values() for chunk in chunks]
        
        token_counts = [chunk['token_count'] for chunk in all_chunk_list]
        word_counts = [chunk['word_count'] for chunk in all_chunk_list]
        
        stats = {
            'total_articles': len(all_chunks),
            'total_chunks': len(all_chunk_list),
            'avg_chunks_per_article': len(all_chunk_list) / len(all_chunks),
            'token_stats': {
                'total_tokens': sum(token_counts),
                'avg_tokens_per_chunk': sum(token_counts) / len(token_counts),
                'min_tokens': min(token_counts),
                'max_tokens': max(token_counts)
            },
            'word_stats': {
                'total_words': sum(word_counts),
                'avg_words_per_chunk': sum(word_counts) / len(word_counts),
                'min_words': min(word_counts),
                'max_words': max(word_counts)
            },
            'chunk_size_distribution': {
                'small (1-100 tokens)': len([t for t in token_counts if 1 <= t < 100]),
                'medium (100-250 tokens)': len([t for t in token_counts if 100 <= t < 250]),
                'large (250+ tokens)': len([t for t in token_counts if t >= 250])
            }
        }
        
        return stats


def main():
    """Test the text processor."""
    processor = TextProcessor()
    
    # Test with sample text
    sample_text = """
    Artificial intelligence (AI) refers to the simulation of human intelligence 
    in machines that are programmed to think like humans and mimic their actions. 
    The term may also be applied to any machine that exhibits traits associated 
    with a human mind such as learning and problem-solving. The ideal characteristic 
    of artificial intelligence is its ability to rationalize and take actions that 
    have the best chance of achieving a specific goal.
    """
    
    chunks = processor.chunk_text(
        text=sample_text,
        title="Artificial Intelligence",
        url="https://example.com"
    )
    
    print(f"Created {len(chunks)} chunks:")
    for i, chunk in enumerate(chunks):
        print(f"\nChunk {i + 1}:")
        print(f"Tokens: {chunk['token_count']}")
        print(f"Text: {chunk['text'][:100]}...")


if __name__ == "__main__":
    main()